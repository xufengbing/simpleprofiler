#!/bin/sh
$JAVA_HOME/bin/java -jar client.jar start $1 $2
