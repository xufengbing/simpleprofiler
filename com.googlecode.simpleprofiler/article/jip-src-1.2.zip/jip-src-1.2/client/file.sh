#!/bin/sh
$JAVA_HOME/bin/java -jar client.jar file $1 $2 $3
