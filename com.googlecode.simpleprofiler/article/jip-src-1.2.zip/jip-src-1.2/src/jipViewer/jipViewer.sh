# ./bin/sh
java -jar jipViewer.jar $1