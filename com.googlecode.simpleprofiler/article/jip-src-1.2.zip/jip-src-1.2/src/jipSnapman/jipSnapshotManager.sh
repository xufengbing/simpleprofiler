# ./bin/sh
java -jar jipSnapshotManager-1.0.jar
