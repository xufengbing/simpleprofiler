/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import com.sun.star.uno.Exception;
import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.gst.explorer.ate.UDAccessor;

/**
 * @author alanlin
 */
public class LoadAction implements IObjectActionDelegate {
	private static final String XML_TAG = "xml";
	private IFile selectFile;

	@Override
	public void run(IAction action) {
		if (isXmlFile(selectFile)) {
			if (!selectFile.exists() || !selectFile.isAccessible()) {
				StringBuilder sb = new StringBuilder("Could not able load file \"");
				sb.append(selectFile.getLocation().toOSString());
				sb.append("\"!\n");
				sb.append("File does not exist or not accessible!");
				MessageDialog.openError(null, "Load", sb.toString());
				return;
			}

			IPath path = selectFile.getLocation();
			IPath dir = path.removeLastSegments(1);

			try {
				UDAccessor.getInstance().loadTDE(dir.toOSString(), selectFile.getName());
			} catch (CoreException93k e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			Object selObj = ((IStructuredSelection)selection).getFirstElement();
			if (selObj instanceof IFile) {
				selectFile = (IFile) selObj;

				if (!isXmlFile(selectFile)) {
					action.setEnabled(false);
				} else {
					action.setEnabled(true);
				}
			}
		} else {
			selectFile = null;
			action.setEnabled(false);
		}
	}

	private boolean isXmlFile(IFile file) {
		return true;
		//return file == null ? false : XML_TAG.equalsIgnoreCase(file.getFileExtension());
	}

	@Override
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		// TODO Auto-generated method stub

	}
}
