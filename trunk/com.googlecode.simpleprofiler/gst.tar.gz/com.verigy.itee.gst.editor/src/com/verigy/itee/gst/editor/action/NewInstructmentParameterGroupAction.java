/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * @author alanlin
 */
public class NewInstructmentParameterGroupAction extends NewAction {

	public NewInstructmentParameterGroupAction() {
		super("Set");
	}

	@Override
	protected GenericNodeType getNodeType() {
		return GenericNodeType.SET;
	}
}
