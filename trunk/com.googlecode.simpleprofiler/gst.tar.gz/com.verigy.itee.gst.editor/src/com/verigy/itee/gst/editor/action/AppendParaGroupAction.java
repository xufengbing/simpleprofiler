/**
 *
 */
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * @author bennwang
 *
 */
public class AppendParaGroupAction extends NewAction {

	public AppendParaGroupAction() {
		super("Append Set");
		actionType = ADD;
	}

	/**
	 * Overrides this method since this action don't need to update the title.
	 */
	@Override
	protected void onSelectionChange(IAction action, ISelection selection2) {
		super.onSelectionChange(action, selection2);
	}

	/* (non-Javadoc)
	 * @see com.verigy.itee.gst.editor.action.NewAction#getNodeType()
	 */
	@Override
	protected GenericNodeType getNodeType() {
		return GenericNodeType.SET;
	}

}
