/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.Arrays;
import java.util.Comparator;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.HTMLTransfer;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.graphics.Point;

import com.verigy.itee.gst.explorer.ate.ITdoNode;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;

/**
 * @author alanlin
 *
 */
public class CopyAction extends AbstractGSTAction {
	/**
	 * Default constructor
	 */
	public CopyAction() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	@Override
	public void run(IAction action) {
	    if (isObjectSelectionMode()) {
    		ITdoNode[] nodes = getSelectedNodes();
    		if(nodes == null || nodes.length == 0) {
                return;
            }
            ClipboardUtil.getClipboard().setContents(new Object[] { nodes },
                    new Transfer[] { GenericNodeTransfer.getInstance() });
	    } else {
	        KTable table = getTable();
	        if (table != null) {
	            setClipboardContent(table, table.getCellSelection());
	        }
	    }
	}

	@Override
	protected void onSelectionChange(IAction action, ISelection selection2) {
	    if (!isContinuousSelection()) {
	        action.setEnabled(false);
	    }
	}

	   /**
     * Copies the specified text range to the clipboard.  The table will be placed
     * in the clipboard in plain text format and RTF format.
     * @param selection The list of cell indices thats content should be set
     * to the clipboard.
     *
     * @exception SWTError, see Clipboard.setContents
     * @see org.eclipse.swt.dnd.Clipboard.setContents
     */
    protected void setClipboardContent(KTable table, Point[] selection) throws SWTError {
        //RTFTransfer rtfTransfer = RTFTransfer.getInstance();
        TextTransfer plainTextTransfer = TextTransfer.getInstance();
        HTMLTransfer htmlTransfer = HTMLTransfer.getInstance();

        //String rtfText = getRTFForSelection(selection);
        String plainText = getTextForSelection(table, selection);
        String htmlText = getHTMLForSelection(table, selection);

        Clipboard clipboard = new Clipboard(table.getDisplay());
        try {
            clipboard.setContents(
                    new String[]{plainText, htmlText}, //rtfText
                    new Transfer[]{plainTextTransfer, htmlTransfer}); // rtfTransfer
        } catch (SWTError error) {
            // Copy to clipboard failed. This happens when another application
            // is accessing the clipboard while we copy. Ignore the error.
            // Rethrow all other errors.
            if (error.code != DND.ERROR_CANNOT_SET_CLIPBOARD) {
                throw error;
            }
        } finally {
            clipboard.dispose();
        }
    }

    protected String getHTMLForSelection(KTable table, Point[] selection) {
        StringBuffer html = new StringBuffer();
        sortSelectedCells(selection);

        Point[] dimensions = findTableDimensions(selection);
        Point topLeft = dimensions[0];
        Point bottomRight = dimensions[1];

        KTableModel model = table.getModel();
        if (model==null) {
            return "";
        }
        // add header:
        html.append("Version:1.0\n");
        html.append("StartHTML:0000000000\n");
        html.append("EndHTML:0000000000\n");
        html.append("StartFragment:0000000000\n");
        html.append("EndFragment:0000000000\n");
        html.append("<html><body><table>");


        Point nextValidCell = selection[0];
        int selCounter = 1;
        for (int row = topLeft.y; row<=bottomRight.y; row++) {
            html.append("<tr>");
            for (int col = topLeft.x; col<=bottomRight.x; col++) {
                // may skip the cell when it is spanned by another one.
                if (model.belongsToCell(col, row).equals(new Point(col, row))) {

                    if (nextValidCell.x == col && nextValidCell.y == row) {
                        html.append("<td");
                        Point spanning = findCellSpanning(col, row, model);
                        if (spanning.x>1) {
                            html.append(" colspan=\""+spanning.x+"\"");
                        }
                        if (spanning.y>1) {
                            html.append(" rowspan=\""+spanning.y+"\"");
                        }
                        html.append(">");

                        Object content = model.getContentAt(col, row);
                        html.append(maskHtmlChars(content.toString()));
                        if (selCounter<selection.length) {
                            nextValidCell = selection[selCounter];
                            selCounter++;
                        }
                    } else {
                        html.append("<td>");
                    }

                    html.append("</td>");
                }
            }
            html.append("</tr>");
        }
        html.append("</table></body></html>");

        return html.toString();
    }

    private String maskHtmlChars(String text) {
        //removed due to encoding issue
        return text;
    }

    protected String getTextForSelection(KTable table, Point[] selection) {
        StringBuffer text = new StringBuffer();
        Point topLeft = sortSelectedCells(selection);
        KTableModel model = table.getModel();
        if (model==null) {
            return "";
        }

        int currentCol = topLeft.x;
        for (int i=0; i<selection.length; i++) {
            for (; currentCol<selection[i].x; currentCol++) {
                text.append(TAB);
            }

            Object content = model.getContentAt(selection[i].x, selection[i].y);
            text.append(content.toString());

            if (i+1<selection.length) {
                for (int row = selection[i].y; row<selection[i+1].y; row++) {
                    text.append(PlatformLineDelimiter);
                }
                if (selection[i].y!=selection[i+1].y) {
                    currentCol=topLeft.x;
                }
            }
        }
        return text.toString();
    }

    protected Point sortSelectedCells(Point[] selection) {
        Arrays.sort(selection, new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Point p1 = (Point)o1;
                Point p2 = (Point)o2;
                if (p1.y<p2.y) {
                    return -1;
                }
                if (p1.y>p2.y) {
                    return +1;
                }
                if (p1.x<p2.x) {
                    return -1;
                }
                if (p1.x>p2.x) {
                    return +1;
                }
                return 0;
            }

        });

        int minCol = selection[0].x;
        for (int i=1; i<selection.length; i++) {
            if (selection[i].x<minCol) {
                minCol=selection[i].x;
            }
        }
        return new Point(minCol, selection[0].y);
    }

    private Point[] findTableDimensions(Point[] selection) {
        Point topLeft = new Point(-1,-1);
        Point bottomRight = new Point(-1, -1);

        for (int i=0; i<selection.length; i++) {
            Point cell = selection[i];
            if (topLeft.x<0) {
                topLeft.x = cell.x;
            } else if (topLeft.x>cell.x) {
                topLeft.x = cell.x;
            }
            if (bottomRight.x<0) {
                bottomRight.x = cell.x;
            } else if (bottomRight.x<cell.x) {
                bottomRight.x = cell.x;
            }

            if (topLeft.y<0) {
                topLeft.y = cell.y;
            } else if (topLeft.y>cell.y) {
                topLeft.y = cell.y;
            }
            if (bottomRight.y<0) {
                bottomRight.y = cell.y;
            } else if (bottomRight.y<cell.y) {
                bottomRight.y = cell.y;
            }
        }
        return new Point[]{topLeft, bottomRight};
    }

    private Point findCellSpanning(int col, int row, KTableModel model) {
        Point spanning = new Point(1,1);
        Point cell = new Point(col, row);
        while (model.belongsToCell(col+spanning.x, row).equals(cell)) {
            spanning.x++;
        }

        while (model.belongsToCell(col, row+spanning.y).equals(cell)) {
            spanning.y++;
        }

        return spanning;
    }
}
