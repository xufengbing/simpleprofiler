/**
 *
 */
package com.verigy.itee.gst.editor.ktable.selection;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.ListenerList;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.util.SafeRunnable;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.editor.Activator;
import com.verigy.itee.gst.editor.ktable.model.IObjectOperationSupport;
import com.verigy.itee.gst.editor.ktable.model.IUdaObjectOperationSupport;
import com.verigy.itee.gst.editor.ktable.selection.internal.GenericNodeSelectionElement;
import com.verigy.itee.gst.editor.model.IGenericNode;
import com.verigy.itee.gst.editor.prefs.PreferenceConstants;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.ktabletree.KTableTreeModel;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableCellSelectionAdapter;
import de.kupzog.ktable.KTableCellSelectionListener;
import de.kupzog.ktable.KTableModel;

/**
 * @author alanlin
 */
public class KTableSelectionProvider implements IGSTSelectionProvider,
		IInitializeSelectionSupport {

	/**
	 * List of selection change listeners (elment type :
	 * <code>ISelectionChangeListener</code>.
	 *
	 * @see #fireSelectionChanged
	 */
	private final ListenerList selectionChangeListeners = new ListenerList();

	private KTableCellSelectionListener cellSelectionListener;

	private ISelection selection;

	private final KTable table;

	private final IEditorPart editor;


	/**
	 * @param table
	 *            non null table object to adapt to
	 * @param editor the editor which contains the given table
	 */
	public KTableSelectionProvider(KTable table, IEditorPart editor) {
		this.editor = editor;
		Assert.isNotNull(table);
		this.table = table;
		addCellChangedListener();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.eclipse.jface.viewers.ISelectionProvider#addSelectionChangedListener
	 * (org.eclipse.jface.viewers.ISelectionChangedListener)
	 */
	@Override
    public void addSelectionChangedListener(ISelectionChangedListener listener) {
		selectionChangeListeners.add(listener);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.jface.viewers.ISelectionProvider#getSelection()
	 */
	@Override
    public ISelection getSelection() {
		return selection;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.eclipse.jface.viewers.ISelectionProvider#removeSelectionChangedListener
	 * (org.eclipse.jface.viewers.ISelectionChangedListener)
	 */
	@Override
    public void removeSelectionChangedListener(
			ISelectionChangedListener listener) {
		selectionChangeListeners.remove(listener);

	}

	@Override
    public void setSelection(ISelection selection) {
		this.selection = selection;

		SelectionChangedEvent event = new SelectionChangedEvent(this, selection);
		fireSelectionChanged(event);
	}

	/**
	 * Set selection with optional fire event. Sometimes we need to re-select
	 * some cells without firing selection change event. This method may help.
	 *
	 * @param selection
	 *            the {@linkplain ISelection} which will be set.
	 * @param fireEvent
	 *            the flag to indicate if a selection change event should be
	 *            fired or not.
	 */
	public void setSelection(ISelection selection, boolean fireEvent) {
		this.selection = selection;

		if (fireEvent) {
			SelectionChangedEvent event = new SelectionChangedEvent(this,
					selection);
			fireSelectionChanged(event);
		}
	}

	/**
	 * Notifies any selection changed listeners that the viewer's selection has
	 * changed. Only listeners registered at the time this method is called are
	 * notified.
	 *
	 * @param event
	 *            a selection changed event
	 * @see ISelectionChangedListener#selectionChanged
	 */
	protected void fireSelectionChanged(final SelectionChangedEvent event) {
		Object[] listeners = selectionChangeListeners.getListeners();
		for (int i = 0; i < listeners.length; i++) {
			final ISelectionChangedListener l = (ISelectionChangedListener) listeners[i];
			SafeRunnable.run(new SafeRunnable() {
				@Override
                public void run() throws Exception {
					l.selectionChanged(event);
				}
			});
		}
	}

	private void addCellChangedListener() {
		cellSelectionListener = new KTableCellSelectionAdapter() {
			/*
			 * (non-Javadoc)
			 *
			 * @see
			 * de.kupzog.ktable.KTableCellSelectionAdapter#cellSelected(int,
			 * int, int)
			 */
			@Override
			public void cellSelected(final int col, final int row, int statemask) {
				if ((statemask & SWT.SHIFT) == SWT.SHIFT || // if Shift key was
															// pressed
						(statemask & SWT.CTRL) == SWT.CTRL) { // if Ctrl key was
																// pressed
					table.getDisplay().asyncExec(new Runnable() {
						@Override
                        public void run() {
							onCellSelected(col, row);
						}
					});
				} else {
					onCellSelected(col, row);
				}

			}

			/*
			 * (non-Javadoc)
			 *
			 * @see
			 * de.kupzog.ktable.KTableCellSelectionAdapter#fixedCellSelected
			 * (int, int, int)
			 */
			@Override
			public void fixedCellSelected(final int col, final int row,
					int statemask) {
				if ((statemask & SWT.SHIFT) == SWT.SHIFT || // if Shift key was
															// pressed
						(statemask & SWT.CTRL) == SWT.CTRL) { // if Ctrl key was
																// pressed
					table.getDisplay().asyncExec(new Runnable() {
						@Override
                        public void run() {
							onCellSelected(col, row);
						}
					});
				} else {
					onCellSelected(col, row);
				}
			}
		};

		table.addCellSelectionListener(cellSelectionListener);
	}

	/**
	 * Gets the object which is selected and constructs selection change event.
	 *
	 * @param col
	 *            the table column index
	 * @param row
	 *            the table row index which is selected
	 */
	private void onCellSelected(int col, int row) {
	    // below selection is only available for KTableTreeModel
	    if (!(table.getModel() instanceof KTableTreeModel)) {
	        return;
	    }

		KTableTreeModel model = (KTableTreeModel)table.getModel();
		if (model instanceof IObjectOperationSupport) {
			IObjectOperationSupport objectSelectionModel = (IObjectOperationSupport) model;
			int[] selectedRows = table.getRowSelection();
			ISelection sel = StructuredSelection.EMPTY;
			if (selectedRows.length > 0) { // row selection
				if (selectedRows.length == 1) {
					IGenericNode selectedNode = (IGenericNode) objectSelectionModel
							.getObjectAt(selectedRows[0]);

					IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
							table, editor, selectedNode, "HEADER", SelectionType.SINGLE_WHOLE_ROW);

					sel = new StructuredSelection(selElm);
				} else {
					List<IGenericNodeSelectionElement> selElms = new ArrayList<IGenericNodeSelectionElement>();
					for (int rowIdx : selectedRows) {
						IGenericNode selectedNode = (IGenericNode) objectSelectionModel
							.getObjectAt(rowIdx);

						IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
								table, editor, selectedNode, "HEADER", SelectionType.MULTI_WHOLE_ROW);
						selElms.add(selElm);
					}

					sel = new StructuredSelection(selElms);
				}
			} else { // cell selection
				Point[] selectedPoints = table.getCellSelection();
				if (selectedPoints.length == 1) {
					IGenericNode selectedNode = (IGenericNode) objectSelectionModel
						.getObjectAt(selectedPoints[0].y);

					String column = model.getContentAt(selectedPoints[0].x, 0).toString();
					IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
							table, editor, selectedNode, column, SelectionType.SINGLE_CELL);

					sel = new StructuredSelection(selElm);
				} else {
					int[] rowIdxs = getAllSelectedRows(selectedPoints);

					List<IGenericNodeSelectionElement> selElms = new ArrayList<IGenericNodeSelectionElement>();
					for (int rowIdx : rowIdxs) {
						IGenericNode selectedNode = (IGenericNode) objectSelectionModel
							.getObjectAt(rowIdx);

						IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
								table, editor, selectedNode, "MULTI", SelectionType.MULTI_CELL);
						selElms.add(selElm);
					}

					sel = new StructuredSelection(selElms);
				}
			}

			setSelection(sel);
		} else if (model instanceof IUdaObjectOperationSupport) {
	            IUdaObjectOperationSupport objectSelectionModel = (IUdaObjectOperationSupport) model;
	            int[] selectedRows = table.getRowSelection();
	            ISelection sel = StructuredSelection.EMPTY;
	            if (selectedRows.length > 0) { // row selection
	                if (selectedRows.length == 1) {
	                    int modelIdx = model.mapRowIndexToModel(selectedRows[0]);
	                    ITdoNode selectedNode = (ITdoNode) objectSelectionModel
	                            .getObjectAt(modelIdx);

	                    List<IGenericNodeSelectionElement> selElms = new ArrayList<IGenericNodeSelectionElement>();
	                    IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
	                            table, editor, selectedNode, "HEADER", SelectionType.SINGLE_WHOLE_ROW, modelIdx);
	                    selElms.add(selElm);

	                    // handle the selection of its children
                        if (!model.isExpanded(selectedRows[0]) && selectedNode.hasChild()) {
                            IPreferenceStore store = Activator.getDefault().getPreferenceStore();
                            String selectionPattern = store.getString(PreferenceConstants.SELECTION_PATTERN);
                            if (!PreferenceConstants.NONE.equals(selectionPattern)) {
                                boolean selected = true;
                                if (PreferenceConstants.ASK.equals(selectionPattern)) {
                                    if (!MessageDialog.openQuestion(null, "Auto Select", "Do you like to auto select all children?")) {
                                        selected = false;
                                    }
                                }

                                if (selected) {
                                    int allChildCount = model.getSubrowCountAll(modelIdx);
                                    for (int idx = modelIdx + 1; idx < modelIdx + allChildCount; idx++) {
                                        ITdoNode children = (ITdoNode)objectSelectionModel.getObjectAt(idx);
                                        selElm = new GenericNodeSelectionElement(
                                                table, editor, children, "HEADER", SelectionType.SINGLE_WHOLE_ROW, idx);
                                        selElms.add(selElm);
                                    }
                                }
                            }
                        }

	                    sel = new StructuredSelection(selElms);
	                } else {
	                    List<IGenericNodeSelectionElement> selElms = new ArrayList<IGenericNodeSelectionElement>();
	                    boolean alreadyAsked = false;
	                    for (int rowIdx : selectedRows) {
	                        int modelRowIdx = model.mapRowIndexToModel(rowIdx);
	                        ITdoNode selectedNode = (ITdoNode) objectSelectionModel
	                            .getObjectAt(modelRowIdx);

	                        IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
	                                table, editor, selectedNode, "HEADER", SelectionType.MULTI_WHOLE_ROW, modelRowIdx);
	                        selElms.add(selElm);

	                        // handle the selection of its children
	                        if (!model.isExpanded(rowIdx) && selectedNode.hasChild()) {
	                            IPreferenceStore store = Activator.getDefault().getPreferenceStore();
	                            String selectionPattern = store.getString(PreferenceConstants.SELECTION_PATTERN);
	                            if (!PreferenceConstants.NONE.equals(selectionPattern)) {
	                                boolean selected = true;
	                                if (PreferenceConstants.ASK.equals(selectionPattern) && !alreadyAsked) {
	                                    alreadyAsked = true;
	                                    if (!MessageDialog.openQuestion(null, "Auto Select", "Do you like to auto select all children?")) {
	                                        selected = false;
	                                    }
	                                }

	                                if (selected) {
	                                    int allChildCount = model.getSubrowCountAll(modelRowIdx);
	                                    for (int idx = modelRowIdx + 1; idx < modelRowIdx + allChildCount; idx++) {
	                                        ITdoNode children = (ITdoNode)objectSelectionModel.getObjectAt(idx);
	                                        selElm = new GenericNodeSelectionElement(
	                                                table, editor, children, "HEADER", SelectionType.MULTI_WHOLE_ROW, idx);
	                                        selElms.add(selElm);
	                                    }
	                                }
	                            }
	                        }
	                    }

	                    sel = new StructuredSelection(selElms);
	                }
	            } else { // cell selection
	                Point[] selectedPoints = table.getCellSelection();
	                if (selectedPoints.length == 1) {
	                    int modelRowIdx = model.mapRowIndexToModel(selectedPoints[0].y);
	                    ITdoNode selectedNode = (ITdoNode) objectSelectionModel
	                        .getObjectAt(modelRowIdx);

	                    String column = model.getContentAt(selectedPoints[0].x, 0).toString();

	                    List<IGenericNodeSelectionElement> selElms = new ArrayList<IGenericNodeSelectionElement>();

	                    IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
	                            table, editor, selectedNode, column, SelectionType.SINGLE_CELL, modelRowIdx);
	                    selElms.add(selElm);

	                    // treat the selection on the first column as the whole row selection and handle the selection of its children
                        if ("Node".equals(column) && !model.isExpanded(selectedPoints[0].y) && selectedNode.hasChild()) {
                            IPreferenceStore store = Activator.getDefault().getPreferenceStore();
                            String selectionPattern = store.getString(PreferenceConstants.SELECTION_PATTERN);
                            if (!PreferenceConstants.NONE.equals(selectionPattern)) {
                                boolean selected = true;
                                if (PreferenceConstants.ASK.equals(selectionPattern)) {
                                    if (!MessageDialog.openQuestion(null, "Auto Select", "Do you like to auto select all children?")) {
                                        selected = false;
                                    }
                                }

                                if (selected) {
                                    int allChildCount = model.getSubrowCountAll(modelRowIdx);
                                    for (int idx = modelRowIdx + 1; idx < modelRowIdx + allChildCount; idx++) {
                                        ITdoNode children = (ITdoNode)objectSelectionModel.getObjectAt(idx);
                                        selElm = new GenericNodeSelectionElement(
                                                table, editor, children, "HEADER", SelectionType.SINGLE_WHOLE_ROW, idx);
                                        selElms.add(selElm);
                                    }
                                }
                            }
                        }


	                    sel = new StructuredSelection(selElms);
	                } else {
	                    int[] rowIdxs = getAllSelectedRows(selectedPoints);
	                    boolean alreadyAsked = false;
	                    boolean isInSameColumn = checkInSameColumn(selectedPoints);
	                    String column = model.getContentAt(selectedPoints[0].x, 0).toString();

	                    List<IGenericNodeSelectionElement> selElms = new ArrayList<IGenericNodeSelectionElement>();
	                    for (int rowIdx : rowIdxs) {
	                        int modelRowIdx = model.mapRowIndexToModel(rowIdx);
                            ITdoNode selectedNode = (ITdoNode) objectSelectionModel
	                            .getObjectAt(modelRowIdx);

	                        String columnStr = isInSameColumn ? column : "MULTI";
	                        IGenericNodeSelectionElement selElm = new GenericNodeSelectionElement(
	                                table, editor, selectedNode, columnStr, SelectionType.MULTI_CELL, modelRowIdx);
	                        selElms.add(selElm);

	                        // treat the selection on the first column as the whole row selection and handle the selection of its children
                           if ("Node".equals(columnStr) && !model.isExpanded(rowIdx) && selectedNode.hasChild()) {
                                IPreferenceStore store = Activator.getDefault().getPreferenceStore();
                                String selectionPattern = store.getString(PreferenceConstants.SELECTION_PATTERN);
                                if (!PreferenceConstants.NONE.equals(selectionPattern)) {
                                    boolean selected = true;
                                    if (PreferenceConstants.ASK.equals(selectionPattern) && !alreadyAsked) {
                                        alreadyAsked = true;
                                        if (!MessageDialog.openQuestion(null, "Auto Select", "Do you like to auto select all children?")) {
                                            selected = false;
                                        }
                                    }

                                    if (selected) {
                                        int allChildCount = model.getSubrowCountAll(modelRowIdx);
                                        for (int idx = modelRowIdx + 1; idx < modelRowIdx + allChildCount; idx++) {
                                            ITdoNode children = (ITdoNode)objectSelectionModel.getObjectAt(idx);
                                            selElm = new GenericNodeSelectionElement(
                                                    table, editor, children, "HEADER", SelectionType.MULTI_WHOLE_ROW, idx);
                                            selElms.add(selElm);
                                        }
                                    }
                                }
                            }
	                    }

	                    sel = new StructuredSelection(selElms);
	                }
	            }

	            setSelection(sel);
	        }
	}

    /**
     * Checks if all selections are in same column.
     * @param selectedPoints all selections to be checked
     * @return Returns true if the given selections are all in same column,
     * otherwise returns false;
     */
    private boolean checkInSameColumn(Point[] selectedPoints) {
        boolean isInSameColumn = true;
        if (selectedPoints.length > 0) {
            int columnIdx = selectedPoints[0].x;
            for (int i = 1; i < selectedPoints.length; i++) {
                if (selectedPoints[i].x != columnIdx) {
                    isInSameColumn = false;
                }
            }
        }
        return isInSameColumn;
    }

    /*
	 * (non-Javadoc)
	 *
	 * @seecom.verigy.itee.testflow.ui.testlist.editors.ITTLSelectionProvider#
	 * fireClearSelectionEvent()
	 */
	@Override
    public void fireClearSelectionEvent() {
		ISelection sel = StructuredSelection.EMPTY;
		setSelection(sel);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @seecom.verigy.itee.testflow.ui.testlist.editors.IInitializeSelection#
	 * initializeSelection(int, int)
	 */
	@Override
    public void initializeSelection() {
		Point[] cells = table.getCellSelection();
		if (cells.length == 0) {
			setSelection(StructuredSelection.EMPTY);
		} else {
			onCellSelected(cells[0].x, cells[0].y);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @seecom.verigy.itee.testflow.ui.testlist.editors.ITTLSelectionProvider#
	 * reselectCell(de.kupzog.ktable.KTable)
	 */
	@Override
    public void reselectCell(KTable aTable) {
		if (aTable == null || aTable.isDisposed()) {
			return;
		}

		Point[] points = aTable.getCellSelection();

		if (points.length == 0) {
			return;
		}

		KTableModel model = aTable.getModel();
		if (model.getRowCount() > points[0].y
				&& model.getColumnCount() > points[0].x) {
			onCellSelected(points[0].x, points[0].y);
		} else {
			setSelection(new StructuredSelection(StructuredSelection.EMPTY));
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * com.verigy.itee.testflow.ui.testlist.editors.ITTLSelectionProvider#selectCell
	 * (de.kupzog.ktable.KTable, int)
	 */
	@Override
    public void selectCell(KTable aTable, int row) {
		if (row >= 0 && row < aTable.getModel().getRowCount()) {
			aTable.setSelection(0, row, true);
		}
	}



	private int[] getAllSelectedRows(Point[] selectedPoints) {
		Set<Integer> spin = new HashSet<Integer>();
		for(Point p : selectedPoints) {
			spin.add(Integer.valueOf(p.y));
		}

		int[] result = new int[spin.size()];

		Iterator<Integer> ite = spin.iterator();
		int i = 0;
		while(ite.hasNext()) {
			Integer row = ite.next();
			result[i++] = row.intValue();
		}

		return result;
	}

    @Override
    public void selectObject(KTable aTable, Object obj) {
        KTableModel model = aTable.getModel();

        if (model instanceof IUdaObjectOperationSupport && obj instanceof ITdoNode) {
            IUdaObjectOperationSupport udaModel = (IUdaObjectOperationSupport) model;
            int rowIndex = udaModel.getRowIndexFor((ITdoNode)obj);

            if (model instanceof KTableTreeModel) {
                rowIndex = ((KTableTreeModel) model).mapRowIndexToTable(rowIndex);
            }

            selectCell(aTable, rowIndex);
        }
    }
}
