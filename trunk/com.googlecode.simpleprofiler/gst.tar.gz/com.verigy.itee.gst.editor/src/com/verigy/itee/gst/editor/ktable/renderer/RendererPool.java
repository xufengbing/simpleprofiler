/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.renderer;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

import com.verigy.itee.gst.editor.Activator;
import com.verigy.itee.gst.editor.model.FloatingTdoNode;
import com.verigy.itee.gst.editor.model.IGenericNode;
import com.verigy.itee.gst.editor.prefs.PreferenceConstants;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.ktabletree.renderers.TreeCellRenderer;

import de.kupzog.ktable.KTableCellRenderer;
import de.kupzog.ktable.renderers.DefaultCellRenderer;
import de.kupzog.ktable.renderers.FixedCellRenderer;


/**
 * @author alanlin
 */
public class RendererPool {
    private static RendererPool instance;
    /**
     * @return Returns the only instance of this class
     */
    public static RendererPool getInstance() {
        if (instance == null ) {
            instance = new RendererPool();
        }

        return instance;
    }

    /**
     * @return Returns the fixed cell renderer
     */
    public KTableCellRenderer getFixedCellRenderer() {
        return fixedCellRenderer;
    }

    /**
     * @param node the corresponding node
     * @param isTreeCell indicates if the cell is tree cell or not
     * @return Returns the corresponding cell renderer
     */
    public KTableCellRenderer getCellRender(IGenericNode node, boolean isTreeCell) {
        GenericNodeType type = node == null ? GenericNodeType.UNKNOWN : node.getNodeType();
        KTableCellRenderer renderer = isTreeCell ? treeCellRenderer.get(type) : nonTreeCellRenderer.get(type);

        if (renderer == null) {
            renderer = isTreeCell ? treeCellRenderer.get(GenericNodeType.UNKNOWN) : nonTreeCellRenderer.get(GenericNodeType.UNKNOWN);
        }

        return renderer;
    }

    /**
     * @param node the corresponding node
     * @param isTreeCell indicates if the cell is tree cell or not
     * @return Returns the corresponding cell renderer
     */
    public KTableCellRenderer getCellRender(IZTestDataNode node, boolean isTreeCell) {
//        GenericNodeType type = node == null ? GenericNodeType.UNKNOWN : node.getNodeType();
        GenericNodeType type = GenericNodeType.UNKNOWN;
        KTableCellRenderer renderer = isTreeCell ? treeCellRenderer.get(type) : nonTreeCellRenderer.get(type);

        if (renderer == null) {
            renderer = isTreeCell ? treeCellRenderer.get(GenericNodeType.UNKNOWN) : nonTreeCellRenderer.get(GenericNodeType.UNKNOWN);
        }

        return renderer;
    }

    /**
     * @param node the corresponding node
     * @param isTreeCell indicates if the cell is tree cell or not
     * @return Returns the corresponding cell renderer
     */
    public KTableCellRenderer getCellRender(ITdoNode node, boolean isTreeCell) {
        GenericNodeType type = node == null ? GenericNodeType.UNKNOWN : node.getNodeType();

        if (node instanceof FloatingTdoNode) {
            return isTreeCell ? floatingNodeCellRender : nonTreeDashDotCellRenderer;
        }

        KTableCellRenderer renderer = isTreeCell ? treeCellRenderer.get(type) : nonTreeCellRenderer.get(type);

        if (renderer == null) {
            renderer = isTreeCell ? treeCellRenderer.get(GenericNodeType.UNKNOWN) : nonTreeCellRenderer.get(GenericNodeType.UNKNOWN);
        }

        return renderer;
    }

    /**
     * constructor
     */
    private RendererPool() {
        installRenderers();
    }

    private Map<GenericNodeType, KTableCellRenderer> nonTreeCellRenderer;
    private Map<GenericNodeType, KTableCellRenderer> treeCellRenderer;
    private KTableCellRenderer fixedCellRenderer;
    private KTableCellRenderer floatingNodeCellRender;
    private KTableCellRenderer nonTreeDashDotCellRenderer;

    private static HashMap<RGB, Color> colorMap;

    /**
     * Initializes all cell renderers.
     */
    private void installRenderers() {
        fixedCellRenderer = new FixedCellRenderer(DefaultCellRenderer.STYLE_PUSH
                | DefaultCellRenderer.INDICATION_SORT
                | DefaultCellRenderer.INDICATION_FOCUS
                | DefaultCellRenderer.INDICATION_CLICKED);

        treeCellRenderer = new HashMap<GenericNodeType, KTableCellRenderer>();
        nonTreeCellRenderer = new HashMap<GenericNodeType, KTableCellRenderer>();
        colorMap = new HashMap<RGB, Color>();

        IPreferenceStore store = Activator.getDefault().getPreferenceStore();
        RGB importColor = PreferenceConverter.getColor(store, PreferenceConstants.IMPORT_TYPE);
        RGB varColor = PreferenceConverter.getColor(store, PreferenceConstants.VAR_TYPE);
        RGB resColor = PreferenceConverter.getColor(store, PreferenceConstants.RES_TYPE);
        RGB setColor = PreferenceConverter.getColor(store, PreferenceConstants.SET_TYPE);
        RGB propColor = PreferenceConverter.getColor(store, PreferenceConstants.PROP_TYPE);

        TreeCellRenderer renderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        renderer.setBackground(getColor(importColor));
        treeCellRenderer.put(GenericNodeType.IMPORT, renderer);

        renderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        renderer.setBackground(getColor(varColor));
        treeCellRenderer.put(GenericNodeType.VAR, renderer);

        renderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        renderer.setBackground(getColor(resColor));
        treeCellRenderer.put(GenericNodeType.RES, renderer);

        renderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        renderer.setBackground(getColor(setColor));
        treeCellRenderer.put(GenericNodeType.SET, renderer);

        renderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        renderer.setBackground(getColor(propColor));
        treeCellRenderer.put(GenericNodeType.PROP, renderer);


        DefaultCellRenderer dRenderer = new DefaultCellRenderer(SWT.NONE);
        dRenderer.setBackground(getColor(importColor));
        nonTreeCellRenderer.put(GenericNodeType.IMPORT, dRenderer);

        dRenderer = new DefaultCellRenderer(SWT.NONE);
        dRenderer.setBackground(getColor(varColor));
        nonTreeCellRenderer.put(GenericNodeType.VAR, dRenderer);

        dRenderer = new DefaultCellRenderer(SWT.NONE);
        dRenderer.setBackground(getColor(resColor));
        nonTreeCellRenderer.put(GenericNodeType.RES, dRenderer);

        dRenderer = new DefaultCellRenderer(SWT.NONE);
        dRenderer.setBackground(getColor(setColor));
        nonTreeCellRenderer.put(GenericNodeType.SET, dRenderer);

        dRenderer = new DefaultCellRenderer(SWT.NONE);
        dRenderer.setBackground(getColor(propColor));
        nonTreeCellRenderer.put(GenericNodeType.PROP, dRenderer);

        // installed two unknown renderers
//        renderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
//        treeCellRenderer.put(GenericNodeType.UNKNOWN, renderer);
        GSTIconCellRender gstIconCellRender = new GSTIconCellRender(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        treeCellRenderer.put(GenericNodeType.UNKNOWN, gstIconCellRender);

        floatingNodeCellRender = new GSTDashDotIconTreeCellRender(DefaultCellRenderer.INDICATION_FOCUS_ROW);

        dRenderer = new DefaultCellRenderer(SWT.NONE);
        nonTreeCellRenderer.put(GenericNodeType.UNKNOWN, dRenderer);

        nonTreeDashDotCellRenderer = new GSTDashDotCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
    }

    private Color getColor(RGB rgb) {
        Color value = colorMap.get(rgb);
        if (value == null) {
            value = new Color(Display.getCurrent(), rgb);
            colorMap.put(rgb, value);
        }
        return value;
    }

    /**
     * Should be called when the system is close
     */
    public void disposeColors() {
        for (Color c : colorMap.values()) {
            c.dispose();
        }
    }

    /**
     * Resets the pool
     */
    public void reset() {
        nonTreeCellRenderer.clear();
        treeCellRenderer.clear();

        installRenderers();
    }
}
