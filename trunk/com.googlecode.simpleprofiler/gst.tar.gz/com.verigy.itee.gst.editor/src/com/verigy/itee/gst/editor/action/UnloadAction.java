/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import com.sun.star.uno.Exception;
import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.gst.explorer.ate.UDAccessor;

/**
 * @author alanlin
 */
public class UnloadAction implements IObjectActionDelegate {
	private static final String XML_TAG = "xml";
	private IFile selectFile;

	@Override
	public void run(IAction action) {
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			Object selObj = ((IStructuredSelection)selection).getFirstElement();
			if (selObj instanceof IFile) {
				selectFile = (IFile) selObj;
				
				if (!isXmlFile(selectFile)) {
					action.setEnabled(false);
				} else {
					action.setEnabled(true);
				}
			}
		} else {
			selectFile = null;
			action.setEnabled(false);
		}
	}

	private boolean isXmlFile(IFile file) {
		return true;
		//return file == null ? false : XML_TAG.equalsIgnoreCase(file.getFileExtension());
	}

	@Override
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		// TODO Auto-generated method stub
		
	}
}

