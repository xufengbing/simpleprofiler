/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.model;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.TdoNode;

/**
 * @author bennwang
 *
 */
public class FloatingTdoNode extends TdoNode {

    /**
     * @param parent Parent node
     */
    public FloatingTdoNode(IZTestDataNode parent) {
        super(parent, -1);
        this.type = GenericNodeType.UNKNOWN;
    }


    /**
     *
     */
    public void arrowUp(){
        int index = getParent().getChildren().indexOf(this);
        if(0 == index) {
            return;
        }
        getParent().getChildren().remove(this);
        ((ITdoNode)getParent()).addChild(this, index-1);
    }

    /**
    *
    */
   public void arrowDown(){
       int index = getParent().getChildren().indexOf(this);
       if(getParent().getChildren().size() == index + 1) {
           return;
       }
       getParent().getChildren().remove(this);
       ((ITdoNode)getParent()).addChild(this, index+1);
   }

   /**
    *
    */
   public void arrowLeft(){
       ITdoNode myparent = (ITdoNode)getParent();
       if(myparent.isRoot()) {
        return;
       }
       int parIndex = myparent.getParent().getChildren().indexOf(myparent);
       myparent.getChildren().remove(this);
       ((ITdoNode)myparent.getParent()).addChild(this, parIndex);
       this.parent = myparent.getParent();
   }

   /**
   *
   */
  public void arrowRight(){
      ITdoNode myparent = (ITdoNode)getParent();
      int index = myparent.getChildren().indexOf(this);
      //The first child
      if(0==index) {
          return;
      }
      ITdoNode preSibling = (ITdoNode)myparent.getChildren().get(index - 1);
      GenericNodeType siblingType = preSibling.getNodeType();
      //This type node can not has a child
      if(GenericNodeType.PROP == siblingType ||
              GenericNodeType.VAR == siblingType ||
              GenericNodeType.UNKNOWN == siblingType) {
        return;
      }
      //Inserted as the first child
      myparent.removeChild(this);
      preSibling.addChild(this, 0);
      this.parent = preSibling;

  }
    @Override
    protected void setNameToUDA(String name) {
        //Do nothing
    }

    @Override
    protected String getNameFromUDA() {
        //Do nothing
        return null;
    }

    @Override
    protected void setValueToUDA(String value) {
        //Do nothing
    }

    @Override
    protected String getValueFromUDA() {
        //Do nothing
        return null;
    }

    /**
     * Set the floating node to the type
     * @param type {@link GenericNodeType}
     */
    public void setNodeType(GenericNodeType type) {
        this.type = type;
    }
}
