/*******************************************************************************

 * Copyright (c) 2006, 2007 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.selection;

/**
 * @author alanlin
 */
public interface IInitializeSelectionSupport {
    /**
     * Initializes selection according to current focus.
     */
    public void initializeSelection();
}
