/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.progress.UIJob;

import com.verigy.itee.gst.editor.editors.KTabletreeBasedEditor;
import com.verigy.itee.gst.editor.ktable.model.IUdaObjectOperationSupport;
import com.verigy.itee.gst.editor.ktable.selection.IGSTSelectionProvider;
import com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement;
import com.verigy.itee.gst.editor.ktable.selection.SelectionType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;

/**
 * @author alanlin
 *
 */
public abstract class AbstractGSTAction implements IActionDelegate {
    protected static final char TAB = '\t';
    protected static final String PlatformLineDelimiter = System.getProperty("line.separator");
    protected static final String EMPTY = "";
	private static final long SCHEDULE_DELAY = 10;
	protected ISelection selection;

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(org.eclipse.jface.action.IAction, org.eclipse.jface.viewers.ISelection)
	 */
	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;

		onSelectionChange(action, selection);
	}

	protected void onSelectionChange(IAction action, ISelection selection2) {
		// do nothing
	}

	protected int getSizeOfSelectedElements() {
		if (selection instanceof StructuredSelection) {
			return ((StructuredSelection) selection).size();
		}

		return 0;
	}

	protected ISelection getSelection() {
		return selection;
	}

	protected ITdoNode getFirstSelectedNode() {
		if (selection != null && selection instanceof StructuredSelection) {
			StructuredSelection structuredSelection = (StructuredSelection) selection;

			IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement)structuredSelection.getFirstElement();

			return nodeSelection == null ? null : nodeSelection.getSelectedNode();
		}
		return null;
	}

	protected KTable getTable() {
       if (selection != null && selection instanceof StructuredSelection) {
            StructuredSelection structuredSelection = (StructuredSelection) selection;

            IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement)structuredSelection.getFirstElement();

            return nodeSelection == null ? null : nodeSelection.getTable();
        }
        return null;
	}

	protected ITdoNode[] getSelectedNodes() {
		if (selection != null && selection instanceof StructuredSelection) {
			StructuredSelection structuredSelection = (StructuredSelection) selection;

			Object[] data = structuredSelection.toArray();

			List<ITdoNode> nodes = new ArrayList<ITdoNode>();
			for (Object d : data) {
				if (d instanceof IGenericNodeSelectionElement) {
					nodes.add(((IGenericNodeSelectionElement)d).getSelectedNode());
				}
			}

			return nodes.toArray(new ITdoNode[nodes.size()]);
		}
		return new ITdoNode[0];
	}

	/**
	 * @return Returns true if the selection is continuous selection. Otherwise
	 * returns false. If there is only one element is selected, the method also
	 * returns true.
	 */
	protected boolean isContinuousSelection() {
       if (selection != null && selection instanceof StructuredSelection) {
            StructuredSelection structuredSelection = (StructuredSelection) selection;

            Object[] data = structuredSelection.toArray();
            int min = Integer.MAX_VALUE;
            int max = -1;
            int[] allIndexs = new int[data.length];
            int i = 0;
            for (Object d : data) {
                if (d instanceof IGenericNodeSelectionElement) {
                    int rowIndex = ((IGenericNodeSelectionElement) d).getModelRowIndex();
                    allIndexs[i++] = rowIndex;

                    if (min > rowIndex) {
                        min = rowIndex;
                    }
                    if (max < rowIndex) {
                        max = rowIndex;
                    }
                }
            }

            int length = max - min + 1;
            return length == data.length;
        }
	    return true;
	}

	/**
	 * @return Returns true if the selection is self contained otherwise returns
	 * false.
	 */
	protected boolean isAllChildrenInSelection() {
       if (selection != null && selection instanceof StructuredSelection) {
            StructuredSelection structuredSelection = (StructuredSelection) selection;

            Object[] data = structuredSelection.toArray();
            Set<ITdoNode> allSelectedNodes = new HashSet<ITdoNode>();
            for (Object d : data) {
                if (d instanceof IGenericNodeSelectionElement) {
                    // collect all nodes
                    allSelectedNodes.add(((IGenericNodeSelectionElement) d).getSelectedNode());
                }
            }

            for (ITdoNode d : allSelectedNodes) {
                for (IZTestDataNode z : d.getChildren()) {
                    if (!allSelectedNodes.contains(z)) {
                        return false;
                    }
                }
            }
        }
        return true;
	}

	protected boolean isTdoObjectInClipboard() {
        Object content = ClipboardUtil.getClipboard().getContents(
                GenericNodeTransfer.getInstance());
        Map<String, ITdoNode> map = new HashMap<String, ITdoNode>();
        if (content instanceof List<?>) {
            List<?> list = (List<?>) content;
            for (int i = 0; i < list.size(); i++) {
                Object listObj = list.get(i);
                if (listObj instanceof String) {
                    String[] fields = ((String)listObj).split(GenericNodeTransfer.FIELD_SEPARATOR);
                    if (fields.length == 4) {
                        return true;
                    }
                }
            }
        }

        return false;
	}

    protected boolean isObjectSelectionMode() {
        if (selection != null && selection instanceof StructuredSelection) {
            StructuredSelection structuredSelection = (StructuredSelection) selection;
            Object element = structuredSelection.getFirstElement();

            if (element instanceof IGenericNodeSelectionElement) {
                IGenericNodeSelectionElement tdoSelectionElem = (IGenericNodeSelectionElement) element;
                SelectionType type = tdoSelectionElem.getSelectionType();
                if (SelectionType.SINGLE_WHOLE_ROW.equals(type) || SelectionType.MULTI_WHOLE_ROW.equals(type)) {
                    return true;
                } else {
                    KTable table = tdoSelectionElem.getTable();
                    if (table != null) {
                        Point[] cellPoints = table.getCellSelection();

                        boolean sameColumn = checkInSameColumn(cellPoints);
                        if (sameColumn && cellPoints[0].x == 1) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

	protected void refreshKTable() {
		if (selection != null && selection instanceof StructuredSelection) {
			StructuredSelection structuredSelection = (StructuredSelection) selection;

			IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement)structuredSelection.getFirstElement();

			final KTable table = nodeSelection.getTable();
			final IEditorPart editor = nodeSelection.getEditor();
			if (table != null && !table.isDisposed()) {
				KTableModel model = table.getModel();

				if (model instanceof IUdaObjectOperationSupport) {
					((IUdaObjectOperationSupport) model).refreshKTableDataModel();
				}

				UIJob job = new UIJob("Refreshing Table") {

					@Override
					public IStatus runInUIThread(IProgressMonitor monitor) {
						table.redraw();

						reSelect(table, editor);

						return Status.OK_STATUS;
					}
				};

				job.schedule(SCHEDULE_DELAY);
			}
		}
	}

	/**
	 * Since ktable will not fire a new selection event if the current cell
	 * is already selected. We need to explicitly trigger again the selection event.
	 * @param table
	 */
	protected void reSelect(KTable table, IEditorPart editor) {
		if (editor != null) {
			ISelectionProvider provider = editor.getEditorSite().getSelectionProvider();

			if (provider instanceof IGSTSelectionProvider) {
				((IGSTSelectionProvider) provider).reselectCell(table);
			}
		}
	}


	protected void updateDirtyFlag(boolean dirty) {
		if (selection != null && selection instanceof StructuredSelection) {
			StructuredSelection structuredSelection = (StructuredSelection) selection;

			IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement)structuredSelection.getFirstElement();

			IEditorPart editor = nodeSelection.getEditor();
			if (editor instanceof KTabletreeBasedEditor) {
				 ((KTabletreeBasedEditor) editor).setDirty(dirty);

			}
		}
	}

    /**
     * Checks if all selections are in same column.
     * @param selectedPoints all selections to be checked
     * @return Returns true if the given selections are all in same column,
     * otherwise returns false;
     */
    private boolean checkInSameColumn(Point[] selectedPoints) {
        boolean isInSameColumn = true;
        if (selectedPoints.length > 0) {
            int columnIdx = selectedPoints[0].x;
            for (int i = 1; i < selectedPoints.length; i++) {
                if (selectedPoints[i].x != columnIdx) {
                    isInSameColumn = false;
                }
            }
        }
        return isInSameColumn;
    }
}
