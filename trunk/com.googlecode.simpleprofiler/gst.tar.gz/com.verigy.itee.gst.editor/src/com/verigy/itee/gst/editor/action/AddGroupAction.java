package com.verigy.itee.gst.editor.action;
import org.eclipse.jface.action.IAction;


/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/

/**
 * @author alanlin
 *
 */
public class AddGroupAction extends AbstractUpdatableAction {

    /**
     * 
     */
    public AddGroupAction() {
        super();
    }

    @Override
    protected boolean doRun(IAction action) {
        // TODO Auto-generated method stub
        return false;
    }

}
