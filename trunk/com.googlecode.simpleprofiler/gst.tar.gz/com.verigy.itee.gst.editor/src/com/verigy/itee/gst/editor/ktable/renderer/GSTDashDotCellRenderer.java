/*******************************************************************************

 * Copyright (c) 2006, 2007 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.renderer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

import de.kupzog.ktable.KTableModel;
import de.kupzog.ktable.SWTX;
import de.kupzog.ktable.renderers.DefaultCellRenderer;

/**
 * Dash dot boundary text cell renderer
 *
 * @author Simon Zhou
 */
public class GSTDashDotCellRenderer extends DefaultCellRenderer {

    private int lineSytle = SWT.LINE_DASHDOT;

    private int lineWidth = 1;

    private Color boundaryColor = Display.getDefault().getSystemColor(SWT.COLOR_RED);

    /**
     * Creates a cellrenderer that prints text in the cell.
     *
     * @param style
     *            Honored style bits are:<br> - INDICATION_FOCUS makes the cell that has
     *            the focus have a deep blue background color and a selection border.<br> -
     *            INDICATION_FOCUS_ROW makes the cell show a selection indicator as it is
     *            often seen in row selection mode. A deep blue background and white
     *            content.<br> - INDICATION_COMMENT lets the renderer paint a small
     *            triangle to the right top corner of the cell.<br> - SWT.BOLD Makes the
     *            renderer draw bold text.<br> - SWT.ITALIC Makes the renderer draw
     *            italic text<br>
     * @param lineSytle
     *            The boundary line style, which must be one of the constants
     *            <code>SWT.LINE_SOLID</code>, <code>SWT.LINE_DASH</code>,
     *            <code>SWT.LINE_DOT</code>, <code>SWT.LINE_DASHDOT</code> or
     *            <code>SWT.LINE_DASHDOTDOT</code>.
     *
     * @param lineWidth
     *            The boundary line width
     * @param boundaryColor
     *            The boundary color
     */
    public GSTDashDotCellRenderer(int style, int lineSytle, int lineWidth,
            Color boundaryColor) {
        super(style);
        this.lineSytle = lineSytle;
        this.lineWidth = lineWidth;
        this.boundaryColor = boundaryColor;
    }

    /**
     * Creates a cellrenderer that prints text in the cell.
     *
     * @param style
     *            Honored style bits are:<br> - INDICATION_FOCUS makes the cell that has
     *            the focus have a deep blue background color and a selection border.<br> -
     *            INDICATION_FOCUS_ROW makes the cell show a selection indicator as it is
     *            often seen in row selection mode. A deep blue background and white
     *            content.<br> - INDICATION_COMMENT lets the renderer paint a small
     *            triangle to the right top corner of the cell.<br> - SWT.BOLD Makes the
     *            renderer draw bold text.<br> - SWT.ITALIC Makes the renderer draw
     *            italic text<br>
     */
    public GSTDashDotCellRenderer(int style) {
        super(style);
    }

    /**
     * Returns the optimal width of the given cell (used by column resizing)
     *
     * @param col
     *            The column index
     * @param row
     *            The row index
     * @param content
     *            The cell content
     * @param fixed
     *            If the cell is fix cell
     * @return Return the optimal width.
     */
    @Override
    public int getOptimalWidth(GC gc, int col, int row, Object content, boolean fixed,
            KTableModel model) {
        return SWTX.getCachedStringExtent(gc, content.toString()).x + 20;
    }

    /**
     * This method is called from KTable to draw a table cell.
     * <p>
     *
     * @param gc
     *            The gc to draw on
     * @param rect
     *            The coordinates and size of the cell
     * @param col
     *            The column
     * @param row
     *            The row
     * @param content
     *            The content of the cell
     * @param focus
     *            If the cell is selected
     * @param fixed
     *            If the cell is fix cell
     * @param clicked
     *            If the cell is currently clicked
     * @param model
     *            The KTableModel
     */
    @Override
    public void drawCell(GC gc, Rectangle rect, int col, int row, Object content,
            boolean focus, boolean fixed, boolean clicked, KTableModel model) {
        applyFont(gc);

        if (content == null) {
            content = "";
        }

        Rectangle boundaryRect = rect;
        if (focus && (m_Style & INDICATION_FOCUS) != 0) {
            rect = drawDefaultSolidCellLine(gc, rect, COLOR_LINE_LIGHTGRAY,
                    COLOR_LINE_LIGHTGRAY);
            rect = getContentRect(rect);

            drawCellContent(gc, rect, boundaryRect, content.toString(), null, fgColorInFocus,
                    bgColorInFocus);
            gc.drawFocus(boundaryRect.x, boundaryRect.y, boundaryRect.width, boundaryRect.height);
        } else if (focus && (m_Style & INDICATION_FOCUS_ROW) != 0) {
            rect = drawDefaultSolidCellLine(gc, rect, bgColorInFocus, bgColorInFocus);
            rect = getContentRect(rect);

            drawCellContent(gc, rect, boundaryRect, content.toString(), null, fgColorInFocus,
                    bgColorInFocus);
        } else {
            rect = drawDefaultSolidCellLine(gc, rect, COLOR_LINE_LIGHTGRAY,
                    COLOR_LINE_LIGHTGRAY);
            rect = getContentRect(rect);

            drawCellContent(gc, rect, boundaryRect, content.toString(), null, getForeground(),
                    getBackground());
        }

        // draw dash-dot boundary
        drawDashDotBoundary(gc, boundaryRect);

        if ((m_Style & INDICATION_COMMENT) != 0) {
            drawCommentSign(gc, rect);
        }

        resetFont(gc);
    }

    protected void drawCellContent(GC gc, Rectangle rect, Rectangle boundaryRect, String text, Image img,
            Color textColor, Color backColor) {
        // clear background and paint content:
        gc.setBackground(backColor);
        gc.setForeground(textColor);
        gc.fillRectangle(boundaryRect);
        SWTX.drawTextImage(gc, text, getAlignment(), img, getAlignment(),
                rect.x + 2/* +3 */, rect.y + 2, rect.width - 6, rect.height - 4);
    }

    /**
     * Set comment indication.
     *
     * @param value
     *            If true, the comment sign is painted. Else it is omitted
     */
    public void setCommentIndication(boolean value) {
        if (value) {
            m_Style = m_Style | INDICATION_COMMENT;
        } else {
            m_Style = m_Style & ~INDICATION_COMMENT;
        }
    }

    /**
     * Gets boundary color.
     *
     * @return Returns the boundary color.
     */
    public Color getBoundaryColor() {
        return boundaryColor;
    }

    /**
     * Sets boundary color.
     *
     * @param boundaryColor
     *            The boundary color to set.
     */
    public void setBoundaryColor(Color boundaryColor) {
        this.boundaryColor = boundaryColor;
    }

    /**
     * Gets the boundary line style, which will be one of the constants
     * <code>SWT.LINE_SOLID</code>, <code>SWT.LINE_DASH</code>,
     * <code>SWT.LINE_DOT</code>, <code>SWT.LINE_DASHDOT</code> or
     * <code>SWT.LINE_DASHDOTDOT</code>.
     *
     * @return Returns the boundary line sytle.
     */
    public int getLineSytle() {
        return lineSytle;
    }

    /**
     * Sets the boundary line style, which must be one of the constants
     * <code>SWT.LINE_SOLID</code>, <code>SWT.LINE_DASH</code>,
     * <code>SWT.LINE_DOT</code>, <code>SWT.LINE_DASHDOT</code> or
     * <code>SWT.LINE_DASHDOTDOT</code>.
     *
     * @param lineSytle
     *            The boundary line sytle to set.
     */
    public void setLineSytle(int lineSytle) {
        this.lineSytle = lineSytle;
    }

    /**
     * Gets the boundary line width.
     *
     * @return Returns the line width.
     */
    public int getLineWidth() {
        return lineWidth;
    }

    /**
     * Sets the boundary line width.
     *
     * @param lineWidth
     *            The line width to set.
     */
    public void setLineWidth(int lineWidth) {
        this.lineWidth = lineWidth;
    }

    /**
     * Draws dash dot boundary.
     *
     * @param gc
     *            The GC object
     * @param rect
     *            The cell rectangle
     */
    private void drawDashDotBoundary(GC gc, Rectangle rect) {
        int margin = 1;

        // draw top horizontal boundary line
        drawHorizontalBoundaryLine(gc, rect.x + margin, rect.x + rect.width - margin,
                rect.y + margin);

        // draw down horizontal boundary line
        drawHorizontalBoundaryLine(gc, rect.x + margin, rect.x + rect.width - margin,
                rect.y + rect.height - margin - 1);

        // draw left vertical boundary line
        drawVerticalBoundaryLine(gc, rect.y + margin, rect.y + rect.height - margin,
                rect.x + margin);

        // draw right vertical boundary line
        drawVerticalBoundaryLine(gc, rect.y + margin, rect.y + rect.height - margin,
                rect.x + rect.width - margin - 1);
    }

    /*
     * Draws vertical boundary line.
     */
    private void drawVerticalBoundaryLine(GC gc, int y1, int y2, int x) {
        Color originalColor = gc.getForeground();
        int originalLineStyle = gc.getLineStyle();
        int originalLineWidth = gc.getLineWidth();

        gc.setForeground(boundaryColor);
        gc.setLineStyle(lineSytle);
        gc.setLineWidth(lineWidth);
        gc.drawLine(x, y1, x, y2);

        gc.setForeground(originalColor);
        gc.setLineStyle(originalLineStyle);
        gc.setLineWidth(originalLineWidth);
    }

    /*
     * Draws horizontal boundary line.
     */
    private void drawHorizontalBoundaryLine(GC gc, int x1, int x2, int y) {
        Color originalColor = gc.getForeground();
        int originalLineStyle = gc.getLineStyle();
        int originalLineWidth = gc.getLineWidth();

        gc.setForeground(boundaryColor);
        gc.setLineStyle(lineSytle);
        gc.setLineWidth(lineWidth);
        gc.drawLine(x1, y, x2, y);

        gc.setForeground(originalColor);
        gc.setLineStyle(originalLineStyle);
        gc.setLineWidth(originalLineWidth);
    }

    /**
     * Get the content rectangle.
     *
     * @param rect
     *            The rectangle to be adjust
     * @return Renturn the content rectangle
     */
    private Rectangle getContentRect(Rectangle rect) {
        final int margin = 1;

        return new Rectangle(rect.x + margin, rect.y + margin, rect.width - (margin * 2),
                rect.height - (margin * 2) - 1);
    }
}