/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.eclipse.core.runtime.Assert;
import org.eclipse.swt.dnd.ByteArrayTransfer;
import org.eclipse.swt.dnd.TransferData;

import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 *
 *
 * @author bennwang
 *
 */
// TODO refactored by benny
public class GenericNodeTransfer extends ByteArrayTransfer {

    /**
     * the path separator
     */
    public static final String PATH_SEPARATOR = "/";

    /**
     * the field separator
     */
    public static final String FIELD_SEPARATOR = ";";

    private static GenericNodeTransfer instance = new GenericNodeTransfer();

    private static final String GENERICNODETYPE = "verigy_gst_genericnode";

    private static final int GENERICNODETYPEID = registerType(GENERICNODETYPE);

    /**
     * Default constructor
     */
    private GenericNodeTransfer() {
        // do nothing
    }

    /**
     * @return {@link GenericNodeTransfer}
     */
    public static GenericNodeTransfer getInstance() {
        return instance;
    }

    /**
     * @param tdoNode the tdo node
     * @return Returns the constructed string
     */
    public static String constructStringFor(ITdoNode tdoNode) {
        Assert.isNotNull(tdoNode);
        StringBuilder sb = new StringBuilder(tdoNode.getName());
        sb.append(FIELD_SEPARATOR);
        sb.append(tdoNode.getValue());
        sb.append(FIELD_SEPARATOR);
        sb.append(tdoNode.getNodeType().toString());
        sb.append(FIELD_SEPARATOR);
        sb.append(getPath(tdoNode));

        return sb.toString();
    }

    /**
     * @param tdoNode the tdo node
     * @return Returns the path of corresponding tdo node
     */
    public static String getPath(ITdoNode tdoNode) {
        Assert.isNotNull(tdoNode);
        StringBuilder sb = new StringBuilder();
        Stack<String> stack = new Stack<String>();
        stack.push(tdoNode.getName());
        while (tdoNode.getParent() != null) {
            tdoNode = (ITdoNode)tdoNode.getParent();
            stack.push(tdoNode.getName());
        }

        int length = stack.size();
        for (int i = 0; i < length; i++) {
            sb.append(stack.pop());
            if (i != length -1) {
                sb.append(PATH_SEPARATOR);
            }
        }
        return sb.toString();
    }

    @Override
    protected void javaToNative(Object object, TransferData transferData) {
        if (!(object instanceof ITdoNode[])) {
            return;
        }

        if (isSupportedType(transferData)) {
            ITdoNode[] tdoNodes = (ITdoNode[]) object;
            try {
                // write data to a byte array and then ask super to convert to pMedium
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                DataOutputStream writeOut = new DataOutputStream(out);
                for (int i = 0, length = tdoNodes.length; i < length; i++) {
                    String contructedStr = constructStringFor(tdoNodes[i]);
                    byte[] buffer = contructedStr.getBytes();
                    writeOut.writeInt(buffer.length);
                    writeOut.write(buffer);
                }
                byte[] buffer = out.toByteArray();
                writeOut.close();

                super.javaToNative(buffer, transferData);

            } catch (IOException e) {
                // TODO By Benny
            }
        }
    }

    @Override
    protected Object nativeToJava(TransferData transferData) {
        if (isSupportedType(transferData)) {

            byte[] buffer = (byte[]) super.nativeToJava(transferData);
            if (buffer == null) {
                return null;
            }

            List<String> nodeList = new ArrayList<String>();
            try {
                ByteArrayInputStream in = new ByteArrayInputStream(buffer);
                DataInputStream readIn = new DataInputStream(in);
                while (readIn.available() > 0) {
                    int size = readIn.readInt();
                    byte str[] = new byte[size];
                    readIn.read(str);
                    nodeList.add(new String(str));
                }
                readIn.close();
            } catch (IOException ex) {
                return null;
            }
            return nodeList;
        }

        return null;
    }

    @Override
    protected String[] getTypeNames() {
        return new String[] { GENERICNODETYPE };
    }

    @Override
    protected int[] getTypeIds() {
        return new int[] { GENERICNODETYPEID };
    }
}
