/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.gsttable;

import java.util.ArrayList;

import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;

import com.verigy.itee.ktabletree.KTableTree;

/**
 * @author alanlin
 */
public class GSTTableTree extends KTableTree implements IHoveredCellChangeSupport {
    protected ArrayList<KHoverCellChangeListener> hoveredCellChangeListener;
    protected ArrayList<KMouseClickedListener> mouseClickedListener;
    protected Point hoveredCell;
	
	public GSTTableTree(Composite parent, int style, int extStyle) {
		super(parent, style, extStyle);
		
		hoveredCellChangeListener = new ArrayList<KHoverCellChangeListener>(10);
		mouseClickedListener = new ArrayList<KMouseClickedListener>(10);
		hoveredCell = new Point(-1, -1);
	}

	@Override
	public void addHoveredCellChangeListener(KHoverCellChangeListener listener) {
		hoveredCellChangeListener.add(listener);
	}

	public void addMouseClickedListener(KMouseClickedListener listener) {
		mouseClickedListener.add(listener);
	}
	
	public Point getHoveredCell() {
		return hoveredCell;
	}

	@Override
	public void removeHoveredCellChangedListener(
			KHoverCellChangeListener listener) {
    	hoveredCellChangeListener.remove(listener);
	}
	
	public void removeMouseClickedListener(KMouseClickedListener l) {
		mouseClickedListener.remove(l);
	}
	
	
    protected void fireHoveredCellChange(Point oldCell, Point newCell) {
		for (int i = 0; i < hoveredCellChangeListener.size(); i++) {
			(hoveredCellChangeListener.get(i)).onHoveredCellChange(oldCell.x, oldCell.y,
					newCell.x, newCell.y, this);
		}
	}
    
    protected void fireMouseClickedListener(Point cell, int stateMask) {
    	for (int i = 0; i < mouseClickedListener.size(); i++) {
    		mouseClickedListener.get(i).onMouseClicked(cell.x, cell.y, stateMask);
    	}
    }
    
	@Override
	protected void onMouseMove(MouseEvent e) {
		super.onMouseMove(e);

		Point cur = calcNonSpanColumnNum(e.x, e.y);
		if (!hoveredCell.equals(cur)) {
			Point tmp = hoveredCell;
			hoveredCell = cur;

			fireHoveredCellChange(tmp, hoveredCell);
		}
	}
	
	@Override
	protected void onMouseDown(MouseEvent e) {
		super.onMouseDown(e);
		
		Point cell = calcNonSpanColumnNum(e.x, e.y);
		
		fireMouseClickedListener(cell, e.stateMask);
	}
}
