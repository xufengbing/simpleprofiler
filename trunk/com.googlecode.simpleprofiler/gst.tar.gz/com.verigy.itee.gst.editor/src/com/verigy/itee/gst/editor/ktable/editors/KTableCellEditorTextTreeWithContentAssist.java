/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.editors;

import org.eclipse.jface.fieldassist.ContentProposalAdapter;
import org.eclipse.jface.fieldassist.IContentProposalListener2;
import org.eclipse.jface.fieldassist.IContentProposalProvider;
import org.eclipse.jface.fieldassist.IControlContentAdapter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IWorkbenchCommandConstants;
import org.eclipse.ui.fieldassist.ContentAssistCommandAdapter;

import com.verigy.itee.gst.explorer.utils.FuncUtil;
import com.verigy.itee.ktabletree.editors.KTableCellEditorTextTree;

import de.kupzog.ktable.IKTableFontProvider;

/**
 * @author alanlin
 *
 */
public class KTableCellEditorTextTreeWithContentAssist extends KTableCellEditorTextTree {

    private final IContentProposalProvider contentProposalProvider;
    private final int proposalAcceptanceStyle = ContentProposalAdapter.PROPOSAL_INSERT;
    private boolean isContentAssistOpened;

    // this listener sets the flag
    IContentProposalListener2 proposalListener = new IContentProposalListener2() {
        @Override
        public void proposalPopupClosed(ContentProposalAdapter adapter) {
            isContentAssistOpened = false;
        }

        @Override
        public void proposalPopupOpened(ContentProposalAdapter adapter) {
            isContentAssistOpened = true;
        }
    };

    private final FocusListener focusListener = new FocusAdapter() {
        @Override
        public void focusLost(FocusEvent e) {
            if(!isContentAssistDialogOpened()) { // content assist dialog was not opened
                close(true);
            }
        }
    };

    /**
     * @param candidats all candidates
     * @param fontProvider the font provider
     */
    public KTableCellEditorTextTreeWithContentAssist(String[] candidats, IKTableFontProvider fontProvider) {
        super(fontProvider);
        this.contentProposalProvider = new ExpressionContentProposalProvider(candidats);
    }

    /**
     * The only constructor.
     * @param contentProposalProvider The {@linkplain IContentProposalProvider} which
     * provides the all proposals.
     * @param fontProvider The {@linkplain IKTableFontProvider}.
     */
    public KTableCellEditorTextTreeWithContentAssist(IContentProposalProvider contentProposalProvider, IKTableFontProvider fontProvider) {
        super(fontProvider);
        this.contentProposalProvider = contentProposalProvider;
    }

    @Override
    protected Control createControl() {
        Control control = super.createControl();
        control.addFocusListener(focusListener);

        IControlContentAdapter contentAdapter = new TextContentAdapter2();
        if(contentProposalProvider != null) {
            ContentAssistCommandAdapter commandAdapter = new ContentAssistCommandAdapter(
                    control, contentAdapter, contentProposalProvider,
                    IWorkbenchCommandConstants.EDIT_CONTENT_ASSIST, null, true);

            commandAdapter.setProposalAcceptanceStyle(proposalAcceptanceStyle);
            commandAdapter.addContentProposalListener(proposalListener);
            commandAdapter.setAutoActivationCharacters(FuncUtil.delimited);
        }

        return control;
    }

    @Override
    public void close(boolean save) {
        if (m_Text != null) {
            m_Text.removeFocusListener(focusListener);
        }

        super.close(save);
    }

   /**
    * Checks whether the content assist dialog is opened or not.
    *
    * @return Return true if it is opened, otherwise return false
    */
   private boolean isContentAssistDialogOpened() {
       return isContentAssistOpened;
   }

    /**
     * Overrides the onTraverse() method
     */
    @Override
    protected void onTraverse(TraverseEvent e) {
        if (!isContentAssistOpened) {
            super.onTraverse(e);
        }
    }

    @Override
    protected void onKeyPressed(KeyEvent e) {
        if (!isContentAssistOpened) {
            super.onKeyPressed(e);

            if (e.character == SWT.ESC) {
                e.doit = false;
            }
        }
    }
}
