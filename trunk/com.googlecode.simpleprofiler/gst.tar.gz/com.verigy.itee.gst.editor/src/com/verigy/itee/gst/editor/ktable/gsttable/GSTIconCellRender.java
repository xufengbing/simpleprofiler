/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.renderer;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jface.resource.ImageDescriptor;

import com.verigy.itee.gst.editor.Activator;
import com.verigy.itee.ktabletree.renderers.TreeCellRenderer;

import de.kupzog.ktable.KTableFontProvider;
import de.kupzog.ktable.renderers.OverlayImageDescriptor;

/**
 * @author alanlin
 *
 */
public class GSTIconCellRender extends TreeCellRenderer {

    /** The image descriptors. */
    private final Map<String, OverlayImageDescriptor> imageDescriptors;

    /**
     * Default constructor
     * @param style the style
     */
    public GSTIconCellRender(int style) {
        super(style, new KTableFontProvider());

        imageDescriptors = new HashMap<String, OverlayImageDescriptor>();
    }

    @Override
    protected OverlayImageDescriptor getOverlayImageDescriptor(Object content, int col,
            int row) {
        String key = content.toString();
        OverlayImageDescriptor overlayImageDescriptor = imageDescriptors.get(key);

        if (overlayImageDescriptor == null) {
            ImageDescriptor topRightImageDescriptor = null;

            if (hasError(content)) {
                topRightImageDescriptor = Activator.getDefault()
                        .getImageDescriptor("icons/full/obj16/executed_ov.gif");
            }

            overlayImageDescriptor = new OverlayImageDescriptor(
                    getIconImageDescriptor(content), new ImageDescriptor[][] {
                            { null }, { null },
                            { topRightImageDescriptor } });

            imageDescriptors.put(key, overlayImageDescriptor);
        }
        return overlayImageDescriptor;
    }

    private boolean hasError(Object content) {
        return false;
    }

    /**
     * Gets the icon image descriptor.
     *
     * @param iconType
     *            The icon type
     * @return The image descriptor
     */
    private ImageDescriptor getIconImageDescriptor(Object content) {
//        if (iconType == IconType.Pattern) {
//            return Activator.getImageDescriptor("icons/full/obj16/pattern.png");
//        } else if (iconType == IconType.Burst) {
//            return Activator.getImageDescriptor("icons/full/obj16/burst.png");
//        } else if (iconType == IconType.PatternNotLoaded) {
//            return Activator
//                    .getImageDescriptor("icons/full/obj16/pattern_not_loaded.png");
//        } else if (iconType == IconType.BurstNotLoaded) {
//            return Activator.getImageDescriptor("icons/full/obj16/burst_not_loaded.png");
//        }
//        throw new IllegalStateException("unknown type");
        return null;
    }
}
