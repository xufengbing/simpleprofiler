package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.actions.OpenFileAction;

import com.verigy.itee.gst.explorer.utils.OpenEditorUtil;

public class RealOpenAction implements IObjectActionDelegate {

	private ISelection selection;

	public RealOpenAction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		// TODO Auto-generated method stub

	}

	@Override
	public void run(IAction action) {
		if (selection != null && selection instanceof IStructuredSelection) {
			Object selectedObj = ((IStructuredSelection) selection).getFirstElement();
			
			if (selectedObj instanceof String) {
				OpenEditorUtil.openLoadedTDE((String) selectedObj);
			}
		}
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
		// TODO Auto-generated method stub

	}
}
