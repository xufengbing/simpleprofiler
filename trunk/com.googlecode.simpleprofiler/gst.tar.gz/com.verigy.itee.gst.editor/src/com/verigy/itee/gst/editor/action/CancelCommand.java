/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import com.verigy.itee.gst.editor.model.FloatingTdoNode;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

/**
 * @author bennwang
 *
 */
public class CancelCommand extends AbstractGSTHanlder {


    @Override
    protected ITdoNode operate(ITdoNode node) {
        //If the node is the root node in TDE
        if((!(node instanceof FloatingTdoNode)) || node.isRoot()) {
            return node;
        }

        IZTestDataNode parent = node.getParent();
        parent.getChildren().remove(node);
        if(parent instanceof ITdoNode) {
            return (ITdoNode)parent;
        }
        return node;
    }
}
