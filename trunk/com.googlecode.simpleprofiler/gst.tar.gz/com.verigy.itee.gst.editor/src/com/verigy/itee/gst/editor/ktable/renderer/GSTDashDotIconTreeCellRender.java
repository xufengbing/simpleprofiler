/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.renderer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

import de.kupzog.ktable.KTableModel;

/**
 * @author alanlin
 *
 */
public class GSTDashDotIconTreeCellRender extends GSTIconCellRender {
    private final int lineSytle = SWT.LINE_DASHDOT;

    private final int lineWidth = 1;

    private final Color boundaryColor = Display.getDefault().getSystemColor(SWT.COLOR_RED);

    /**
     * @param style the style
     */
    public GSTDashDotIconTreeCellRender(int style) {
        super(style);
    }

    @Override
    public void drawCell(GC gc, Rectangle rect, int col, int row, Object content,
            boolean focus, boolean fixed, boolean clicked, KTableModel model) {

        applyFont(gc);

        /*int topWidth = 1; int bottomWidth=1; int leftWidth=1; int rightWidth=1;
         rect = drawSolidCellLines(gc, rect, vBorderColor, hBorderColor,
         topWidth, bottomWidth, leftWidth, rightWidth);
         */
        Image img = getImage(content, row, col);

        Rectangle boundaryRect = rect;
        // draw focus sign:
        if (focus && (m_Style & INDICATION_FOCUS)!=0) {
            // draw content:
            rect = drawDefaultSolidCellLine(gc, rect, COLOR_LINE_LIGHTGRAY, COLOR_LINE_LIGHTGRAY);
            drawCellContent(gc, rect, content.toString(), img, fgColorInFocus, bgColorInFocus, model, col, row);
            gc.drawFocus(rect.x, rect.y, rect.width, rect.height);

        } else if (focus && (m_Style & INDICATION_FOCUS_ROW)!=0) {
            rect = drawDefaultSolidCellLine(gc, rect, bgColorInFocus, bgColorInFocus);
            // draw content:
            drawCellContent(gc, rect, content.toString(), img, fgColorInFocus, bgColorInFocus, model, col, row);
        } else {
            rect = drawDefaultSolidCellLine(gc, rect, COLOR_LINE_LIGHTGRAY, COLOR_LINE_LIGHTGRAY);
            // draw content:
            drawCellContent(gc, rect, content.toString(), img, getForeground(content,
                    col, row), getBackground(), model, col, row);
        }

        // draw dash-dot boundary
        drawDashDotBoundary(gc, boundaryRect);

        if ((m_Style & INDICATION_COMMENT)!=0) {
            drawCommentSign(gc, rect);
        }

        resetFont(gc);
    }


    /**
     * Draws dash dot boundary.
     *
     * @param gc
     *            The GC object
     * @param rect
     *            The cell rectangle
     */
    private void drawDashDotBoundary(GC gc, Rectangle rect) {
        int margin = 1;

        // draw top horizontal boundary line
        drawHorizontalBoundaryLine(gc, rect.x + margin, rect.x + rect.width - margin,
                rect.y + margin);

        // draw down horizontal boundary line
        drawHorizontalBoundaryLine(gc, rect.x + margin, rect.x + rect.width - margin,
                rect.y + rect.height - margin - 1);

        // draw left vertical boundary line
        drawVerticalBoundaryLine(gc, rect.y + margin, rect.y + rect.height - margin,
                rect.x + margin);

        // draw right vertical boundary line
        drawVerticalBoundaryLine(gc, rect.y + margin, rect.y + rect.height - margin,
                rect.x + rect.width - margin - 1);
    }


    /*
     * Draws vertical boundary line.
     */
    private void drawVerticalBoundaryLine(GC gc, int y1, int y2, int x) {
        Color originalColor = gc.getForeground();
        int originalLineStyle = gc.getLineStyle();
        int originalLineWidth = gc.getLineWidth();

        gc.setForeground(boundaryColor);
        gc.setLineStyle(lineSytle);
        gc.setLineWidth(lineWidth);
        gc.drawLine(x, y1, x, y2);

        gc.setForeground(originalColor);
        gc.setLineStyle(originalLineStyle);
        gc.setLineWidth(originalLineWidth);
    }

    /*
     * Draws horizontal boundary line.
     */
    private void drawHorizontalBoundaryLine(GC gc, int x1, int x2, int y) {
        Color originalColor = gc.getForeground();
        int originalLineStyle = gc.getLineStyle();
        int originalLineWidth = gc.getLineWidth();

        gc.setForeground(boundaryColor);
        gc.setLineStyle(lineSytle);
        gc.setLineWidth(lineWidth);
        gc.drawLine(x1, y, x2, y);

        gc.setForeground(originalColor);
        gc.setLineStyle(originalLineStyle);
        gc.setLineWidth(originalLineWidth);
    }
}
