package com.verigy.itee.gst.editor.action;

import com.verigy.itee.gst.editor.model.FloatingTdoNode;
import com.verigy.itee.gst.explorer.ate.ITdoNode;


/**
 * @author bennwang
 *
 */
public class ChangeLevelCommand extends AbstractGSTHanlder {

    @Override
    protected ITdoNode operate(ITdoNode node) {
        if(!(node instanceof FloatingTdoNode)) {
            return node;
        }
        FloatingTdoNode selectedNode = (FloatingTdoNode)node;
        String parameter = (String)getParameters().get("com.verigy.itee.gst.editor.commandpara.direction");
        if(null == parameter) {
            return node;
        }
        if("UP".equals(parameter)) {
            selectedNode.arrowUp();
        }else if("DOWN".equals(parameter)) {
            selectedNode.arrowDown();
        }else if("LEFT".equals(parameter)) {
            selectedNode.arrowLeft();
        }else if("RIGHT".equals(parameter)) {
            selectedNode.arrowRight();
        }
        return selectedNode;
    }
}
