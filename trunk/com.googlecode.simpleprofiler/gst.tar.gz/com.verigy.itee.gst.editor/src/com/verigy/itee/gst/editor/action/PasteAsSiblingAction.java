/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;

import com.verigy.itee.gst.editor.model.TdoNodeFactory;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

/**
 * @author alanlin
 *
 */
public class PasteAsSiblingAction extends AbstractUpdatableAction {
    private int offset;

    /**
     * Default constructor
     */
    public PasteAsSiblingAction() {
        super();
    }

    @Override
    protected boolean doRun(IAction action) {
        ITdoNode[] nodes = getSelectedNodes();
        if (null == nodes || nodes.length == 0) {
            return false;
        }

        ITdoNode selectedNode = nodes[0];
        Object content = ClipboardUtil.getClipboard().getContents(
                GenericNodeTransfer.getInstance());
        Map<String, ITdoNode> map = new HashMap<String, ITdoNode>();
        if (content instanceof List<?>) {
            List<?> list = (List<?>) content;
            offset = 0;
            for (int i = 0; i < list.size(); i++) {
                Object listObj = list.get(i);
                if (listObj instanceof String) {
                    createNodeFromString(selectedNode, (String) listObj, map);
                }
            }
            return true;
        }

        return false;
    }

    private ITdoNode createNodeFromString(ITdoNode selectedNode, String fieldStrings, Map<String, ITdoNode> createdMap) {
        String[] fields = fieldStrings.split(GenericNodeTransfer.FIELD_SEPARATOR);
        if (fields.length == 4) {
            ITdoNode parent = getParent(selectedNode, createdMap, fields[3]);

            ITdoNode newNode = null;
            if (parent == null) {
                newNode = TdoNodeFactory.getInstance()
                        .createTdoSiblingNode(getPreviousNode(selectedNode),
                                GenericNodeType.convertFrom(fields[2]), fields[0]);
                newNode.setValue(fields[1]);

                // add to parent
                int newIndex = getIndexOf(getPreviousNode(selectedNode)) + 1;
                ((ITdoNode)selectedNode.getParent()).addChild(newNode, newIndex);

                offset++;
            } else {
                newNode = TdoNodeFactory.getInstance().createTdoChildNode(
                        parent, GenericNodeType.convertFrom(fields[2]),
                        fields[0]);
                newNode.setValue(fields[1]);

                // add to parent
                parent.addChild(newNode, 0);
            }

            createdMap.put(fields[3], newNode);

            return newNode;
        }

        return null;
    }

    private ITdoNode getPreviousNode(ITdoNode selectedNode) {
        List<IZTestDataNode> children = selectedNode.getParent().getChildren();
        int indexOfSelectedNode = children.indexOf(selectedNode);
        ITdoNode result = (ITdoNode)children.get(indexOfSelectedNode + offset);
        return result == null ? selectedNode : result;
    }

    private int getIndexOf(ITdoNode node) {
        List<IZTestDataNode> children = node.getParent().getChildren();
        return children.indexOf(node);
    }

    private ITdoNode getParent(ITdoNode selectedNode, Map<String, ITdoNode> createdMap,
            String path) {
        int index = path.lastIndexOf(GenericNodeTransfer.PATH_SEPARATOR);
        String parentPath = index == -1 ? path : path.substring(0, index);

        ITdoNode node = createdMap.get(parentPath);

        return node;
    }

    @Override
    protected void onSelectionChange(IAction action, ISelection selection2) {
        ITdoNode gn = getFirstSelectedNode();
        Object content = ClipboardUtil.getClipboard().getContents(
                GenericNodeTransfer.getInstance());

        boolean shouldDisable = false;
        if (gn != null && content instanceof List<?>) {
            List<?> list = (List<?>) content;
            if (list.size() > 0) {
                Object data = list.get(0);
                if (data instanceof String) {
                    String[] fields = ((String) data)
                            .split(GenericNodeTransfer.FIELD_SEPARATOR);
                    if (fields.length == 4) {
                        GenericNodeType typeForSelection = gn.getNodeType();
                        GenericNodeType typeForContentInClipboard = GenericNodeType
                                .convertFrom(fields[2]);
                        int levelForSelection = typeForSelection.getLevel();
                        int levelForContentInClipboard = typeForContentInClipboard
                                .getLevel();

                        int gap = levelForContentInClipboard - levelForSelection;

                        if (gap == 1 && !GenericNodeType.SET.equals(typeForSelection)) {
                            shouldDisable = true;
                        } else if (gap != 0) {
                            shouldDisable = true;
                        }
                    } else {
                        shouldDisable = true;
                    }
                } else {
                    shouldDisable = true;
                }
            } else {
                shouldDisable = true;
            }
        } else {
            shouldDisable = true;
        }

        if (shouldDisable) {
            action.setEnabled(false);
        }
    }
}
