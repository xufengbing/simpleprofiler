/*******************************************************************************
 * Copyright (c) 2011 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.model;

import java.util.Set;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * @author alanlin
 *
 */
public interface IFilterSupport {
    /**
     * @return Returns filter
     */
    public Set<GenericNodeType> getFilter();

    /**
     * @param filter
     */
    public void setFilter(Set<GenericNodeType> filter);
}
