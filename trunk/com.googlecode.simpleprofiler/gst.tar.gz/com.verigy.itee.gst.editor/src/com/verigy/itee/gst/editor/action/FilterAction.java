/*******************************************************************************
 * Copyright (c) 2011 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.HashSet;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.ui.IEditorActionDelegate;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.ListSelectionDialog;
import org.eclipse.ui.forms.editor.FormEditor;

import com.verigy.itee.gst.editor.editors.GSTFilterPageFactory;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * @author bennwang
 *
 */
public class FilterAction extends AbstractGSTAction implements IEditorActionDelegate {


    private IEditorPart editor;

    @Override
    public void run(IAction action) {

        if(null == editor) {
            return;
        }

        ListSelectionDialog selectDialog = new ListSelectionDialog(editor.getSite().getShell(),
                new Object(),
                new ArrayContentProvider(){
                    @Override
                    public Object[] getElements(Object inputElement) {
                        return new Object[]{GenericNodeType.PROP,GenericNodeType.SET};
                    }
                },
                new LabelProvider(),
                "Filter Dialog");
        if(selectDialog.open() == Dialog.OK) {
            Object[] result = selectDialog.getResult();
            if((null != result) && result.length > 0) {
                HashSet<GenericNodeType> filters = new HashSet<GenericNodeType>();
                for(int i=0; i<result.length; i++) {
                    filters.add((GenericNodeType)result[i]);
                }
                String pageId = GSTFilterPageFactory.getInstance().createPage((FormEditor)editor, filters);
                if (pageId != null) {
                    ((FormEditor)editor).setActivePage(pageId);
                }
            }
        }
    }

    @Override
    public void setActiveEditor(IAction action, IEditorPart targetEditor) {

        if(targetEditor instanceof FormEditor) {
            editor = targetEditor;
        }

    }

    @Override
    protected void onSelectionChange(IAction action, ISelection selection2) {
        IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
        if (editor instanceof FormEditor) {
            action.setEnabled(true);
        } else {
            action.setEnabled(false);
        }
    }
}
