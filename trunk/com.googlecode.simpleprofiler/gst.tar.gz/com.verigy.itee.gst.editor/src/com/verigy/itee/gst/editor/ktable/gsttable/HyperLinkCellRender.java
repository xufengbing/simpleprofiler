/**
 * 
 */
package com.verigy.itee.gst.editor.ktable.gsttable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;
import de.kupzog.ktable.renderers.TextCellRenderer;

/**
 * @author alan.lin
 *
 */
public class HyperLinkCellRender extends TextCellRenderer {
    public static Color COLOR_BLUE = Display.getDefault().getSystemColor(SWT.COLOR_BLUE);

	private KTable table;
	private Font newFont;

	public HyperLinkCellRender(int style) {
		super(style);
	}
	
	public void setTable(KTable table) {
		this.table = table;
	}

    /** 
     * A default implementation that paints cells in a way that is more or less
     * Excel-like. Only the cell with focus looks very different.
     * @see de.kupzog.ktable.KTableCellRenderer#drawCell(GC, Rectangle, int, int, Object, boolean, boolean, boolean, KTableModel)
     */
    @Override
	public void drawCell(GC gc, Rectangle rect, int col, int row, Object content, 
            boolean focus, boolean fixed, boolean clicked, KTableModel model) {
        
        boolean mouseIn = false;
        if (table != null && table instanceof IHoveredCellChangeSupport) {
        	Point mouse = ((IHoveredCellChangeSupport)table).getHoveredCell();
        	mouseIn = (mouse.y == row) && (mouse.x == col);
        }
        
        applyFont(gc, mouseIn);
        
        // draw focus sign:
        if (focus && (m_Style & INDICATION_FOCUS)!=0) {
            // draw content:
            rect = drawDefaultSolidCellLine(gc, rect, COLOR_LINE_LIGHTGRAY, COLOR_LINE_LIGHTGRAY);
            drawCellContent(gc, rect, content.toString(), null, getForeground(mouseIn), colorBgfocus);
            gc.drawFocus(rect.x, rect.y, rect.width, rect.height);
            
        } else if (focus && (m_Style & INDICATION_FOCUS_ROW)!=0) {
            rect = drawDefaultSolidCellLine(gc, rect, bgColorInFocus, bgColorInFocus);
            // draw content:
            drawCellContent(gc, rect, content.toString(), null, bgColorInFocus, bgColorInFocus);
            
        } else {
            rect = drawDefaultSolidCellLine(gc, rect, COLOR_LINE_LIGHTGRAY, COLOR_LINE_LIGHTGRAY);
            // draw content:
            drawCellContent(gc, rect, content.toString(), null, getForeground(mouseIn), getBackground());
        }
        
        if ((m_Style & INDICATION_COMMENT)!=0)
            drawCommentSign(gc, rect);
        
        resetFont(gc);
        if (newFont != null) {
        	newFont.dispose();
        }
    }
    
    public Color getForeground(boolean mouseIn) {
    	return mouseIn ? COLOR_BLUE : super.getForeground();
    }
    
    protected void applyFont(GC gc, boolean mouseIn) {
    	super.applyFont(gc);
    	
    	if (mouseIn) {
    		Font font = gc.getFont();
    		FontData[] fds = font.getFontData();
    		for (int i = 0; i < fds.length; i++) {
    			int style = fds[i].getStyle();
    			style |= SWT.ITALIC;
    			//style |= SWT.UNDERLINE_LINK;
    			style |= SWT.UNDERLINE_SINGLE;
    			fds[i].setStyle(style);
    		}
    		
    		newFont = new Font(Display.getCurrent(), fds);
    		gc.setFont(newFont);
    	}
    }
}
