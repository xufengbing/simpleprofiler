/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.editors;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.contexts.IContextService;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.FormPage;

import com.verigy.itee.gst.editor.ktable.gsttable.GSTTableTree;
import com.verigy.itee.gst.editor.ktable.gsttable.KHoverCellChangeListener;
import com.verigy.itee.gst.editor.ktable.model.UDAKTabletreeModel2;
import com.verigy.itee.gst.editor.ktable.selection.KTableSelectionProvider;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.TdoNode;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.utils.GSTEditorInput;
import com.verigy.itee.gst.explorer.utils.Util;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTable.KTX;
import de.kupzog.ktable.SWTX;

/**
 * @author bennwang
 *
 */
public class GSTFilterFormPage extends FormPage {

    private final static String contextMenuId = "GST#PopupMenu";

    private GSTTableTree table;

    private ITdoNode rootNode;

    private UDAKTabletreeModel2 model;

    private ISelectionProvider selectionProvider;

    private final Set<GenericNodeType> filter;

    /**
     *
     * Create a new form page with/without a filter
     * @param editor {@link FormEditor}
     * @param id unique id
     * @param title page title
     * @param filter the filter
     */
    public GSTFilterFormPage(FormEditor editor, String id, String title, Set<GenericNodeType> filter) {
        super(editor, id, title);
        this.filter = filter;
    }


    @Override
    public void createPartControl(Composite parent) {
        super.createPartControl(parent);
        ((IContextService) getEditorSite().getService(IContextService.class))
        .activateContext("com.verigy.itee.gst.editor.context");
    }

    @Override
    protected void createFormContent(IManagedForm managedForm) {
        super.createFormContent(managedForm);
        Composite parent = managedForm.getForm().getBody();
        createKTabletree(parent);
        createContextMenu(table);
    }

    private void createContextMenu(Control control) {
        if (contextMenuId == null || selectionProvider == null) {
            return;
        }

        MenuManager manager = new MenuManager(contextMenuId, contextMenuId);
        manager.setRemoveAllWhenShown(true);
        manager.addMenuListener(new IMenuListener() {
            @Override
            public void menuAboutToShow(IMenuManager m) {
                fillContextMenu(m);
            }
        });
        Menu contextMenu = manager.createContextMenu(control);
        getEditorSite().registerContextMenu(contextMenuId, manager, selectionProvider,
                false);
        control.setMenu(contextMenu);
    }

    private void fillContextMenu(IMenuManager m) {
        // reserve menu positions here
        m.add(new Separator(contextMenuId + ".reference"));
        m.add(new Separator(contextMenuId + ".undoredo"));
        m.add(new Separator(contextMenuId + ".open"));
        m.add(new GroupMarker(contextMenuId + ".goto"));
        m.add(new Separator(contextMenuId + ".adddelete"));
        m.add(new Separator(contextMenuId + ".copypaste"));
        m.add(new Separator(contextMenuId + ".format"));
        m.add(new Separator(contextMenuId + ".filter"));

        // install default copy/paste action
//        m.add(new Separator());
//        m.add(actionHandler.m_SelectAllAction);
//        m.add(actionHandler.m_CopyAction);
//        m.add(actionHandler.m_CopyAllAction);
//        m.add(actionHandler.m_CutAction);
//        m.add(actionHandler.m_PasteAction);

        m.add(new Separator(contextMenuId + "." + IWorkbenchActionConstants.MB_ADDITIONS));
    }


    /**
     * @return Returns the root node of this editor
     */
    public ITdoNode getRootNode() {
        return rootNode;
    }

    private void createKTabletree(Composite parent) {
        parent.setLayout(new FillLayout());
        /*
         * Style bit (SWTX.MULTI) enables the multiply selection no matter it's cell
         * selection or row selection which means enabling selecting multiply cells or
         * rows. Style bit (SWTX.RECT_SELECTION) enables rectangle selection with the help
         * of shift key or ctrl key. The extended style bits (KTX.HEADER_ROW_SELECTION,
         * KTX.HEADER_COLUMN_SELECTION) enables selecting the whole row or whole column on
         * row header or column header. The combination of (SWTX.MULTI,
         * SWTX.RECT_SELECTION and KTX.EXPAND_ROW_SELECTION) enables the
         * KTable.getRowSelection() method returns the all selection rows otherwise only
         * the first row and the last row are returned. Same rule applies to the
         * combination of (SWTX.MULTI, SWTX.RECT_SELECTION and KTX.EXPAND_CELL_SELECTION).
         */
        int style = SWTX.MULTI | SWTX.AUTO_SCROLL | SWTX.FILL_WITH_LASTCOL
                | SWTX.EDIT_ON_KEY | SWTX.RECT_SELECTION;
        int extStyle = KTX.HEADER_ROW_SELECTION | KTX.EXPAND_ROW_SELECTION
                | KTX.EXPAND_CELL_SELECTION | KTX.HEADER_COLUMN_SELECTION
                | KTX.ENABLE_DRAG_SELECTION;
        table = new GSTTableTree(parent, style, extStyle);

        IEditorInput input = getEditorInput();
        if (null == input) {
            return;
        }

        List<String> uiFormat = new ArrayList<String>();
        rootNode = null;

        if (input instanceof IFileEditorInput) {
            IFileEditorInput fileEditorInput = (IFileEditorInput) input;
            IFile file = fileEditorInput.getFile();

            String name = file.getName();
            String extention = file.getFileExtension();

            name = name.substring(0, name.length() - extention.length() - 1);

            IZTestDataNode superNode = null;
            if (input instanceof GSTEditorInput) { // open from project explorer
                superNode = ((GSTEditorInput) input).getNode();
            } else { // jump from problem view
                superNode = Util.convertToTDENode(file);
            }

            rootNode = new TdoNode(null, (int) superNode.getAddress(),true);
            if (superNode instanceof IUTDEntity) {
                uiFormat = getUIFormatFrom((IUTDEntity) superNode);
            }
        }

        model = new UDAKTabletreeModel2(this, table, rootNode, uiFormat, filter);
        table.setModel(model);


        selectionProvider = new KTableSelectionProvider(table, this);
        getSite().setSelectionProvider(selectionProvider);


        // register mouse move listener for hyper link style cell renderer
        table.addHoveredCellChangeListener(new KHoverCellChangeListener() {
            @Override
            public void onHoveredCellChange(int x1, int y1, int x2, int y2, KTable aTable) {
                if (x1 >= 0 && y1 >= 0) {
                    aTable.redraw(x1, y1, 1, 1);
                }
                if (x2 >= 0 && y2 >= 0) {
                    aTable.redraw(x2, y2, 1, 1);
                }
            }
        });


    }


    private List<String> getUIFormatFrom(IUTDEntity tdeEntity) {
        List<String> format = new ArrayList<String>();
        String metaData = tdeEntity.getMetaData();

        if (!metaData.isEmpty()) {
            String[] columns = metaData.split("[,| |;]");
            for (String c : columns) {
                if (!c.trim().isEmpty()) {
                    format.add(c.trim());
                }
            }
        }

        return format;
    }
}
