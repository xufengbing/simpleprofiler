/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.widgets.Display;

/**
 * @author bennwang
 *
 */
public class ClipboardUtil {

    final static Clipboard clipBoard = new Clipboard(Display.getDefault());
    final static long ID = System.currentTimeMillis();

    static Clipboard getClipboard() {
        return clipBoard;
    }

    static String getID() {
        return String.valueOf(ID);
    }


}
