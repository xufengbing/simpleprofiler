/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;

/**
 * @author alanlin
 *
 */
public abstract class AbstractUpdatableAction extends AbstractGSTAction{	
	@Override
	public void run(IAction action) {
		if(doRun(action)) {
			refreshKTable();
		}
	}
	
	/**
	 * Does the real operations for this action and returns <code>true</code>
	 * or <code>false</code> to indicate if the action is successfully done.
	 * @param action the action.
	 * @return
	 */
	abstract protected boolean doRun(IAction action);
}
