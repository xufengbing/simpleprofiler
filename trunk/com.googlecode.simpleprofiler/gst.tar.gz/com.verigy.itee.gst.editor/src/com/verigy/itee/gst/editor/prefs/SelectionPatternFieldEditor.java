/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.prefs;

import org.eclipse.jface.preference.FieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;

/**
 * @author alanlin
 */
public class SelectionPatternFieldEditor extends FieldEditor {
    private final static String ASK = "Always Ask";
    private final static String NONE = "None";
    private final static String AUTO = "Auto";

    private Group selectionPatternGroup;
    private Button alwaysAskRadioButton;
    private Button autoSelectionRadioButton;
    private Button noneAutoSelectionRadioButton;

    private String selectionPattern;

    /**
     * Default constructor
     */
    protected SelectionPatternFieldEditor() {
        // no default constructor
    }

    /**
     * Creates a color field editor.
     *
     * @param name
     *            the name of the preference this field editor works on
     * @param labelText
     *            the label text of the field editor
     * @param parent
     *            the parent of the field editor's control
     */
    public SelectionPatternFieldEditor(String name, String labelText, Composite parent) {
        super(name, labelText, parent);
    }

    @Override
    protected void adjustForNumColumns(int numColumns) {
        if (selectionPatternGroup != null) {
            ((GridData) selectionPatternGroup.getLayoutData()).horizontalSpan = numColumns;
        }
    }

    @Override
    protected void doFillIntoGrid(Composite parent, int numColumns) {
        Control control = getSelectionPatternGroup(parent);
        GridData data = new GridData();
        data.horizontalSpan = numColumns;
        data.grabExcessHorizontalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        control.setLayoutData(data);
    }

    @Override
    protected void doLoad() {
        selectionPattern = getPreferenceStore().getString(PreferenceConstants.SELECTION_PATTERN);
        if (selectionPatternGroup != null) {
            if (ASK.equals(selectionPattern)) {
                alwaysAskRadioButton.setSelection(true);
                autoSelectionRadioButton.setSelection(false);
                noneAutoSelectionRadioButton.setSelection(false);
            } else if (NONE.equals(selectionPattern)) {
                alwaysAskRadioButton.setSelection(false);
                autoSelectionRadioButton.setSelection(false);
                noneAutoSelectionRadioButton.setSelection(true);
            } else {
                alwaysAskRadioButton.setSelection(false);
                autoSelectionRadioButton.setSelection(true);
                noneAutoSelectionRadioButton.setSelection(false);
            }
        }
    }

    @Override
    protected void doLoadDefault() {
        selectionPattern = getPreferenceStore().getDefaultString(PreferenceConstants.SELECTION_PATTERN);
        if (selectionPatternGroup != null) {
            if (ASK.equals(selectionPattern)) {
                alwaysAskRadioButton.setSelection(true);
                autoSelectionRadioButton.setSelection(false);
                noneAutoSelectionRadioButton.setSelection(false);
            } else if (NONE.equals(selectionPattern)) {
                alwaysAskRadioButton.setSelection(false);
                autoSelectionRadioButton.setSelection(false);
                noneAutoSelectionRadioButton.setSelection(true);
            } else {
                alwaysAskRadioButton.setSelection(false);
                autoSelectionRadioButton.setSelection(true);
                noneAutoSelectionRadioButton.setSelection(false);
            }
        }
    }

    @Override
    protected void doStore() {
        if (selectionPatternGroup == null) {
            getPreferenceStore().setDefault(PreferenceConstants.SELECTION_PATTERN, AUTO);
        } else {
            getPreferenceStore().setValue(PreferenceConstants.SELECTION_PATTERN, selectionPattern);
        }
    }

    @Override
    public int getNumberOfControls() {
        return 1;
    }

    /**
     * Creates the widgets for this field editor.
     * @param parent the parent
     * @return the created selection pattern group
     */
    private Control getSelectionPatternGroup(Composite parent) {
        if (selectionPatternGroup == null) {
            GridLayout layout;
            Font font = parent.getFont();

            // Create the top level group which is also the "main"
            //   control which we will pass back.
            selectionPatternGroup = new Group(parent, SWT.NONE );
            selectionPatternGroup.setFont(font);
            selectionPatternGroup.setText("Selection Patterns");
            layout = new GridLayout();
            layout.horizontalSpacing = HORIZONTAL_GAP;
            layout.numColumns = 1;
            selectionPatternGroup.setLayout(layout);

            // always ask radio button
            alwaysAskRadioButton = new Button(selectionPatternGroup, SWT.RADIO | SWT.LEFT);
            alwaysAskRadioButton.setFont(font);
            alwaysAskRadioButton.setText("Always ask user to select the selection pattern!");
            alwaysAskRadioButton.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent event) {
                    String oldValue = selectionPattern;
                    selectionPattern = ASK;
                    setPresentsDefaultValue(false);

                    if (!selectionPattern.equals(oldValue)) {
                        fireValueChanged(PreferenceConstants.SELECTION_PATTERN, oldValue, selectionPattern);
                    }
                }
            });

            // auto selection radio button
            autoSelectionRadioButton = new Button(selectionPatternGroup, SWT.RADIO | SWT.LEFT);
            autoSelectionRadioButton.setFont(font);
            autoSelectionRadioButton.setText("Auto select all its children when it is collapsed!");
            autoSelectionRadioButton.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent event) {
                    String oldValue = selectionPattern;
                    selectionPattern = AUTO;
                    setPresentsDefaultValue(true);

                    if (!selectionPattern.equals(oldValue)) {
                        fireValueChanged(PreferenceConstants.SELECTION_PATTERN, oldValue, selectionPattern);
                    }
                }
            });

            // - none radio button
            noneAutoSelectionRadioButton = new Button(selectionPatternGroup, SWT.RADIO | SWT.LEFT);
            noneAutoSelectionRadioButton.setFont(font);
            noneAutoSelectionRadioButton.setText("Only select current node when it is collapsed!");
            noneAutoSelectionRadioButton.addSelectionListener(new SelectionAdapter() {
                @Override
                public void widgetSelected(SelectionEvent event) {
                    String oldValue = selectionPattern;
                    selectionPattern = NONE;
                    setPresentsDefaultValue(false);

                    if (!selectionPattern.equals(oldValue)) {
                        fireValueChanged(PreferenceConstants.SELECTION_PATTERN, oldValue, selectionPattern);
                    }

                }
            });
        }
        return selectionPatternGroup;
    }
}
