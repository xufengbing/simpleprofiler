/**
 *
 */
package com.verigy.itee.gst.editor.ktable.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.editor.contentassist.FakeContentAssistHelper;
import com.verigy.itee.gst.editor.contentassist.IContentAssistHelper;
import com.verigy.itee.gst.editor.ktable.editors.KTableCellEditorContentAssistWithExpression;
import com.verigy.itee.gst.editor.ktable.editors.KTableCellEditorTextTreeWithContentAssist;
import com.verigy.itee.gst.editor.ktable.gsttable.HyperLinkCellRender;
import com.verigy.itee.gst.editor.ktable.renderer.RendererPool;
import com.verigy.itee.gst.editor.model.TdoNodeFactory;
import com.verigy.itee.gst.editor.support.IDirtyFlagSupport;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.ktabletree.KTableTreeModel;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableCellEditor;
import de.kupzog.ktable.KTableCellRenderer;
import de.kupzog.ktable.KTableFontProvider;
import de.kupzog.ktable.renderers.DefaultCellRenderer;

/**
 * @author alanlin
 */
public class UDAKTabletreeModel extends KTableTreeModel implements IUdaObjectOperationSupport {
	private List<String> columnProperties;
	/*
	 * Shared cell renderer for all cell and no need to generate cell renderer
	 * for each cell.
	 */
    private final KTableCellRenderer hyperlinkRenderer;

    private int[] rootRows;

    private ITdoNode[] contents;
    private List<String> format;
	private ITdoNode rootNode;

	private final IDirtyFlagSupport editor;

	private final IContentAssistHelper contentAssistHelper;

    /**
     * The constructor.
     * @param rootNode it's a {@link ITdoNode} and it's the portal of the
     * all hierarchical test data entity.
     * @param format it's string set which contains all formated properties.
     */
    public UDAKTabletreeModel(IEditorPart editor, KTable table, ITdoNode rootNode, List<String> format) {
    	if (editor instanceof IDirtyFlagSupport) {
    		this.editor = (IDirtyFlagSupport)editor;
    	} else {
    		this.editor = null;
    	}

        hyperlinkRenderer = new HyperLinkCellRender(DefaultCellRenderer.INDICATION_FOCUS);
        ((HyperLinkCellRender)hyperlinkRenderer).setTable(table);

        contentAssistHelper = FakeContentAssistHelper.getInstance();

        /*
         * Constructs the contents
         */
        refreshKTableDataModel(rootNode, format);

        setDirtyFlag(false);
    }

	private void setDirtyFlag(boolean dirtyFlag) {
		if (editor != null) {
			editor.setDirty(dirtyFlag);
		}
	}

    @Override
    public void refreshKTableDataModel(ITdoNode theRoot,
    		List<String> theFormat) {
        // IMPORTANT: The format should be assigned before calling traverseAllNodes().
        this.format = theFormat;// == null ? new ArrayList()<String>() : format;
        this.rootNode = theRoot;

        // Initialize the column properties.
        columnProperties = new ArrayList<String>();
        columnProperties.add("Node");
        columnProperties.add("Value");
        for (String aFormat : this.format) {
        	columnProperties.add(aFormat);
        }

        // always add a additional comment column
        //columnProperties.add("Comment");

        traverseAllNodes(theRoot);
        // IMPORTANT: Must take fixed headers into account!!!!!!!
        for (int i = 0; i < rootRows.length; i++) {
        	rootRows[i] += getFixedHeaderRowCount();
        }

		/*
		 * Don't forget to call intialize();
		 */
        initialize();

        setDirtyFlag(true);
    }

    @Override
    public void refreshKTableDataModel() {
    	refreshKTableDataModel(rootNode, format);
    }



	/**
     * Traverses all nodes from the given root node. Uses stack instead of recurse
     * method to avoid stack overflow issue.
     * @param theRoot the root node which will be traversed.
     */
    private void traverseAllNodes(ITdoNode theRoot) {
//    	Assert.isNotNull(theRoot);
        if (theRoot == null) {
            contents = new ITdoNode[0];
            rootRows = new int[0];
            return;
        }

    	Stack<ITdoNode> stack = new Stack<ITdoNode>();
    	ITdoNode current = theRoot;
    	List<ITdoNode> nodes = new ArrayList<ITdoNode>();
    	while(current != null || !stack.isEmpty()) {
    		// A trick here
    		nodes.add(current);

    		if (current.hasChild()) {
	    		for (int i = current.getChildren().size() - 1; i >= 0 ; i--) {
	    		    ITdoNode child = (ITdoNode)current.getChildren().get(i);
					if (!format.contains(child.getName().trim())) {
	    				stack.push(child);
	    			}
	    		}
	    		current = null;
    		} else {
    			if (stack.size() > 0) {
    				current = stack.pop();
    			} else {
    				current = null;
    			}
    		}

    		if (stack.size() > 0 && current == null) {
    			current = stack.pop();
    		}
    	}

    	contents = nodes.toArray(new ITdoNode[nodes.size()]);
    	rootRows = new int[] {0};
	}

	/*
     * @see KTableDefaultModel#doGetCellEditor(int, int)
     */
    @Override
    public KTableCellEditor doGetCellEditor(int col, int row) {
        int modelIdx = 0;
        if (col == 1) {
            modelIdx = row - getFixedHeaderRowCount();
            if (modelIdx >=0 && modelIdx <= contents.length) {
                ITdoNode node = contents[modelIdx];
                if (node != null && !GenericNodeType.IMPORT.equals(node.getNodeType())) {
                    return getCellEditor(
                            contentAssistHelper.getContentAssistFor(node));
                }
            }

            return null;
        }

        if (col == 2) {
            modelIdx = row - getFixedHeaderRowCount();
            if (modelIdx >=0 && modelIdx <= contents.length) {
                ITdoNode node = contents[modelIdx];
                if (node != null) {
                    if (GenericNodeType.IMPORT.equals(node.getNodeType())) {
                        return getCellEditor(
                            contentAssistHelper.getContentAssistFor(node));
                    }
                    if (GenericNodeType.PROP.equals(node.getNodeType())) {
                        return new KTableCellEditorContentAssistWithExpression(contentAssistHelper.getValueProposalsFor(node), new KTableFontProvider());
                    }
                }
            }
        }

        return new KTableCellEditorContentAssistWithExpression(new String[0], new KTableFontProvider());
    }

    /*
     * @see KTableDefaultModel#doGetCellRenderer(int, int)
     */
    @Override
    public KTableCellRenderer doGetCellRenderer(int col, int row) {
        RendererPool pool = RendererPool.getInstance();
        if (isHeaderCell(col, row)) {
            return pool.getFixedCellRenderer();
        }

        boolean isTreeCell = (col == 1);
        int modelIdx = row - getFixedHeaderRowCount();
        if (modelIdx >=0 && modelIdx < contents.length) {
            ITdoNode node = contents[modelIdx];

            if (node != null) {
                return pool.getCellRender(node, isTreeCell);
            }
        }


        return pool.getCellRender((ITdoNode)null, isTreeCell);
    }

    @Override
    public String getTooltipAt(int col, int row) {
    	if (doGetCellRenderer(col, row) == hyperlinkRenderer) {
    		return "\"CTRL + Click\" to open this reference";
    	}
        Object content = doGetContentAt(col, row);
        return (content == null) ? EMPTY_STR : content.toString();
    }

    /*
     * @see KTableDefaultModel#doGetColumnCount()
     */
    @Override
    public int doGetColumnCount() {
        return columnProperties.size() + getFixedHeaderColumnCount();
    }

    /*
     * @see KTableDefaultModel#doGetContentAt(int, int)
     */
    @Override
    public Object doGetContentAt(int col, int row) {
        String returnValue = EMPTY_STR;
        int modelIndex = row - getFixedHeaderRowCount();
        int colIdx = col - getFixedHeaderColumnCount();

        if (isHeaderCell(col, row)) {
        	if (row == 0) {
        		if (col == 0) {
        			return EMPTY_STR;
        		}

        		return columnProperties.get(col - getFixedHeaderColumnCount());
        	}
            if (modelIndex >= 0 && modelIndex <= contents.length) {
                ITdoNode gn = contents[modelIndex];
                if (gn != null) {
                    return gn.getNodeType().getRepresentation();
                }
            }
        	return EMPTY_STR;
        }

        if (modelIndex >= 0 && modelIndex <= contents.length) {
        	ITdoNode gn = contents[modelIndex];
        	if (gn != null) {
        		switch (colIdx) {
				case 0:
					returnValue = gn.getName();
					break;
				case 1:
					returnValue = gn.getValue();
					break;
				default:
					ITdoNode child = (ITdoNode)gn.getChildByName(columnProperties.get(colIdx));
					returnValue = child == null ? EMPTY_STR : child.getValue();
					break;
				}
        	}
        }

        return returnValue;
    }

    /*
     * @see KTableDefaultModel#doGetRowCount()
     */
    @Override
    public int doGetRowCount() {
        return getFixedRowCount() + contents.length;
    }

    /*
     * @see KTableDefaultModel#doSetContentAt(int, int, java.lang.Object)
     */
    @Override
    public void doSetContentAt(int col, int row, Object value) {
        if (isHeaderCell(col, row)) {
        	// do nothing
        }

        int modelIndex = row - getFixedHeaderRowCount();
        int colIdx = col - getFixedHeaderColumnCount();
        if (modelIndex >= 0 && modelIndex <= contents.length) {
        	ITdoNode gn = contents[modelIndex];
        	if (gn != null) {
        		switch (colIdx) {
				case 0:
					gn.setName(value.toString());
					setDirtyFlag(true);
					break;
				case 1:
					gn.setValue(value.toString());
					setDirtyFlag(true);
					break;
				default:
					ITdoNode child = (ITdoNode)gn.getChildByName(columnProperties.get(colIdx));
					if (child != null) {
						child.setValue(value.toString());
						setDirtyFlag(true);
					} else {		// doesn't exist and creates a new one
					    child = TdoNodeFactory.getInstance().createTdoChildNode(
			                    gn, GenericNodeType.PROP, columnProperties.get(colIdx));
					    child.setValue(value.toString());
					    gn.addChild(child);
					    setDirtyFlag(true);
					}
					break;
				}
        	}
        }
    }

    /*
     * @see KTableDefaultModel#getInitialColumnWidth(int)
     */
    @Override
    public int getInitialColumnWidth(int column) {
    	if (column == 0) {
    		return 25;
    	} else if(column == 1) {
    	    return 268;
    	} else if (column == 2) {
    	    return 100;
    	}
        return 80;
    }

    /*
     * @see KTableModel#getFixedHeaderColumnCount()
     */
    @Override
    public int getFixedHeaderColumnCount() {
        return 1;
    }

    /*
     * @see KTableModel#getFixedHeaderRowCount()
     */
    @Override
    public int getFixedHeaderRowCount() {
        return 1;
    }

    /*
     * @see KTableModel#getFixedSelectableColumnCount()
     */
    @Override
    public int getFixedSelectableColumnCount() {
        return 0;
    }

    /*
     * @see KTableModel#getFixedSelectableRowCount()
     */
    @Override
    public int getFixedSelectableRowCount() {
        return 0;
    }

    /*
     * @see KTableModel#isColumnResizable(int)
     */
    @Override
    public boolean isColumnResizable(int col) {
        return true;
    }

    /*
     * @see KTableModel#isRowResizable(int)
     */
    @Override
    public boolean isRowResizable(int row) {
        return false;
    }

    /*
     * @see KTableDefaultModel#getInitialRowHeight(int)
     */
    @Override
    public int getInitialRowHeight(int row) {
    	if (row < getFixedHeaderRowCount()) {		// fixed rows
    		return 25;
    	}
        return 22;
    }

    /*
     * @see KTableTreeModel#getChildsCountForRow(int)
     */
    @Override
    public int getChildsCountForRow(int row) {
    	int modelIdx = row - getFixedHeaderRowCount();
    	if (modelIdx >= 0 && modelIdx < contents.length) {
    		IZTestDataNode entity = contents[modelIdx];
    		if (entity != null) {
    			int verticalDisplayedChildrenCount = 0;
    			for (IZTestDataNode child : entity.getChildren()) {
    				if (!format.contains(child.getName().trim())) {
    					++ verticalDisplayedChildrenCount;
    				}
    			}
    			return verticalDisplayedChildrenCount;
    		}
    	}

    	return 0;
    }

    /*
     * @see KTableTreeModel#getRootRows()
     */
    @Override
    public int[] getRootRows() {
        return rootRows;
    }

	@Override
	public Object getObjectAt(int index) {
		int objIdx = index - getFixedHeaderRowCount();
		if (objIdx >= 0 && objIdx < contents.length) {
			return contents[objIdx];
		}
		return null;
	}

	public int getModelRowIndexOf(ITdoNode node) {
	    int result = -1;

	    for (int i = 0; i < contents.length; i++) {
	        if (contents[i].equals(node)) {
	            result = i;
	            break;
	        }
	    }

	    return result;
	}

    private final static String EMPTY_STR = "";

    /**
     * Get a content assist editor with available contents
     * @param candidates array
     * @return Returns the cell editor
     */
    protected KTableCellEditor getCellEditor(String[] candidates) {
        return new KTableCellEditorTextTreeWithContentAssist(candidates,
                new KTableFontProvider());
    }
    @Override
    public int getRowIndexFor(ITdoNode node) {
        int modelRowIndex = getModelRowIndexOf(node);

        return modelRowIndex + getFixedRowCount();
    }

    @Override
    protected Object getElementAt(int i) {
        return getObjectAt(i);
    }
}
