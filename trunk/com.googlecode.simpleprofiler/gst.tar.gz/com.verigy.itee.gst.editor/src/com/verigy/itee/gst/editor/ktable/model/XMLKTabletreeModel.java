/**
 *
 */
package com.verigy.itee.gst.editor.ktable.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.editor.contentassist.FakeContentAssistHelper;
import com.verigy.itee.gst.editor.contentassist.IContentAssistHelper;
import com.verigy.itee.gst.editor.ktable.editors.KTableCellEditorTextTreeWithContentAssist;
import com.verigy.itee.gst.editor.ktable.gsttable.HyperLinkCellRender;
import com.verigy.itee.gst.editor.ktable.renderer.RendererPool;
import com.verigy.itee.gst.editor.model.IGenericNode;
import com.verigy.itee.gst.editor.support.IDirtyFlagSupport;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.ktabletree.KTableTreeModel;
import com.verigy.itee.ktabletree.editors.KTableCellEditorTextTree;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableCellEditor;
import de.kupzog.ktable.KTableCellRenderer;
import de.kupzog.ktable.KTableFontProvider;
import de.kupzog.ktable.editors.KTableCellEditorText2;
import de.kupzog.ktable.renderers.DefaultCellRenderer;

/**
 * @author alanlin
 */
public class XMLKTabletreeModel extends KTableTreeModel implements IObjectOperationSupport {
	private List<String> columnProperties;
	/*
	 * Shared cell renderer for all cell and no need to generate cell renderer
	 * for each cell.
	 */
//    private final KTableCellRenderer fixedRenderer;
//    private final KTableCellRenderer defaultRenderer;
//    private final KTableCellRenderer treeRenderer;
    private final KTableCellRenderer hyperlinkRenderer;

    private int[] rootRows;

    private IGenericNode[] contents;
    private List<String> format;
	private IGenericNode rootNode;

	private final IDirtyFlagSupport editor;

	private final IContentAssistHelper contentAssistHelper;

    /**
     * The constructor.
     * @param rootNode it's a {@link IGenericNode} and it's the portal of the
     * all hierarchical test data entity.
     * @param format it's string set which contains all formated properties.
     */
    public XMLKTabletreeModel(IEditorPart editor, KTable table, IGenericNode rootNode, List<String> format) {
    	if (editor instanceof IDirtyFlagSupport) {
    		this.editor = (IDirtyFlagSupport)editor;
    	} else {
    		this.editor = null;
    	}

		/*
    	 * Initialize all renderers for later usage.
    	 */
//        fixedRenderer = new FixedCellRenderer(DefaultCellRenderer.STYLE_PUSH
//                | DefaultCellRenderer.INDICATION_SORT
//                | DefaultCellRenderer.INDICATION_FOCUS
//                | DefaultCellRenderer.INDICATION_CLICKED);
//        defaultRenderer = new DefaultCellRenderer(0);
//        treeRenderer = new TreeCellRenderer(DefaultCellRenderer.INDICATION_FOCUS_ROW);
        hyperlinkRenderer = new HyperLinkCellRender(DefaultCellRenderer.INDICATION_FOCUS);
        ((HyperLinkCellRender)hyperlinkRenderer).setTable(table);

        contentAssistHelper = FakeContentAssistHelper.getInstance();

        /*
         * Constructs the contents
         */
        refreshKTableDataModel(rootNode, format);

        setDirtyFlag(false);
    }

	private void setDirtyFlag(boolean dirtyFlag) {
		if (editor != null) {
			editor.setDirty(dirtyFlag);
		}
	}

    @Override
    public void refreshKTableDataModel(IGenericNode theRoot,
    		List<String> theFormat) {
        // IMPORTANT: The format should be assigned before calling traverseAllNodes().
        this.format = theFormat;// == null ? new ArrayList()<String>() : format;
        this.rootNode = theRoot;

        // Initialize the column properties.
        columnProperties = new ArrayList<String>();
        columnProperties.add("Node");
        columnProperties.add("Value");
        for (String aFormat : this.format) {
        	columnProperties.add(aFormat);
        }

        // always add a additional comment column
        //columnProperties.add("Comment");

        traverseAllNodes(theRoot);
        // IMPORTANT: Must take fixed headers into account!!!!!!!
        for (int i = 0; i < rootRows.length; i++) {
        	rootRows[i] += getFixedHeaderRowCount();
        }

		/*
		 * Don't forget to call intialize();
		 */
        initialize();

        setDirtyFlag(true);
    }

    @Override
    public void refreshKTableDataModel() {
    	refreshKTableDataModel(rootNode, format);
    }



	/**
     * Traverses all nodes from the given root node. Uses stack instead of recurse
     * method to avoid stack overflow issue.
     * @param theRoot the root node which will be traversed.
     */
    private void traverseAllNodes(IGenericNode theRoot) {
//    	Assert.isNotNull(theRoot);
        if (theRoot == null) {
            contents = new IGenericNode[0];
            rootRows = new int[0];
            return;
        }

    	Stack<IGenericNode> stack = new Stack<IGenericNode>();
    	IGenericNode current = theRoot;
    	List<IGenericNode> nodes = new ArrayList<IGenericNode>();
    	while(current != null || !stack.isEmpty()) {
    		// A trick here
    		nodes.add(current);

    		if (current.hasChild()) {
	    		for (int i = current.getChildren().size() - 1; i >= 0 ; i--) {
	    			IGenericNode child = current.getChildren().get(i);
					if (!format.contains(child.getName().trim())) {
	    				stack.push(child);
	    			}
	    		}
	    		current = null;
    		} else {
    			if (stack.size() > 0) {
    				current = stack.pop();
    			} else {
    				current = null;
    			}
    		}

    		if (stack.size() > 0 && current == null) {
    			current = stack.pop();
    		}
    	}

    	contents = nodes.toArray(new IGenericNode[nodes.size()]);
    	rootRows = new int[] {0};
	}

	/*
     * @see KTableDefaultModel#doGetCellEditor(int, int)
     */
    @Override
    public KTableCellEditor doGetCellEditor(int col, int row) {
        if (col == 1) {
            return new KTableCellEditorTextTree(new KTableFontProvider());
        }

        return new KTableCellEditorText2(new KTableFontProvider());
    }

    /*
     * @see KTableDefaultModel#doGetCellRenderer(int, int)
     */
    @Override
    public KTableCellRenderer doGetCellRenderer(int col, int row) {
        RendererPool pool = RendererPool.getInstance();
        if (isHeaderCell(col, row)) {
            return pool.getFixedCellRenderer();
        }

        boolean isTreeCell = (col == 1);
        int modelIdx = row - getFixedHeaderRowCount();
        if (modelIdx >=0 && modelIdx < contents.length) {
            IGenericNode node = contents[modelIdx];

            if (node != null) {
                return pool.getCellRender(node, isTreeCell);
            }
        }


        return pool.getCellRender((ITdoNode)null, isTreeCell);
    }

    @Override
    public String getTooltipAt(int col, int row) {
    	if (doGetCellRenderer(col, row) == hyperlinkRenderer) {
    		return "\"CTRL + Click\" to open this reference";
    	}
    	return doGetContentAt(col, row).toString();
    }

    /*
     * @see KTableDefaultModel#doGetColumnCount()
     */
    @Override
    public int doGetColumnCount() {
        return columnProperties.size() + getFixedHeaderColumnCount();
    }

    /*
     * @see KTableDefaultModel#doGetContentAt(int, int)
     */
    @Override
    public Object doGetContentAt(int col, int row) {
        String returnValue = EMPTY_STR;
        int modelIndex = row - getFixedHeaderRowCount();
        int colIdx = col - getFixedHeaderColumnCount();

        if (isHeaderCell(col, row)) {
        	if (row == 0) {
        		if (col == 0) {
        			return EMPTY_STR;
        		}

        		return columnProperties.get(col - getFixedHeaderColumnCount());
        	}
            if (modelIndex >= 0 && modelIndex <= contents.length) {
                IGenericNode gn = contents[modelIndex];
                if (gn != null) {
                    return gn.getNodeType().getRepresentation();
                }
            }
        	return EMPTY_STR;
        }

        if (modelIndex >= 0 && modelIndex <= contents.length) {
        	IGenericNode gn = contents[modelIndex];
        	if (gn != null) {
        		switch (colIdx) {
				case 0:
					returnValue = gn.getName();
					break;
				case 1:
					returnValue = gn.getValue();
					break;
				default:
					IGenericNode child = gn.getChild(columnProperties.get(colIdx));
					returnValue = child == null ? EMPTY_STR : child.getValue();
					break;
				}
        	}
        }

        return returnValue;
    }

    /*
     * @see KTableDefaultModel#doGetRowCount()
     */
    @Override
    public int doGetRowCount() {
        return getFixedRowCount() + contents.length;
    }

    /*
     * @see KTableDefaultModel#doSetContentAt(int, int, java.lang.Object)
     */
    @Override
    public void doSetContentAt(int col, int row, Object value) {
        if (isHeaderCell(col, row)) {
        	// do nothing
        }

        int modelIndex = row - getFixedHeaderRowCount();
        int colIdx = col - getFixedHeaderColumnCount();
        if (modelIndex >= 0 && modelIndex <= contents.length) {
        	IGenericNode gn = contents[modelIndex];
        	if (gn != null) {
        		switch (colIdx) {
				case 0:
					gn.setName(value.toString());
					setDirtyFlag(true);
					break;
				case 1:
					gn.setValue(value.toString());
					setDirtyFlag(true);
					break;
				default:
					IGenericNode child = gn.getChild(columnProperties.get(colIdx));
					if (child != null) {
						child.setValue(value.toString());
						setDirtyFlag(true);
					} else {		// doesn't exist and creates a new one

					}
					break;
				}
        	}
        }
    }

    /*
     * @see KTableDefaultModel#getInitialColumnWidth(int)
     */
    @Override
    public int getInitialColumnWidth(int column) {
    	if (column == 0) {
    		return 25;
    	} else if(column == 1) {
    	    return 268;
    	} else if (column == 2) {
    	    return 100;
    	}
        return 80;
    }

    /*
     * @see KTableModel#getFixedHeaderColumnCount()
     */
    @Override
    public int getFixedHeaderColumnCount() {
        return 1;
    }

    /*
     * @see KTableModel#getFixedHeaderRowCount()
     */
    @Override
    public int getFixedHeaderRowCount() {
        return 1;
    }

    /*
     * @see KTableModel#getFixedSelectableColumnCount()
     */
    @Override
    public int getFixedSelectableColumnCount() {
        return 0;
    }

    /*
     * @see KTableModel#getFixedSelectableRowCount()
     */
    @Override
    public int getFixedSelectableRowCount() {
        return 0;
    }

    /*
     * @see KTableModel#isColumnResizable(int)
     */
    @Override
    public boolean isColumnResizable(int col) {
        return true;
    }

    /*
     * @see KTableModel#isRowResizable(int)
     */
    @Override
    public boolean isRowResizable(int row) {
        return false;
    }

    /*
     * @see KTableDefaultModel#getInitialRowHeight(int)
     */
    @Override
    public int getInitialRowHeight(int row) {
    	if (row < getFixedHeaderRowCount()) {		// fixed rows
    		return 25;
    	}
        return 22;
    }

    /*
     * @see KTableTreeModel#getChildsCountForRow(int)
     */
    @Override
    public int getChildsCountForRow(int row) {
    	int modelIdx = row - getFixedHeaderRowCount();
    	if (modelIdx >= 0 && modelIdx < contents.length) {
    		IGenericNode entity = contents[modelIdx];
    		if (entity != null) {
    			int verticalDisplayedChildrenCount = 0;
    			for (IGenericNode child : entity.getChildren()) {
    				if (!format.contains(child.getName().trim())) {
    					++ verticalDisplayedChildrenCount;
    				}
    			}
    			return verticalDisplayedChildrenCount;
    		}
    	}

    	return 0;
    }

    /*
     * @see KTableTreeModel#getRootRows()
     */
    @Override
    public int[] getRootRows() {
        return rootRows;
    }

	@Override
	public Object getObjectAt(int index) {
		int objIdx = index - getFixedHeaderRowCount();
		if (objIdx >= 0 && objIdx < contents.length) {
			return contents[objIdx];
		}
		return null;
	}

	public int getModelRowIndexOf(IGenericNode node) {
	    int result = -1;

	    for (int i = 0; i < contents.length; i++) {
	        if (contents[i].equals(node)) {
	            result = i;
	            break;
	        }
	    }

	    return result;
	}

    private final static String EMPTY_STR = "";

    /**
     * Get a content assist editor with available contents
     * @param candidates array
     * @return Returns the cell editor
     */
    protected KTableCellEditor getCellEditor(String[] candidates) {
        return new KTableCellEditorTextTreeWithContentAssist(candidates,
                new KTableFontProvider());
    }
}
