/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;

import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 * @author alanlin
 *
 */
public class DeleteAction extends AbstractGSTAction {

	/**
	 *
	 */
	public DeleteAction() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	@Override
	public void run(IAction action) {
		ITdoNode[] allNodes = getSelectedNodes();
		if (allNodes.length > 0) {
		    ITdoNode rootParent = (ITdoNode)(allNodes[0].getParent());
		    if (rootParent != null) {
                StringBuffer msgBuf = new StringBuffer("Would you like to delete node(s):\n ");
                for (ITdoNode d : allNodes) {
                    msgBuf.append(d.getName());
                    msgBuf.append(' ');
                }
                msgBuf.deleteCharAt(msgBuf.length() - 1);
                msgBuf.append("?");

                if (MessageDialog.openConfirm(null, "Delete", msgBuf.toString())) {
                    //case: not the root node
                    for (int i = allNodes.length - 1; i >= 0; i--) {
                        ITdoNode parent = (ITdoNode)allNodes[i].getParent();
                        parent.removeChild(allNodes[i]);
                    }

                    // don't forget to call this
                    refreshKTable();

                    updateDirtyFlag(true);
                }
		    }
		}
	}

   @Override
    protected void onSelectionChange(IAction action, ISelection selection2) {
        if (!isContinuousSelection()) {
            action.setEnabled(false);
        } else if (!isAllChildrenInSelection()) {
            action.setEnabled(false);
        }
    }
}
