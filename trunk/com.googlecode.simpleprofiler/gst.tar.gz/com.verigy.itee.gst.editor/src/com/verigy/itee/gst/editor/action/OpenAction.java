/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;

import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 * @author alanlin
 *
 */
public class OpenAction extends AbstractGSTAction {
	/**
	 * Default constructor
	 */
	public OpenAction() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
	 */
	@Override
	public void run(IAction action) {
		ITdoNode selectedNode = getFirstSelectedNode();

		// according to original syntax
		//OpenEditorUtil.openFileOfSelectedNode1(selectedNode);

		// according to new syntax, the device in TRON directory, ex11
		// always use the relative path against currently editing file.
		//OpenEditorUtil.openFileOfSelectedNode(selectedNode);
	}

	@Override
	protected void onSelectionChange(IAction action, ISelection selection2) {
		if (getSizeOfSelectedElements() > 1) {
			action.setEnabled(false);
		}
	}
}
