package com.verigy.itee.gst.editor.model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XmlModel {

	private String filePath;

	private Document doc;

	private IGenericNode root;

	public XmlModel(String filePath) {
		this.filePath = filePath;
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		docFactory.setIgnoringElementContentWhitespace(true);
		DocumentBuilder docBuilder;
		doc = null;
		try {
			docBuilder = docFactory.newDocumentBuilder();
			 doc = docBuilder.parse(filePath);
		} catch (ParserConfigurationException e1) {
			e1.printStackTrace();
		} catch (SAXException e) {
			System.err.println("This is not a valid xml file.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void createRoot(IGenericNode parent, NodeList nodeList) {
		if(nodeList == null || nodeList.getLength() == 0) {
            return;
        }
		for(int i=0; i<nodeList.getLength(); i++) {
			Node item = nodeList.item(i);
			if(Node.ELEMENT_NODE == item.getNodeType() &&
					item.getChildNodes().getLength() == 1 &&
					Node.TEXT_NODE == item.getChildNodes().item(0).getNodeType()) {
				parent.addChild(new GenericNodeImpl(item, parent));
			}else if(Node.ELEMENT_NODE == item.getNodeType() &&
					item.getChildNodes().getLength() == 0) {
				parent.addChild(new GenericNodeImpl(item, parent));
			}else if(item.getChildNodes().getLength() > 0 ) {
				IGenericNode node = new GenericNodeImpl(item, parent);
				parent.addChild(node);
				createRoot(node, item.getChildNodes());
			}
    	}
	}

	public IGenericNode getRootNode() {
		if(null == root && null != doc) {
			doc.getDocumentElement().normalize();
			Node rootElement = doc.getDocumentElement();
			root = new GenericNodeImpl(rootElement, null);
			createRoot(root, rootElement.getChildNodes());
		}
		return root;
	}

	public List<String> getUIFormat() {
		List<String> formatList = new ArrayList<String>();
		Node rootElement = doc.getDocumentElement();
		if(null != rootElement && rootElement.hasAttributes()) {
			if(null == rootElement.getAttributes().getNamedItem("format")) {
                return formatList;
            }
			String formats = rootElement.getAttributes().getNamedItem("format").getNodeValue();
			if(null != formats) {
				String[] array = formats.split(",");
				for(int i=0; null != array && i<array.length; i++) {
                    formatList.add(array[i].trim());
                }
			}
		}
		return formatList;
	}

	public void setUIFormat(String[] formats) {
		if (formats == null || formats.length == 0) {
			return;
		}

		Node specNode = doc.getElementsByTagName("spec").item(0);
		if(null != specNode) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < formats.length; i++) {
				sb.append(formats[i]);
				if (i != (formats.length - 1)) {
					sb.append(",");
				}
			}

			((Element) specNode).setAttribute("format", sb.toString());
		}
	}

	public void save() throws TransformerException {
		performSave(filePath);
	}

	public void save(String newFilePath) throws TransformerException {
		filePath = newFilePath;
		performSave(filePath);
	}

	public Document getDocument() {
		return doc;
	}
	/**
	 * @throws TransformerFactoryConfigurationError
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	private void performSave(String theFilePath) throws TransformerFactoryConfigurationError,
		TransformerConfigurationException, TransformerException {
		DOMSource domSource = new DOMSource(doc);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

        // for pretty print
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

        StreamResult sr = new StreamResult(new File(theFilePath));
        transformer.transform(domSource, sr);
	}
}
