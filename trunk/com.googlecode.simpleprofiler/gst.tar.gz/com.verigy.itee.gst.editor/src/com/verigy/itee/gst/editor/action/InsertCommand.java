package com.verigy.itee.gst.editor.action;

import com.verigy.itee.gst.editor.model.FloatingTdoNode;
import com.verigy.itee.gst.editor.model.TdoNodeFactory;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 * @author bennwang
 *
 */
public class InsertCommand extends AbstractGSTHanlder {

    @Override
    protected ITdoNode operate(ITdoNode node) {
        if(null == node) {
            return node;
        }
        String parameter = (String)getParameters().get("com.verigy.itee.gst.editor.commandpara.insert");
        if(null == parameter) {
            return node;
        }
        FloatingTdoNode floatingTdoNode = null;
        //If the node is the root node in TDE
        if(node.isRoot()) {
            floatingTdoNode = (FloatingTdoNode)TdoNodeFactory.getInstance().createFloatingTdoNode(node);
            floatingTdoNode.setNodeType(GenericNodeType.UNKNOWN);
            //Always add the floating node as the first child
            node.addChild(floatingTdoNode,0);
            return floatingTdoNode;
        }
        //TODO Benny check the object cast
        floatingTdoNode = (FloatingTdoNode)TdoNodeFactory.getInstance().createFloatingTdoNode((ITdoNode)node.getParent());
        floatingTdoNode.setNodeType(GenericNodeType.UNKNOWN);
        ITdoNode parent = (ITdoNode)node.getParent();
        int index = parent.getChildren().indexOf(node);
        if(-1 == index) {
            return node;
        }
        if("ABOVE".equals(parameter)) {
            parent.addChild(floatingTdoNode, index);
        }else if ("BELOW".equals(parameter)) {
            parent.addChild(floatingTdoNode, index+1);
        }
        return floatingTdoNode;
    }

}
