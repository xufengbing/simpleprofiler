package com.verigy.itee.gst.editor.model;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import xoc.ate.ext.specsheet.ZAttribute;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.IDService;

public class GenericNodeFactory {

	static private GenericNodeFactory instance = null;

	protected GenericNodeFactory () {

	}

	static public GenericNodeFactory getInstance() {
		if (null == instance) {
            instance = new GenericNodeFactory();
        }
		return instance;
	}

	public IGenericNode createGenericNode(IGenericNode parent, GenericNodeType nodeType) {

	    return null;
	}

	public xoc.ate.ext.configurationsheet.ZAttribute[] createAttributesInConfig(GenericNodeType type) {
	    xoc.ate.ext.configurationsheet.ZAttribute[] attributes = null;
	    return attributes;
	}

	public ZAttribute[] createAttributesInSpec(GenericNodeType type) {
	    ZAttribute[] attributes = null;
	    if(type == GenericNodeType.IMPORT) {
	        attributes = new ZAttribute[2];
	        attributes[0] = new ZAttribute();
	        attributes[0].key = IDService.getInstance().getId("val");
	        attributes[0].value = "newImport";
	        attributes[1] = new ZAttribute();
	        attributes[1].key = IDService.getInstance().getId("comm");
	        attributes[1].value = "newComm";
	    } else if (type == GenericNodeType.VAR) {
	        attributes = new ZAttribute[3];
	        attributes[0] = new ZAttribute();
            attributes[0].key = IDService.getInstance().getId("id");
            attributes[0].value = "newVar";
            attributes[1] = new ZAttribute();
            attributes[1].key = IDService.getInstance().getId("val");
            attributes[1].value = "newVal";
            attributes[2] = new ZAttribute();
            attributes[2].key = IDService.getInstance().getId("comm");
            attributes[2].value = "newComm";
	    }else if (type == GenericNodeType.RES) {
            attributes = new ZAttribute[1];
            attributes[0] = new ZAttribute();
            attributes[0].key = IDService.getInstance().getId("id");
            attributes[0].value = "newRes";
        }else if (type == GenericNodeType.SET) {
            attributes = new ZAttribute[2];
            attributes[0] = new ZAttribute();
            attributes[0].key = IDService.getInstance().getId("id");
            attributes[0].value = "newSet";
            attributes[1] = new ZAttribute();
            attributes[1].key = IDService.getInstance().getId("label");
            attributes[1].value = "1";
        }else if (type == GenericNodeType.PROP) {
            attributes = new ZAttribute[2];
            attributes[0] = new ZAttribute();
            attributes[0].key = IDService.getInstance().getId("id");
            attributes[0].value = "newProp";
            attributes[1] = new ZAttribute();
            attributes[1].key = IDService.getInstance().getId("val");
            attributes[1].value = "";
        }

	    return attributes;
	}

	public Node createNode(IGenericNode parent, GenericNodeType nodeType) {
	    if(!(parent instanceof GenericNodeImpl)) {
            return null;
        }
		Document xmlDocument = ((GenericNodeImpl)parent).getDocument();
		Node node = null;
		switch (nodeType) {
		case IMPORT:    //<import val="ImportedSpecSheet" comm="This is an &quot;import&quot; statement"/>
			Node xmlNode = xmlDocument.createElement("import");
			((Element)xmlNode).setAttribute("val", "");
			((Element)xmlNode).setAttribute("comm", "");
			node = xmlNode;
			break;
		case VAR:		 //<var id="edgeResolution" val="2 ns" comm="This is a variable assignment"/>
			xmlNode = xmlDocument.createElement("var");
			((Element)xmlNode).setAttribute("id", "var");
			((Element)xmlNode).setAttribute("val", "value");
			((Element)xmlNode).setAttribute("comm", "");
			node = xmlNode;
			break;
		case RES:		// <res id="pin1,pin3" comm="This should end up before pin2">
			xmlNode = xmlDocument.createElement("res");
			((Element)xmlNode).setAttribute("id", "pin1,pin2");
			((Element)xmlNode).setAttribute("comm", "");
			node = xmlNode;
			break;
		case SET:	// <set id="timing" label="1">
			xmlNode = xmlDocument.createElement("set");
			((Element)xmlNode).setAttribute("id", "timing");
			((Element)xmlNode).setAttribute("label", "1");
			((Element)xmlNode).setAttribute("comm", "");
			node = xmlNode;
			break;
		case PROP://      <prop id="period" val="10 * edgeResolution" comm="period depends on edge resolution"/>
			xmlNode = xmlDocument.createElement("prop");
			((Element)xmlNode).setAttribute("id", "period");
			((Element)xmlNode).setAttribute("val", "2 power 2");
			((Element)xmlNode).setAttribute("comm", "");
			node = xmlNode;
			break;
		default:
			break;
		}

		return node;
	}
}
