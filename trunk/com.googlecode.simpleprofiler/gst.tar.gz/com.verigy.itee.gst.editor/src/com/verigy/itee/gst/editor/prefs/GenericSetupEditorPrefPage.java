/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.prefs;

import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.verigy.itee.gst.editor.Activator;

/**
 * @author alanlin
 */
public class GenericSetupEditorPrefPage extends FieldEditorPreferencePage implements
        IWorkbenchPreferencePage {

    private ColorFieldEditor importColor;
    private ColorFieldEditor resourceColor;
    private ColorFieldEditor variableColor;
    private ColorFieldEditor setColor;
    private ColorFieldEditor propertyColor;
    private SelectionPatternFieldEditor selectionPatternFieldEditor;

    /**
     * default constructor
     */
    public GenericSetupEditorPrefPage() {
        super(GRID);
        setPreferenceStore(Activator.getDefault().getPreferenceStore());
    }

    @Override
    public void init(IWorkbench workbench) {
        // do nothing
    }

    @Override
    protected void createFieldEditors() {
        importColor = createColorFieldEditor(PreferenceConstants.IMPORT_TYPE,
                "Import:", getFieldEditorParent());
        addField(importColor);

        resourceColor = createColorFieldEditor(PreferenceConstants.RES_TYPE,
                "Resource:", getFieldEditorParent());
        addField(resourceColor);

        variableColor = createColorFieldEditor(PreferenceConstants.VAR_TYPE,
                "Variable:", getFieldEditorParent());
        addField(variableColor);

        setColor = createColorFieldEditor(PreferenceConstants.SET_TYPE,
                "Set:", getFieldEditorParent());
        addField(setColor);

        propertyColor = createColorFieldEditor(PreferenceConstants.PROP_TYPE,
                "Property:", getFieldEditorParent());
        addField(propertyColor);

        selectionPatternFieldEditor = createSelectionPatternFieldEditor(
                PreferenceConstants.SELECTION_PATTERN, "Selection Pattern",
                getFieldEditorParent());
        addField(selectionPatternFieldEditor);
    }

    /**
     * Creates a new color field editor.
     */
    private ColorFieldEditor createColorFieldEditor(String preferenceName, String label, Composite parent) {
        ColorFieldEditor editor = new ColorFieldEditor(preferenceName, label, parent);
        editor.setPage(this);
        editor.setPreferenceStore(getPreferenceStore());
        return editor;
    }

    private SelectionPatternFieldEditor createSelectionPatternFieldEditor(String preferenceName, String label, Composite parent) {
        SelectionPatternFieldEditor editor = new SelectionPatternFieldEditor(preferenceName, label, parent);
        editor.setPage(this);
        editor.setPreferenceStore(getPreferenceStore());
        return editor;
    }
}
