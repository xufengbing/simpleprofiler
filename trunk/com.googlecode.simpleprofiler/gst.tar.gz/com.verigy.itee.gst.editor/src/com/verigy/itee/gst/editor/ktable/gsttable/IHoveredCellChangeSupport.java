/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.gsttable;

import org.eclipse.swt.graphics.Point;

/**
 * @author alanlin
 */
interface IHoveredCellChangeSupport {
	/**
	 * @return Returns the cell position above which is the mouse
	 */
	public Point getHoveredCell();
	
	/**
	 * Adds the listener for listening the hovered cell change event.
	 * @param listener the listener which is interested in the hovered cell change.
	 */
	public void addHoveredCellChangeListener(KHoverCellChangeListener listener);
	
	/**
	 * Removes the listener which is added previous for the hovered cell change event.
	 * If the specified listener is not contained in the registered listeners, nothing
	 * happens.
	 * @param listener the listner which should be removed from the list.
	 */
	public void removeHoveredCellChangedListener(KHoverCellChangeListener listener);
}
