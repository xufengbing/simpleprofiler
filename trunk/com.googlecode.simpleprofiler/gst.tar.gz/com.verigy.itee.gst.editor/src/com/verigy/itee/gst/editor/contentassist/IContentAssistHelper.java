/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.contentassist;

import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 * @author alanlin
 */
public interface IContentAssistHelper {
    /**
     * Identifier type
     * @author alanlin
     */
    public static enum IdentifierType {
        /**
         * Import type
         */
        IMPORT,
        /**
         * Variable type
         */
        VARIABLE,
        /**
         * Resource type
         */
        RESOURCE;
    }

    /**
     * @param node
     * @return
     */
    public String[] getContentAssistFor(ITdoNode node);

    /**
     * @param node
     * @return
     */
    public String[] getValueProposalsFor(ITdoNode node);

    /**
     * Query all available identifiers for specified type. The specified type
     * should be either one of {@linkplain IdentifierType}.These identifiers will
     * be queried each time since the content may change during editting.
     * @param idType the specified type.
     * @return Returns all available identifiers or empty array. No <code>null</code>
     * will be returned.
     */
    public String[] getAllIdentifiers(IdentifierType idType);

    /**
     * Query all possible union for inputed querier. The information is static.
     * @param querier the querier
     * @return Returns all available union or empty array. No <code>null</code>
     * will be returned.
     */
    public String[] getAllUnionOf(String querier);
}
