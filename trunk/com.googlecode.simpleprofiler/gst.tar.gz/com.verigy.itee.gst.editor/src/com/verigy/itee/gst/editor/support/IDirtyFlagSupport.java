/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.support;

/**
 * @author alanlin
 *
 */
public interface IDirtyFlagSupport {
	public void setDirty(boolean flag);
}
