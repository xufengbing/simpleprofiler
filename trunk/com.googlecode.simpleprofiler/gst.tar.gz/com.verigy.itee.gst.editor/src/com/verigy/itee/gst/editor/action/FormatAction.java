/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.IFormPage;

import com.verigy.itee.gst.editor.dialogs.FormatSelectionDialog;
import com.verigy.itee.gst.editor.editors.GSTEditorATEKTable;
import com.verigy.itee.gst.editor.editors.GSTFilterFormPage;
import com.verigy.itee.gst.editor.ktable.model.IUdaObjectOperationSupport;
import com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.utils.Util;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;

/**
 * @author alanlin
 */
public class FormatAction extends AbstractUpdatableAction {

	public FormatAction() {
		// do nothing
	}


	@Override
	protected boolean doRun(IAction action) {
		ITdoNode rootNode = getRootNodeOfActiveEditor();
		IZTestDataNode superNode = Util.convertToTDENode(getEditFile());
		if (superNode instanceof IUTDEntity) {
			IUTDEntity tdeEntity = (IUTDEntity) superNode;
            Set<String> currentFormats = getUIFormatFrom(tdeEntity);
			Set<String> allAvailableFormats = new LinkedHashSet<String>();

			HashSet<String> allFormats = new LinkedHashSet<String>();

			visit(rootNode, allFormats);

			allFormats.removeAll(currentFormats);
			allAvailableFormats.addAll(allFormats);

			FormatSelectionDialog dialog = new FormatSelectionDialog(PlatformUI
					.getWorkbench().getActiveWorkbenchWindow().getShell(),
					currentFormats, allAvailableFormats);
			if (dialog.open() == Window.OK) {
				Object[] results = dialog.getResult();

				if (results != null) {
					ISelection sel = getSelection();
					if (sel != null && sel instanceof StructuredSelection) {
						StructuredSelection structuredSelection = (StructuredSelection) sel;

						IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement)structuredSelection.getFirstElement();

						final KTable table = nodeSelection.getTable();
						if (table != null && !table.isDisposed()) {
							KTableModel model = table.getModel();

							List<String> formats = new ArrayList<String>();
							StringBuilder formatStr = new StringBuilder();
							if(results.length > 0) {
                                for (Object o : results) {
                                	String f = o.toString().trim();
                                    formats.add(f);
                                	formatStr.append(f);
                                	formatStr.append(", ");
                                }
                                formatStr.deleteCharAt(formatStr.length() - 1);
                                formatStr.deleteCharAt(formatStr.length() - 1);
                            }
							tdeEntity.setMetaData(formatStr.toString());
							((IUdaObjectOperationSupport) model).refreshKTableDataModel(rootNode, formats);
							return true;
						}
					}
				}
			}
		}

		return false;
	}


	@SuppressWarnings("null")
	private void visit(IZTestDataNode root, HashSet<String> allAvailableFormats) {
    	Stack<IZTestDataNode> stack = new Stack<IZTestDataNode>();
    	IZTestDataNode current = root;
    	while(current != null || !stack.isEmpty()) {
    		// A trick here
    		if (!current.hasChild() && GenericNodeType.PROP.equals(((ITdoNode)current).getNodeType())) {
    			allAvailableFormats.add(current.getName());
    		}

    		if (current.hasChild()) {
	    		for (int i = current.getChildren().size() - 1; i >= 0 ; i--) {
	    			IZTestDataNode child = current.getChildren().get(i);
	    			stack.push(child);
	    		}
	    		current = null;
    		} else {
    			if (stack.size() > 0) {
    				current = stack.pop();
    			} else {
    				current = null;
    			}
    		}

    		if (stack.size() > 0 && current == null) {
    			current = stack.pop();
    		}
    	}
    }

    private Set<String> getUIFormatFrom(IUTDEntity tdeEntity) {
        Set<String> format = new HashSet<String>();
        String metaData = tdeEntity.getMetaData();

        if (!metaData.isEmpty()) {
            String[] columns = metaData.split("[,|;| ]");
            for (String c : columns) {
                if (!c.trim().isEmpty()) {
                    format.add(c.trim());
                }
            }
        }

        return format;
    }

	private ITdoNode getRootNodeOfActiveEditor() {
        IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow()
                .getActivePage().getActiveEditor();

        if (editor instanceof GSTEditorATEKTable) {
            return ((GSTEditorATEKTable) editor).getRootNode();
        } else if (editor instanceof FormEditor) {
            IFormPage activePage = ((FormEditor) editor).getActivePageInstance();
            if (activePage instanceof GSTFilterFormPage) {
                return ((GSTFilterFormPage) activePage).getRootNode();
            }
        }
	    return null;
	}

    private IFile getEditFile() {
        IEditorPart editor = PlatformUI.getWorkbench().getActiveWorkbenchWindow()
                .getActivePage().getActiveEditor();

        IEditorInput input = editor.getEditorInput();

        if (input instanceof IFileEditorInput) {
            return ((IFileEditorInput) input).getFile();
        }
        return null;
    }
}
