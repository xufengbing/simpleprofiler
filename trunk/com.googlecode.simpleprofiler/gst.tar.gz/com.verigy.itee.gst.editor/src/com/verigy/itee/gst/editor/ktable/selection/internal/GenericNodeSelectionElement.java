/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.selection.internal;

import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.editor.ktable.model.IFilterSupport;
import com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement;
import com.verigy.itee.gst.editor.ktable.selection.SelectionType;
import com.verigy.itee.gst.editor.model.IGenericNode;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.utils.FuncUtil;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;

/**
 * The implementation of {@linkplain IGenericNodeSelectionElement}.
 * @author alanlin
 */
public class GenericNodeSelectionElement implements
		IGenericNodeSelectionElement {

	private final IGenericNode node;
	private final ITdoNode tdoNode;
	private final String column;
	private final SelectionType selType;
	private final KTable table;
	private final IEditorPart editor;
	private final int modelRowIndex;

	/**
	 * The constructor for the old proto.
	 * @param table the table which contains the selection element.
	 * @param editor the editor in which the selection is triggered.
	 * @param node the node which is selected.
	 * @param column the column of the selection.
	 * @param selType the selection type.
	 */
	public GenericNodeSelectionElement(KTable table, IEditorPart editor, IGenericNode node, String column, SelectionType selType) {
		this.table = table;
		this.editor = editor;
		this.node = node;
		this.column = column;
		this.selType = selType;
		this.tdoNode = null;
		this.modelRowIndex = -1;
	}

	/**
     * The constructor for the new proto
     * @param table the table which contains the selection element.
     * @param editor the editor in which the selection is triggered.
     * @param tdoNode the node which is selected.
     * @param column the column of the selection.
     * @param selType the selection type.
	 * @param modelRowIndex the index in the table model
     */
    public GenericNodeSelectionElement(KTable table, IEditorPart editor, ITdoNode tdoNode, String column, SelectionType selType, int modelRowIndex) {
        this.table = table;
        this.editor = editor;
        this.node = null;
        this.column = column;
        this.selType = selType;
        this.tdoNode = tdoNode;
        this.modelRowIndex = modelRowIndex;
    }

	/* (non-Javadoc)
	 * @see com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement#getColumn()
	 */
	@Override
	public String getColumn() {
		return column;
	}

	/* (non-Javadoc)
	 * @see com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement#getSelectionType()
	 */
	@Override
	public SelectionType getSelectionType() {
		return selType;
	}


	/* (non-Javadoc)
	 * @see com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement#getType()
	 */
	@Override
	public GenericNodeType getType() {
		return node == null ? tdoNode.getNodeType() : node.getNodeType();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IActionFilter#testAttribute(java.lang.Object, java.lang.String, java.lang.String)
	 */
	@Override
	public boolean testAttribute(Object target, String name, String value) {
		if (!(target instanceof IGenericNodeSelectionElement)) {
			return false;
		}

        IGenericNodeSelectionElement selectedElement = (IGenericNodeSelectionElement) target;

		if (TAG_HASVAR.equals(name)) {
		    String content = "";
		    if (selectedElement.getElement() != null) {
		        content = selectedElement.getElement().getValue();
		    } else {
		        content = selectedElement.getSelectedNode().getValue();
		    }
		    boolean hasVar = hasVariable(content);
		    return Boolean.valueOf(value).booleanValue() == hasVar;
		}

		if (TAG_BELONGTO.equals(name)) {
		    GenericNodeType type = GenericNodeType.valueOf(value);
		    return GenericNodeType.UNKNOWN == type ? false : type.equals(belongTo());
		}

		if (TAG_FILTERED.equals(name)) {
		    KTableModel model = selectedElement.getTable().getModel();
		    if (model instanceof IFilterSupport) {
		        boolean filtered = !((IFilterSupport) model).getFilter().isEmpty();
		        return Boolean.valueOf(value).equals(filtered);
		    }
		    return true;
		}

		String testAttr = null;
		if (TAG_TYPE.equals(name)) {
			testAttr = getType().toString().toUpperCase();
		}

		if (TAG_COLUMN.equals(name)) {
			testAttr = getColumn();
		}

		if (TAG_SELECTION_TYPE.equals(name)) {
			testAttr = getSelectionType().toString();
		}

		return isStringIn(testAttr, getSplitedValues(value));
	}

    private boolean hasVariable(String value) {
        boolean hasVar = false;
        String[] allElements = FuncUtil.retrieveVarInExpression(value);

        for (String ele : allElements) {
            try {
                Integer.valueOf(ele);
            } catch (NumberFormatException exp) {
                hasVar = true;
                break;
            }
        }

        return hasVar;
    }

    private String[] getSplitedValues(String value) {
		 return value.split("[;|:|,]");
	}

	private boolean isStringIn(String str, String[] strSet) {
		if (str == null || strSet != null) {
			for (String s : strSet) {
				if(s.equals(str)) {
					return true;
				}
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.core.runtime.IAdaptable#getAdapter(java.lang.Class)
	 */
	@Override
	public Object getAdapter(Class adapter) {
		if (IGenericNode.class == adapter) {
			return node;
		}
		return null;
	}

	@Override
	public IGenericNode getElement() {
		return node;
	}

	private final static String TAG_TYPE = "type";
	private final static String TAG_COLUMN = "column";
	private final static String TAG_SELECTION_TYPE = "selectionType";
	private final static String TAG_HASVAR = "hasVar";
	private final static String TAG_BELONGTO = "belongTo";
	private final static String TAG_FILTERED = "isFiltered";

	@Override
	public KTable getTable() {
		return table;
	}

	@Override
	public IEditorPart getEditor() {
		return editor;
	}

    @Override
    public GenericNodeType belongTo() {
        GenericNodeType result = GenericNodeType.UNKNOWN;
        IGenericNode node = getElement();
        if (node != null) {
            IGenericNode root = node.getRoot();
            if (root != null) {
                result = root.getNodeType();
            }
        } else {
            ITdoNode root = (ITdoNode)getSelectedNode().getRoot();
            if (root != null) {
                result = root.getNodeType();
            }
        }
        return result;
    }

    @Override
    public ITdoNode getSelectedNode() {
        return tdoNode;
    }

    @Override
    public int getModelRowIndex() {
        return modelRowIndex;
    }
}
