/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.support;

import com.verigy.itee.gst.editor.model.XmlModel;

/**
 * @author alanlin
 *
 */
public interface IQueryXmlNode {
	public XmlModel getXmlModel();
}
