/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.handlers.HandlerUtil;

import com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement;
import com.verigy.itee.gst.editor.model.IGenericNode;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.utils.FuncUtil;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author alanlin
 *
 */
public class GoToDeclarationHandler extends AbstractHandler {

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        ISelection selection = HandlerUtil.getActiveWorkbenchWindow(event)
                .getActivePage().getSelection();
        if (selection instanceof IStructuredSelection) {
            StructuredSelection structuredSelection = (StructuredSelection) selection;
            IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement) structuredSelection
                    .getFirstElement();
            IGenericNode node = nodeSelection == null ? null : nodeSelection.getElement();
            ITdoNode tdoNode = nodeSelection == null ? null : nodeSelection.getSelectedNode();

            String content = "";
            if (node != null) {
                content = node.getValue();
            } else if (tdoNode != null) {
                content = tdoNode.getValue();
            }

            String[] vars = FuncUtil.filterDigitalElements(FuncUtil
                    .retrieveVarInExpression(content));

            Util.goToDeclarationOf(vars);

        }

        return null;
    }
}
