/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.prefs;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.graphics.RGB;

import com.verigy.itee.gst.editor.Activator;

/**
 * @author alanlin
 */
public class PreferenceInitializer extends AbstractPreferenceInitializer {

    /**
     * Constructor
     */
    public PreferenceInitializer() {
        super();
    }

    @Override
    public void initializeDefaultPreferences() {
        IPreferenceStore store = Activator.getDefault().getPreferenceStore();

//        PreferenceConverter.setDefault(store, PreferenceConstants.IMPORT_TYPE,
//                new RGB(197, 198, 199));
//        PreferenceConverter.setDefault(store, PreferenceConstants.VAR_TYPE,
//                new RGB(202, 238, 157));
//        PreferenceConverter.setDefault(store, PreferenceConstants.RES_TYPE,
//                new RGB(234, 243, 185));
//        PreferenceConverter.setDefault(store, PreferenceConstants.SET_TYPE,
//                new RGB(156, 200, 243));
//        PreferenceConverter.setDefault(store, PreferenceConstants.PROP_TYPE,
//                new RGB(209, 233, 234));
        PreferenceConverter.setDefault(store, PreferenceConstants.IMPORT_TYPE,
                new RGB(255, 255, 255));
        PreferenceConverter.setDefault(store, PreferenceConstants.VAR_TYPE,
                new RGB(255, 255, 255));
        PreferenceConverter.setDefault(store, PreferenceConstants.RES_TYPE,
                new RGB(255, 255, 255));
        PreferenceConverter.setDefault(store, PreferenceConstants.SET_TYPE,
                new RGB(255, 255, 255));
        PreferenceConverter.setDefault(store, PreferenceConstants.PROP_TYPE,
                new RGB(255, 255, 255));

        store.setDefault(PreferenceConstants.SELECTION_PATTERN, "Auto");
    }

}
