/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.editors;

import java.util.Set;

import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.editor.FormEditor;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * @author bennwang
 *
 */
public class GSTFilterPageFactory {

    private static GSTFilterPageFactory INSTANCE = null;

    private GSTFilterPageFactory () {
        //do nothing
    }

    /**
     * Get the singleton
     * @return The singleton
     */
    public static GSTFilterPageFactory getInstance() {
        if(null == INSTANCE) {
            INSTANCE = new GSTFilterPageFactory();
        }
        return INSTANCE;
    }

    /**
     * Create a new page and add it to the editor
     * @param editor Target editor
     * @return Returns the page id of the newly created form page
     */
    public String createPage(final FormEditor editor, final Set<GenericNodeType> filter) {
        assert(editor != null);

        String pageId = generatePageId();
        GSTFilterFormPage newPage = new GSTFilterFormPage(editor, pageId, "new page", filter);
        try {
            editor.addPage(newPage);
        } catch (PartInitException e) {
            // LOG.logError("TODO", e);
            return null;
        }

        return pageId;
    }

    private String generatePageId() {
        return pageIdPrefix + String.valueOf(generatorIndex++);
    }
    private static int generatorIndex = 0;
    private static String pageIdPrefix = "FilterPage_";
}
