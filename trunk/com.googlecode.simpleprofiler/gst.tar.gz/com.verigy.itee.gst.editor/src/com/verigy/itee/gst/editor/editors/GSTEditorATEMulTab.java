/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.editors;

import java.util.HashSet;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.IFormPage;

import com.verigy.itee.gst.editor.Activator;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.utils.GSTEditorInput;

/**
 * @author bennwang
 *
 */
public class GSTEditorATEMulTab extends FormEditor {


    private final Image configsheetIcon = JFaceResources.getResources().
            createImage(Activator.getDefault().getImageDescriptor("icons/configsheet.png"));

    private final Image specsheetIcon = JFaceResources.getResources().
            createImage(Activator.getDefault().getImageDescriptor("icons/specsheet.gif"));

    @Override
    protected void addPages() {
        try {
            addPage(new GSTFilterFormPage(this, "GST page 1", getTitle(), new HashSet<GenericNodeType>()));
//            addPage(new GSTFilterFormPage(this, "GST page 1", getTitle(), GenericNodeType.PROP));
//            addPage(new GSTFilterFormPage(this, "GST page 1", getTitle(), GenericNodeType.SET));
        } catch (PartInitException e) {
            // LOG.logError("TODO", e);
        }

    }

    @Override
    public int addPage(IFormPage page) throws PartInitException {
        int index = super.addPage(page);
        if(0 != index) {
            (((CTabFolder)getContainer()).getItem(index)).setShowClose(true);
        }
        return index;
    }


    @Override
    public void doSave(IProgressMonitor monitor) {
        // TODO Auto-generated method stub

    }

    @Override
    public void doSaveAs() {
        // TODO Auto-generated method stub

    }


    @Override
    public void init(IEditorSite site, IEditorInput input) throws PartInitException {
        setSite(site);
        setInput(input);
        setPartName(input.getName());
    }


    @Override
    public boolean isSaveAsAllowed() {
        // TODO Auto-generated method stub
        return false;
    }


    @Override
    public Image getTitleImage() {
        final IEditorInput input = getEditorInput();
        assert (null != input);
        if (input instanceof GSTEditorInput) {
            String type = ((GSTEditorInput) input).getType();
            if ("CFG".equals(type)) {
                return configsheetIcon;
            } else if ("SPEC".equals(type)) {
                return specsheetIcon;
            }
        }

        return super.getTitleImage();
    }
}
