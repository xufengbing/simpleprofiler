/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.selection.internal;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.ui.IActionFilter;

/**
 * @author alanlin
 *
 */
public class GenericNodePropertyTester extends PropertyTester {
    @Override
    public boolean test(Object receiver, String property, Object[] args,
            Object expectedValue) {
        if (receiver instanceof IActionFilter) {
            return ((IActionFilter) receiver).testAttribute(receiver, property, expectedValue.toString());
        }
        return false;
    }
}
