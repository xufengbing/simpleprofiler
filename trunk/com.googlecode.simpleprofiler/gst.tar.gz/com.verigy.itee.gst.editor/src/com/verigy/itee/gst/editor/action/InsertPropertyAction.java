/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;

/**
 * @author alanlin
 *
 */
public class InsertPropertyAction extends AbstractUpdatableAction {

    /**
     * 
     */
    public InsertPropertyAction() {
        super();
    }

    @Override
    protected boolean doRun(IAction action) {
        // TODO Auto-generated method stub
        return false;
    }

}
