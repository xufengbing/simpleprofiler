/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;

/**
 * @author alanlin
 *
 */
public class AddInstrumentAction extends AbstractUpdatableAction {

    /**
     * Default constructor
     */
    public AddInstrumentAction() {
        super();
    }

    @Override
    protected boolean doRun(IAction action) {
        // TODO add implementation
        return true;
    }
}
