package com.verigy.itee.gst.editor.model;

import java.util.List;
import java.util.Map;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * An interface for UI to operate the model from xml file
 *
 * @author bennwang
 *
 */
public interface IGenericNode {

	/**
	 * Get the parent node
	 *
	 * @return {@link IGenericNode}
	 */
	public IGenericNode getParent();

	/**
	 * Get the root node
	 *
	 * @return {@link IGenericNode}
	 */
	public IGenericNode getRoot();

	/**
	 * Check if this node is the root node
	 *
	 * @return boolean
	 */
	public boolean isRoot();

	/**
	 * Get the children nodes of this node
	 *
	 * @return {@link List}
	 */
	public List<IGenericNode> getChildren();

	/**
	 * Get the child node according to the node name
	 * @param name node name
	 * @return child node has the name
	 */
	public IGenericNode getChild(String name);

	/**
	 * Remove a child node
	 *
	 * @param child to be remove
	 */
	public void removeChild(IGenericNode child);

	/**
	 * Append a child to the children list
	 *
	 * @param child to be added
	 */
	public void addChild(IGenericNode child);

    /**
     * Add a child node to the specific position according to its successor
     *
     * @param child to be added
     * @param successor successor node
     */
    void addChild(IGenericNode child, IGenericNode successor);


	/**
	 * Check if this node has child or not
	 *
	 * @return bolean
	 */
	public boolean hasChild();

	/**
	 * Check if this node has an attribute
	 *
	 * @return boolean
	 */
	public boolean hasAttribute();

	/**
	 * Get the node name
	 *
	 * @return the node name
	 */
	public String getName();

	/**
	 * Set the a new name for the node
	 *
	 * @param newName new name
	 * @return boolean
	 */
	public boolean setName(String newName);

	/**
	 * Get the node value
	 *
	 * @return the value
	 */
	public String getValue();

	/**
	 * Get the node type
	 *
	 * @return {@link GenericNodeType}
	 */
	public GenericNodeType getNodeType();

	/**
	 * Set the new value for this node
	 * @param newValue new value
	 * @return boolean
	 */
	public boolean setValue(String newValue);

	/**
	 * Get the attributes of this node
	 *
	 * @return {@link Map}
	 */
	public Map<String, String> getAttributes();

	public String getTypeChain();

}
