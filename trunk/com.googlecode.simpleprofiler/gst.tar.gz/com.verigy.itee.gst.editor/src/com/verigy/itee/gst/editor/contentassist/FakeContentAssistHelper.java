/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.contentassist;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import com.verigy.itee.gst.editor.contentassist.FakeModelInfo.StructureInfo;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

/**
 * @author alanlin
 */
public class FakeContentAssistHelper implements IContentAssistHelper {
    private static FakeContentAssistHelper instance;

    /**
     * @return Returns the instance of this class
     */
    public static FakeContentAssistHelper getInstance() {
        if (instance == null) {
            instance = new FakeContentAssistHelper();
        }

        return instance;
    }

    /**
     * Default Constructor
     */
    protected FakeContentAssistHelper() {
        super();
        initializeFakeData();
    }

    @Override
    public String[] getAllIdentifiers(IdentifierType idType) {
        if (IdentifierType.IMPORT.equals(idType)) {
            return allTDEs.toArray(new String[allTDEs.size()]);
        }
        if (IdentifierType.VARIABLE.equals(idType)) {
            return allVariables.toArray(new String[allVariables.size()]);
        }
        if (IdentifierType.RESOURCE.equals(idType)) {
            return allResources.toArray(new String[allResources.size()]);
        }
        return new String[0];
    }

    @Override
    public String[] getAllUnionOf(String querier) {
        String[] result = new String[0];
        if (querier != null && !querier.isEmpty()) {
            FakeModelInfo modelInfo = new FakeModelInfo();
            FakeModelInfo.StructureInfo root = modelInfo.getRoot();

            String[] types = querier.split("[/]");
            StructureInfo node = root;
            for (int i = 0; i < types.length - 1; i++) {
                if ("UNKNOWN".equals(types[i])) {
                    node = root.getChildWithTypeName("SPEC");
                    continue;
                }

                node = node.getChildWithTypeName(types[i]);
                if (node == null) {
                    break;
                }
            }

            if (node != null) {
                result = node.getChildrenNames();
            }
        }
        return result;
    }


    private void initializeFakeData() {
        allTDEs = new ArrayList<String>();
        allVariables = new ArrayList<String>();
        allResources = new ArrayList<String>();

        allTDEs.add("digConfig.cfg");
        allTDEs.add("employedLevel.spec");
        allTDEs.add("emptyLevel.spec");
        allTDEs.add("level.spec");
        allTDEs.add("timing.spec");
        allTDEs.add("wavetable.spec");

        allVariables.add("period");
        allVariables.add("bit");
        allVariables.add("delay");
        allVariables.add("sync1");
        allVariables.add("sync2");
        allVariables.add("lowswing");
        allVariables.add("hiswing");


        allResources.add("a0");
        allResources.add("a1");
        allResources.add("a2");
        allResources.add("a3");
        allResources.add("a4");
        allResources.add("a5");
        allResources.add("a6");
        allResources.add("a7");
        allResources.add("all_ios");
        allResources.add("CP");
        allResources.add("mode");
        allResources.add("ser_in");
        allResources.add("_MR");
        allResources.add("ser_out");
        allResources.add("io_pins");
    }

    private List<String> allTDEs;
    private List<String> allVariables;
    private List<String> allResources;

    @Override
    public String[] getContentAssistFor(ITdoNode node) {
        GenericNodeType type = node.getNodeType();
        if (GenericNodeType.PROP.equals(type) || GenericNodeType.SET.equals(type)) {
            return getAllUnionOf(getNodeTypeChain(node));
        }
        return getAllIdentifiers(getIdentifierType(type));
    }

    @Override
    public String[] getValueProposalsFor(ITdoNode node) {
        GenericNodeType type = node.getNodeType();
        if (GenericNodeType.PROP.equals(type)) {
            return getAllIdentifiers(IdentifierType.VARIABLE);
        }
        return new String[0];
    }

    /**
     * @param type
     * @return
     */
    private IdentifierType getIdentifierType(GenericNodeType type) {
        if (GenericNodeType.IMPORT.equals(type)) {
            return IdentifierType.IMPORT;
        }
        if (GenericNodeType.RES.equals(type)) {
            return IdentifierType.RESOURCE;
        }
        if (GenericNodeType.VAR.equals(type)) {
            return IdentifierType.VARIABLE;
        }
        return null;
    }

    private String getNodeTypeChain(ITdoNode node) {
        Stack<String> typeStack = new Stack<String>();
        IZTestDataNode point = node;
        while(point instanceof ITdoNode) {
            if (GenericNodeType.SET.equals(((ITdoNode)point).getNodeType())) {
                typeStack.push(point.getName());
            } else if (point.hasChild()) {
                typeStack.push(((ITdoNode)point).getNodeType().toString());
            } else {
                typeStack.push(point.getName());
            }
            point = point.getParent();
        }

        StringBuilder sb = new StringBuilder();
        while(!typeStack.empty()) {
            sb.append(typeStack.pop());
            sb.append('/');
        }
        return sb.toString();
    }
}
