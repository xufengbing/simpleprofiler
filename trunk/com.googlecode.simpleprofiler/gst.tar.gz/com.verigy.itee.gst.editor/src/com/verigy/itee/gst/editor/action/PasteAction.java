/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.graphics.Point;

import com.verigy.itee.gst.editor.model.TdoNodeFactory;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;

/**
 * @author alanlin
 */
public class PasteAction extends AbstractUpdatableAction {

	public PasteAction() {
		// do nothing
	}


	@Override
    protected boolean doRun(IAction action) {
	    if (isObjectSelectionMode()) {
            ITdoNode[] nodes = getSelectedNodes();
            if (null == nodes || nodes.length == 0) {
                return false;
            }

            ITdoNode selectedNode = nodes[0];
            Object content = ClipboardUtil.getClipboard().getContents(
                    GenericNodeTransfer.getInstance());
            Map<String, ITdoNode> map = new HashMap<String, ITdoNode>();
            if (content instanceof List<?>) {
                List<?> list = (List<?>) content;
                for (int i = 0; i < list.size(); i++) {
                    Object listObj = list.get(i);
                    if (listObj instanceof String) {
                        createNodeFromString(selectedNode, (String) listObj, map);
                    }
                }
                return true;
            }

	    } else {
	        KTable table = getTable();
	        if (table != null) {
	            pasteToSelection(table, getTextFromClipboard(table), table.getCellSelection());
	            return true;
	        }
	    }

        return false;
    }


    private ITdoNode createNodeFromString(ITdoNode selectedNode, String fieldStrings, Map<String, ITdoNode> createdMap) {
        String[] fields = fieldStrings.split(GenericNodeTransfer.FIELD_SEPARATOR);
        if (fields.length == 4) {
            ITdoNode parent = getParent(selectedNode, createdMap, fields[3]);

            ITdoNode newNode = TdoNodeFactory.getInstance().createTdoChildNode(
                    parent, GenericNodeType.convertFrom(fields[2]),
                    fields[0]);
            newNode.setValue(fields[1]);

            if (parent != null) {
                parent.addChild(newNode, 0);
            }

            createdMap.put(fields[3], newNode);

            return newNode;
        }

        return null;
    }

    private ITdoNode getParent(ITdoNode selectedNode, Map<String, ITdoNode> createdMap,
            String path) {
        int index = path.lastIndexOf(GenericNodeTransfer.PATH_SEPARATOR);
        String parentPath = index == -1 ? path : path.substring(0, index);

        ITdoNode node = createdMap.get(parentPath);
        ITdoNode parent = node == null? selectedNode : node;

        return parent;
    }

    @Override
    protected void onSelectionChange(IAction action, ISelection selection2) {
        boolean isObjectInClipboard = isTdoObjectInClipboard();
        boolean isObjectSelection = isObjectSelectionMode();
        if (isObjectInClipboard && isObjectSelection) {
            doOnObjectSelectionChange(action);
        } else if (isObjectInClipboard || isObjectSelection) {
            action.setEnabled(false);
        }
    }


    /**
     * @param action
     */
    private void doOnObjectSelectionChange(IAction action) {
        ITdoNode gn = getFirstSelectedNode();
        Object content = ClipboardUtil.getClipboard().getContents(
                GenericNodeTransfer.getInstance());

        boolean shouldDisable = false;
        if (gn != null && content instanceof List<?>) {
            List<?> list = (List<?>) content;
            if (list.size() > 0) {
                Object data = list.get(0);
                if (data instanceof String) {
                    String[] fields = ((String) data)
                            .split(GenericNodeTransfer.FIELD_SEPARATOR);
                    if (fields.length == 4) {
                        GenericNodeType typeForSelection = gn.getNodeType();
                        GenericNodeType typeForContentInClipboard = GenericNodeType
                                .convertFrom(fields[2]);
                        int levelForSelection = typeForSelection.getLevel();
                        int levelForContentInClipboard = typeForContentInClipboard
                                .getLevel();

                        int gap = levelForContentInClipboard - levelForSelection;

                        if (gap != 1) {
                            shouldDisable = true;
                        } else if (gap == 0
                                && !GenericNodeType.SET.equals(typeForSelection)) {
                            shouldDisable = true;
                        }
                    }
                }
            }
        }

        if (shouldDisable) {
            action.setEnabled(false);
        }
    }

    protected String getTextFromClipboard(KTable table) {
        Clipboard clipboard = new Clipboard(table.getDisplay());
        try {
            return clipboard.getContents(TextTransfer.getInstance()).toString();
        } catch (Exception ex) {
            return "";
        } finally {
            clipboard.dispose();
        }
    }

    protected void pasteToSelection(KTable table, String text, Point[] selection) {
        if (selection==null || selection.length==0) {
            return;
        }
        KTableModel model = table.getModel();
        if (model==null) {
            return;
        }

        try {
            table.setRedraw(false);
            table.setSelection(new Point[]{}, false);
            Vector sel = new Vector();

            String[][] cellTexts = parseCellTexts(table, text);
            for (int row=0; row<cellTexts.length; row++) {
                for (int col=0; col<cellTexts[row].length; col++) {
                    model.setContentAt(col+selection[0].x, row+selection[0].y, cellTexts[row][col]);
                    sel.add(new Point(col+selection[0].x, row+selection[0].y));
                }
            }
            table.setSelection((Point[])sel.toArray(new Point[]{}), false);
        } finally {
            table.setRedraw(true);
        }
    }
    protected String[][] parseCellTexts(KTable table, String text) {
        if (!table.isMultiSelectMode()) {
            return new String[][]{{text}};
        } else {
            String[] lines = text.split(PlatformLineDelimiter);
            String[][] cellText = new String[lines.length][];
            for (int line=0; line<lines.length; line++) {
                cellText[line] = lines[line].split(TAB+"");
            }
            return cellText;
        }
    }

}
