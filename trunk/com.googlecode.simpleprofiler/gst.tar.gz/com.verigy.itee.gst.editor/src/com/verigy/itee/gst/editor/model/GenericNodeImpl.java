package com.verigy.itee.gst.editor.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;

/**
 * The implementation of interface {@link IGenericNode}.
 *
 * @author bennwang
 *
 */
public class GenericNodeImpl implements IGenericNode {

	private Node xmlNode = null;

	private IGenericNode parent = null;

	private final ArrayList<IGenericNode> nodeList = new ArrayList<IGenericNode>();

	/**
	 * A thin wrapper of a xml node
	 *
	 * @param xmlNode {@link Node}
	 * @param parent {@link IGenericNode}
	 */
	public GenericNodeImpl(final Node xmlNode, final IGenericNode parent) {
		if(null != xmlNode) {
			this.xmlNode = xmlNode;
		}
		this.parent = parent;
	}


	@Override
	public void addChild(IGenericNode child) {
		nodeList.add(child);
	}


	private void createRoot(IGenericNode parentNode, Node children) {
//		if(children == null || children.getLength() == 0)
//			return;
//		for(int i=0; i<children.getLength(); i++) {
			Node item = children;//children.item(i);
			if(Node.ELEMENT_NODE == item.getNodeType() &&
					item.getChildNodes().getLength() == 1 &&
					Node.TEXT_NODE == item.getChildNodes().item(0).getNodeType()) {
				parentNode.addChild(new GenericNodeImpl(item, parentNode));
			}else if(Node.ELEMENT_NODE == item.getNodeType() &&
					item.getChildNodes().getLength() == 0) {
				parentNode.addChild(new GenericNodeImpl(item, parentNode));
			}else if(item.getChildNodes().getLength() > 0 ) {
				IGenericNode node = new GenericNodeImpl(item, parentNode);
				parentNode.addChild(node);
				for(int i=0; i<item.getChildNodes().getLength(); i++) {
					createRoot(node, children.getChildNodes().item(i));
				}
//				createRoot(node, item.getChildNodes());
			}
//    	}
	}

	@Override
	public List<IGenericNode> getChildren() {
		return nodeList;
	}


	@Override
	public boolean hasChild() {
		if(nodeList.isEmpty()) {
            return false;
        }
		return true;
	}


	@Override
	public void removeChild(IGenericNode child) {
		if (child instanceof GenericNodeImpl) {
			GenericNodeImpl genericNodeImpl = (GenericNodeImpl) child;
			xmlNode.removeChild(genericNodeImpl.xmlNode);
		}
		nodeList.remove(child);
	}

	@Override
	public String getName() {
		if(null != xmlNode &&
				Node.ELEMENT_NODE == xmlNode.getNodeType() &&
				1 == xmlNode.getChildNodes().getLength() &&
				Node.TEXT_NODE == xmlNode.getChildNodes().item(0).getNodeType()) {
			Node text = xmlNode.getChildNodes().item(0);
			if(text.getNodeValue().contains("=")) {
                return text.getNodeValue().split("=")[0];
            }
			return xmlNode.getNodeName();
		}
		if(hasAttribute()) {
			if( null == getAttributes().get("id")) {
                return xmlNode.getNodeName();
            }
			return getAttributes().get("id");
		}
		if(null == xmlNode.getNodeName()) {
            return "";
        }
		return xmlNode.getNodeName();
	}

	@Override
	public Map<String, String> getAttributes() {
		if(null == xmlNode || !xmlNode.hasAttributes()) {
            return null;
        }
		Map<String, String> attributes = new HashMap<String, String>();
		for(int i=0; i<xmlNode.getAttributes().getLength(); i++) {
			Attr attr = (Attr) xmlNode.getAttributes().item(i);
			attributes.put(attr.getName(), attr.getValue());
		}
		return attributes;
	}


	@Override
	public boolean hasAttribute() {
		if(null == xmlNode) {
            return false;
        }
		return xmlNode.hasAttributes();
	}

	@Override
	public String getValue() {
		if(null != xmlNode &&
				Node.ELEMENT_NODE == xmlNode.getNodeType() &&
				1 == xmlNode.getChildNodes().getLength() &&
				Node.TEXT_NODE == xmlNode.getChildNodes().item(0).getNodeType()) {
			Node text = xmlNode.getChildNodes().item(0);
			if(text.getNodeValue().contains("=")) {
                return text.getNodeValue().split("=")[1];
            }
			return text.getNodeValue();
		}
		if(hasAttribute()) {
			if(null != getAttributes().get("val")) {
                return getAttributes().get("val");
            } else if (null != getAttributes().get("label")) {
                return getAttributes().get("label");
            } else {
                return "";
            }
		}
		if(null == xmlNode.getNodeValue()) {
            return "";
        }
		return xmlNode.getNodeValue();
	}

	@Override
	public IGenericNode getChild(String name) {
		if(hasChild()) {
			for(int i=0; i<nodeList.size(); i++) {
				if(name.equals(nodeList.get(i).getName().trim())) {
                    return nodeList.get(i);
                }
			}
		}
		return null;
	}

	@Override
	public boolean setName(String newName) {
		//TODO
		if(null != xmlNode &&
				Node.ELEMENT_NODE == xmlNode.getNodeType() &&
				1 == xmlNode.getChildNodes().getLength() &&
				Node.TEXT_NODE == xmlNode.getChildNodes().item(0).getNodeType()) {
			//case: <eqn> d0 = t_d0_RX </eqn>
			Node text = xmlNode.getChildNodes().item(0);
			if(text.getNodeValue().contains("=")) {
				String nodeValue = text.getNodeValue();
				//TODO by benny
				text.setNodeValue(newName  + " = " + nodeValue.split("=")[1]);
			} else {
				//case: <site>1</site>
				//do nothing
			}
		}
		if(hasAttribute()) {
			if( null == getAttributes().get("name")) {
				//case: <method value="testmethod.dc.continuity">
				//do nothing
			} else {
				//case:  <grp name="all">
				for(int i=0; i<xmlNode.getAttributes().getLength(); i++) {
					Attr attr = (Attr) xmlNode.getAttributes().item(i);
					if("name".equals(attr.getName())){
						attr.setValue(newName);
					}
				}
			}

		}
//		if(null == xmlNode.getNodeName())
//			return "";
//		return xmlNode.getNodeName();
		//do nothing
		return true;
	}

	@Override
	public boolean setValue(String newValue) {
		//TODO
		if(null != xmlNode &&
				Node.ELEMENT_NODE == xmlNode.getNodeType() &&
				1 == xmlNode.getChildNodes().getLength() &&
				Node.TEXT_NODE == xmlNode.getChildNodes().item(0).getNodeType()) {
			//case: <eqn> d0 = t_d0_RX </eqn>
			Node text = xmlNode.getChildNodes().item(0);
			if(text.getNodeValue().contains("=")) {
				String nodeValue = text.getNodeValue();
				//TODO by benny
				text.setNodeValue(nodeValue.split("=")[0] + " = " + newValue);
			} else {
				//case: <site>1</site>
				text.setNodeValue(newValue);
			}
		}
		if(hasAttribute()) {
			if( null == getAttributes().get("value")) {
				//case: <group name="Vcc">
				//do nothing
			} else {
				//case:  <method value="testmethod.dc.continuity">
				for(int i=0; i<xmlNode.getAttributes().getLength(); i++) {
					Attr attr = (Attr) xmlNode.getAttributes().item(i);
					if("value".equals(attr.getName())){
						attr.setValue(newValue);
					}
				}
			}
		}
//		if(null == xmlNode.getNodeValue())
//			return "";
//		return xmlNode.getNodeValue();
		xmlNode.setNodeValue(newValue);
		return true;
	}

	@Override
	public IGenericNode getParent() {
		return parent;
	}

	@Override
	public GenericNodeType getNodeType() {
		if(null != xmlNode){
			if(xmlNode instanceof Element) {
				String tagName = ((Element)xmlNode).getTagName();
				if("spec_sheet".equals(tagName)) {
                    return GenericNodeType.SPEC;
                } else if("import".equals(tagName)) {
                    return GenericNodeType.IMPORT;
                } else if("var".equals(tagName)) {
                    return GenericNodeType.VAR;
                } else if("res".equals(tagName)) {
                    return GenericNodeType.RES;
                } else if("set".equals(tagName)) {
                    return GenericNodeType.SET;
                } else if("prop".equals(tagName)) {
                    return GenericNodeType.PROP;
                } else {
                    return GenericNodeType.UNKNOWN;
                }
			}
		}

		return GenericNodeType.UNKNOWN;

	}

	/**
	 * Should be replaced by getRoot
	 *
	 * @return {@link Document}
	 */
	public Document getDocument() {
		Document ownerDocument = null;
		if(null != xmlNode) {
            ownerDocument = xmlNode.getOwnerDocument();
        }
		return ownerDocument;
	}

    @Override
    public String getTypeChain() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public IGenericNode getRoot() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isRoot() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void addChild(IGenericNode child, IGenericNode successor) {
        // TODO Auto-generated method stub

    }

}
