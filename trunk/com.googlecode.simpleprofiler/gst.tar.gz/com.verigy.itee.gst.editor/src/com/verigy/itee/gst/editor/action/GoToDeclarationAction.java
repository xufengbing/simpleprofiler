/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;

import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.utils.FuncUtil;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author alanlin
 *
 */
public class GoToDeclarationAction extends AbstractGSTAction {

    /**
     * The constructor
     */
    public GoToDeclarationAction() {
        super();
    }

    @Override
    public void run(IAction action) {
        ITdoNode node = getFirstSelectedNode();

        if (node != null) {
            String content = node.getValue();
            String[] vars = FuncUtil.filterDigitalElements(FuncUtil.retrieveVarInExpression(content));

            Util.goToDeclarationOf(vars);
        }
    }
}
