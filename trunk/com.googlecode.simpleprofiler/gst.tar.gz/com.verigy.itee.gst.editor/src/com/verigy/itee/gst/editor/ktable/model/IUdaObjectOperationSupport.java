/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.model;

import java.util.List;

import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 * @author alanlin
 */
public interface IUdaObjectOperationSupport {
	/**
	 *
	 * @param index the row index which should be used to get the corresponding
	 * object. The index here may include the fix row header of kable model and it's
	 * visible row index and the implemention should map this row index into the
	 * pure index in real object array.
	 * @return Returns the object at specified {@code index}. Returns <code>null</code> if there
	 * is no corresponding object.
	 */
	public Object getObjectAt(int index);

	/**
	 * @param node
	 * @return
	 */
	public int getRowIndexFor(ITdoNode node);

	/**
	 * Refreshes the table model in terms of the inputed root node.
	 * @param rootNode the {@linkplain ITdoNode}. It's the root node of xml nodes.
	 * @param format the format
	 */
	public void refreshKTableDataModel(ITdoNode rootNode, List<String> format);

	/**
	 * Refreshes the ktable model with already set root node and format.
	 */
	public void refreshKTableDataModel();
}
