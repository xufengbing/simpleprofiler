/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.model;

import xoc.ate.cor.uda.ZAttribute;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.TdoNode;
import com.verigy.itee.gst.explorer.ate.UDAccessor;

/**
 * @author bennwang
 *
 */
public class TdoNodeFactory {

    static private TdoNodeFactory instance = null;

    private TdoNodeFactory() {
        //do nothing
    }

    static public TdoNodeFactory getInstance() {
        if(null == instance) {
            instance = new TdoNodeFactory();
        }
        return instance;
    }


    public ITdoNode createFloatingTdoNode(ITdoNode parent) {
        ITdoNode node = null;
        node = new FloatingTdoNode(parent);
        return node;
    }



    /**
     * Create a new TDO node in model
     * @param parent parent node
     * @param type {@link GenericNodeType}
     * @param name node name
     * @return new node
     */
    public ITdoNode createTdoChildNode(ITdoNode parent, GenericNodeType type, String name) {
        int child = UDAccessor.getInstance().createTestDataChildNode((int)parent.getAddress(), createAttributeList(type), name);
        if( child == -1) {
            return null;
        }
        return new TdoNode(parent, child);
    }

    //TODO Benny to refine
    public ITdoNode createTdoSiblingNode(ITdoNode previous, GenericNodeType type, String name) {
        int sibling = UDAccessor.getInstance().createTdoSiblingNode((int)previous.getAddress(), createAttributeList(type), name);
        if( sibling == -1) {
            return null;
        }
        return new TdoNode(previous.getParent(), sibling);
    }

    /**
     *
     * @param type
     * @return
     */
    public ZAttribute[] createAttributeList(GenericNodeType type) {
        ZAttribute[] attributes = null;
        if(type == GenericNodeType.IMPORT) {
            attributes = new ZAttribute[3];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1] = new ZAttribute();
            attributes[1].name = "subType";
            attributes[1].value = "import";
            attributes[2] = new ZAttribute();
            attributes[2].name = "val";
            attributes[2].value = "newImport";
        }else if (type == GenericNodeType.VAR) {
            attributes = new ZAttribute[3];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1] = new ZAttribute();
            attributes[1].name = "subType";
            attributes[1].value = "var";
            attributes[2] = new ZAttribute();
            attributes[2].name = "val";
            attributes[2].value = "newVar";
        }else if (type == GenericNodeType.RES) {
            attributes = new ZAttribute[2];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1] = new ZAttribute();
            attributes[1].name = "subType";
            attributes[1].value = "res";
        }else if (type == GenericNodeType.SET) {
            attributes = new ZAttribute[3];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1] = new ZAttribute();
            attributes[1].name = "subType";
            attributes[1].value = "set";
            attributes[2] = new ZAttribute();
            attributes[2].name = "label";
            attributes[2].value = "newSet";
        }else if (type == GenericNodeType.PROP) {
            attributes = new ZAttribute[3];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1] = new ZAttribute();
            attributes[1].name = "subType";
            attributes[1].value = "prop";
            attributes[2] = new ZAttribute();
            attributes[2].name = "val";
            attributes[2].value = "newProp";
        }else if (type == GenericNodeType.INSTRUMENT) {
            attributes = new ZAttribute[2];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1].name  = "subType";
            attributes[1].value = "instrument";
        }else if (type == GenericNodeType.GROUP) {
            attributes = new ZAttribute[2];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1].name  = "subType";
            attributes[1].value = "group";
        }else if (type == GenericNodeType.NET) {
            attributes = new ZAttribute[2];
            attributes[0] = new ZAttribute();
            attributes[0].name  = "nodeType";
            attributes[0].value = "TEST_DATA_OBJECT";
            attributes[1].name  = "subType";
            attributes[1].value = "net";
        }

        return attributes;
    }
}
