/*******************************************************************************

 * Copyright (c) 2006, 2007 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.selection;

import org.eclipse.jface.viewers.ISelectionProvider;

import de.kupzog.ktable.KTable;

/**
 * @author alanlin
 */
public interface IGSTSelectionProvider extends ISelectionProvider {
    /**
     * Sends a selection event with <code>null</code> argument for all
     * registers to remove theirs content.
     */
    public void fireClearSelectionEvent();

    /**
     * Due to KTable does not fire selection event if user clicks on an already
     * selected cell, it causes all menus based on current selection to be incorrect.
     * To fix this issue, an reselecting of current selected cells will force the
     * table to fire an cell selection event.
     * @param table the {@linkplain KTable}.
     * TODO Actually the right click should trigger an event even if the cell has
     * been selected. It should be add be KTable.
     */
    public void reselectCell(KTable table);

    /**
     * Selects the first cell of the given row in the given table.
     * @param table the table
     * @param row the row index
     */
    public void selectCell(KTable table, int row);

    /**
     * Selects the specified obj in the given table. If the object can't be found
     * in the table, does nothing.
     * @param table the table which may contain the specified obj.
     * @param obj the object to be focused.
     */
    public void selectObject(KTable table, Object obj);
}
