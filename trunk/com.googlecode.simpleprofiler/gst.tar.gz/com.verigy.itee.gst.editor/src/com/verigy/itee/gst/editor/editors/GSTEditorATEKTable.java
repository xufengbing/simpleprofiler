/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.editors;

import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.TransformerException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.contexts.IContextService;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.ide.IGotoMarker;
import org.eclipse.ui.part.EditorPart;
import org.eclipse.ui.part.FileEditorInput;

import com.verigy.itee.gst.editor.Activator;
import com.verigy.itee.gst.editor.ktable.gsttable.GSTTableTree;
import com.verigy.itee.gst.editor.ktable.gsttable.KTableActionHandler;
import com.verigy.itee.gst.editor.ktable.model.UDAKTabletreeModel;
import com.verigy.itee.gst.editor.ktable.renderer.RendererPool;
import com.verigy.itee.gst.editor.ktable.selection.KTableSelectionProvider;
import com.verigy.itee.gst.editor.model.XmlModel;
import com.verigy.itee.gst.editor.support.IDirtyFlagSupport;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.TdoNode;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.utils.GSTEditorInput;
import com.verigy.itee.gst.explorer.utils.Util;

import de.kupzog.ktable.KTable.KTX;
import de.kupzog.ktable.SWTX;

/**
 * @author alanlin
 */
public class GSTEditorATEKTable extends EditorPart implements IDirtyFlagSupport,
        IGotoMarker {
    private final static String contextMenuId = "GST#PopupMenu";

    private ISelectionProvider selectionProvider;

    private boolean isDirty;

    private XmlModel xmlModel;

    private ITdoNode rootNode;

    private GSTTableTree table;

    private UDAKTabletreeModel model;

    private IPreferenceStore preferenceStore;

    private KTableActionHandler actionHandler;

    // TODO Benny refactor
    private final static Image configsheetIcon = JFaceResources.getResources()
            .createImage(
                    Activator.getDefault().getImageDescriptor("icons/configsheet.png"));

    private final static Image specsheetIcon = JFaceResources.getResources().createImage(
            Activator.getDefault().getImageDescriptor("icons/specsheet.gif"));

    /*
     * (non-Javadoc)
     *
     * @seeorg.eclipse.ui.part.EditorPart#doSave(org.eclipse.core.runtime.
     * IProgressMonitor)
     */
    @Override
    public void doSave(IProgressMonitor monitor) {
        if (xmlModel != null) {
            try {
                xmlModel.save();
                setDirty(false);
            } catch (TransformerException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.ui.part.EditorPart#doSaveAs()
     */
    @Override
    public void doSaveAs() {
        performSaveAs(getProgressMonitor());

        setDirty(false);
    }

    @Override
    public Image getTitleImage() {
        final IEditorInput input = getEditorInput();
        assert (null != input);
        if (input instanceof GSTEditorInput) {
            String type = ((GSTEditorInput) input).getType();
            if ("CFG".equals(type)) {
                return configsheetIcon;
            } else if ("SPEC".equals(type)) {
                return specsheetIcon;
            }
        }

        return super.getTitleImage();
    }

    protected void performSaveAs(IProgressMonitor progressMonitor) {
        Shell shell = getSite().getShell();
        final IEditorInput input = getEditorInput();
        boolean success = false;

        IEditorInput newInput = null;

        if (input instanceof IFileEditorInput) {
            SaveAsDialog dialog = new SaveAsDialog(shell);

            IFile original = (input instanceof IFileEditorInput) ? ((IFileEditorInput) input)
                    .getFile() : null;
            if (original != null) {
                dialog.setOriginalFile(original);
            }

            dialog.create();

            if (dialog.open() == Window.CANCEL) {
                if (progressMonitor != null) {
                    progressMonitor.setCanceled(true);
                }
                return;
            }

            IPath filePath = dialog.getResult();
            if (filePath == null) {
                if (progressMonitor != null) {
                    progressMonitor.setCanceled(true);
                }
                return;
            }

            IWorkspace workspace = ResourcesPlugin.getWorkspace();
            IFile file = workspace.getRoot().getFile(filePath);

            newInput = new FileEditorInput(file);
            String newFilePath = file.getLocation().toOSString();

            try {
                xmlModel.save(newFilePath);
                setInput(newInput);
                setPartName(newInput.getName());
                success = true;
            } catch (TransformerException x) {
                // do nothing
            }

            if (success) {
                try {
                    IProject project = file.getProject();
                    if (project != null) {
                        project.refreshLocal(IResource.DEPTH_INFINITE,
                                getProgressMonitor());
                    }
                } catch (CoreException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        if (progressMonitor != null) {
            progressMonitor.setCanceled(!success);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.ui.part.EditorPart#init(org.eclipse.ui.IEditorSite,
     * org.eclipse.ui.IEditorInput)
     */
    @Override
    public void init(IEditorSite site, IEditorInput input) throws PartInitException {
        setSite(site);
        setInput(input);

        setPartName(input.getName());

        if (selectionProvider != null) {
            getSite().setSelectionProvider(selectionProvider);
        }

        ((IContextService) getEditorSite().getService(IContextService.class))
                .activateContext("com.verigy.itee.gst.editor.context");

        setPreferenceStore(Activator.getDefault().getPreferenceStore());

        isDirty = false;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.ui.part.EditorPart#isDirty()
     */
    @Override
    public boolean isDirty() {
        return isDirty;
    }

    @Override
    public void setDirty(boolean isDirty) {
        //
        // Set internal "dirty" flag
        //
        this.isDirty = isDirty;
        //
        // Fire the "property change" event to change file's status within Eclipse IDE
        //
        firePropertyChange(IEditorPart.PROP_DIRTY);
    }

    @Override
    public void dispose() {
        preferenceStore.removePropertyChangeListener(propertyChangeListener);

        // RendererPool.getInstance().disposeColors();

        super.dispose();
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.ui.part.EditorPart#isSaveAsAllowed()
     */
    @Override
    public boolean isSaveAsAllowed() {
        return true;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets
     * .Composite)
     */
    @Override
    public void createPartControl(Composite parent) {
        createKTabletree(parent);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
     */
    @Override
    public void setFocus() {
        if (table != null) {
            table.setFocus();
        }
    }

    protected IProgressMonitor getProgressMonitor() {

        IProgressMonitor pm = null;

        IStatusLineManager manager = getStatusLineManager();
        if (manager != null) {
            pm = manager.getProgressMonitor();
        }

        return pm != null ? pm : new NullProgressMonitor();
    }

    protected IStatusLineManager getStatusLineManager() {
        return getEditorSite().getActionBars().getStatusLineManager();
    }

    private void createKTabletree(Composite parent) {
        parent.setLayout(new FillLayout());
        /*
         * Style bit (SWTX.MULTI) enables the multiply selection no matter it's cell
         * selection or row selection which means enabling selecting multiply cells or
         * rows. Style bit (SWTX.RECT_SELECTION) enables rectangle selection with the help
         * of shift key or ctrl key. The extended style bits (KTX.HEADER_ROW_SELECTION,
         * KTX.HEADER_COLUMN_SELECTION) enables selecting the whole row or whole column on
         * row header or column header. The combination of (SWTX.MULTI,
         * SWTX.RECT_SELECTION and KTX.EXPAND_ROW_SELECTION) enables the
         * KTable.getRowSelection() method returns the all selection rows otherwise only
         * the first row and the last row are returned. Same rule applies to the
         * combination of (SWTX.MULTI, SWTX.RECT_SELECTION and KTX.EXPAND_CELL_SELECTION).
         */
        int style = SWTX.MULTI | SWTX.AUTO_SCROLL | SWTX.FILL_WITH_LASTCOL
                | SWTX.EDIT_ON_KEY | SWTX.RECT_SELECTION;
        int extStyle = KTX.HEADER_ROW_SELECTION | KTX.EXPAND_ROW_SELECTION
                | KTX.EXPAND_CELL_SELECTION | KTX.HEADER_COLUMN_SELECTION
                | KTX.ENABLE_DRAG_SELECTION;
        table = new GSTTableTree(parent, style, extStyle);

        IEditorInput input = getEditorInput();
        if (null == input) {
            return;
        }

        List<String> uiFormat = new ArrayList<String>();
        rootNode = null;

        if (input instanceof IFileEditorInput) {
            IFileEditorInput fileEditorInput = (IFileEditorInput) input;
            IFile file = fileEditorInput.getFile();

            String name = file.getName();
            String extention = file.getFileExtension();

            name = name.substring(0, name.length() - extention.length() - 1);

            IZTestDataNode superNode = null;
            if (input instanceof GSTEditorInput) { // open from project explorer
                superNode = ((GSTEditorInput) input).getNode();
            } else { // jump from problem view
                superNode = Util.convertToTDENode(file);
            }

            rootNode = new TdoNode(null, (int) superNode.getAddress(),true);
            if (superNode instanceof IUTDEntity) {
                uiFormat = getUIFormatFrom((IUTDEntity) superNode);
            }
        }

        model = new UDAKTabletreeModel(this, table, rootNode, uiFormat);
        table.setModel(model);

        // register mouse move listener for hyper link style cell renderer
//        table.addHoveredCellChangeListener(new KHoverCellChangeListener() {
//            @Override
//            public void onHoveredCellChange(int x1, int y1, int x2, int y2, KTable aTable) {
//                if (x1 >= 0 && y1 >= 0) {
//                    aTable.redraw(x1, y1, 1, 1);
//                }
//                if (x2 >= 0 && y2 >= 0) {
//                    aTable.redraw(x2, y2, 1, 1);
//                }
//            }
//        });

        // register selection provider
        selectionProvider = new KTableSelectionProvider(table, this);
        getSite().setSelectionProvider(selectionProvider);

        // the actioHandler should be initialized prior to createContextMenu() method
        // since it will be used in filling default copy/paste action.
        actionHandler = new KTableActionHandler(table);

        // create context menu
        createContextMenu(table);
    }

    private List<String> getUIFormatFrom(IUTDEntity tdeEntity) {
        List<String> format = new ArrayList<String>();
        String metaData = tdeEntity.getMetaData();

        if (!metaData.isEmpty()) {
            String[] columns = metaData.split("[,| |;]");
            for (String c : columns) {
                if (!c.trim().isEmpty()) {
                    format.add(c.trim());
                }
            }
        }

        return format;
    }

    private void createContextMenu(Control control) {
        if (contextMenuId == null || selectionProvider == null) {
            return;
        }

        MenuManager manager = new MenuManager(contextMenuId, contextMenuId);
        manager.setRemoveAllWhenShown(true);
        manager.addMenuListener(new IMenuListener() {
            @Override
            public void menuAboutToShow(IMenuManager m) {
                fillContextMenu(m);
            }
        });
        Menu contextMenu = manager.createContextMenu(control);
        getEditorSite().registerContextMenu(contextMenuId, manager, selectionProvider,
                false);
        control.setMenu(contextMenu);
    }

    private void fillContextMenu(IMenuManager m) {
        // reserve menu positions here
        m.add(new Separator(contextMenuId + ".reference"));
        m.add(new Separator(contextMenuId + ".undoredo"));
        m.add(new Separator(contextMenuId + ".open"));
        m.add(new GroupMarker(contextMenuId + ".goto"));
        m.add(new Separator(contextMenuId + ".adddelete"));
        m.add(new Separator(contextMenuId + ".copypaste"));
        m.add(new Separator(contextMenuId + ".format"));

        // install default copy/paste action
//        m.add(new Separator());
//        m.add(actionHandler.m_SelectAllAction);
//        m.add(actionHandler.m_CopyAction);
//        m.add(actionHandler.m_CopyAllAction);
//        m.add(actionHandler.m_CutAction);
//        m.add(actionHandler.m_PasteAction);

        m.add(new Separator(contextMenuId + "." + IWorkbenchActionConstants.MB_ADDITIONS));
    }

    IPropertyChangeListener propertyChangeListener = new IPropertyChangeListener() {
        @Override
        public void propertyChange(org.eclipse.jface.util.PropertyChangeEvent event) {
            RendererPool.getInstance().reset();
            table.redraw();
        }
    };

    private void setPreferenceStore(IPreferenceStore store) {
        if (preferenceStore != null) {
            preferenceStore.removePropertyChangeListener(propertyChangeListener);
        }

        preferenceStore = store;

        if (preferenceStore != null) {
            preferenceStore.addPropertyChangeListener(propertyChangeListener);
        }
    }

    /**
     * @return Returns the root node of this editor
     */
    public ITdoNode getRootNode() {
        return rootNode;
    }

    @Override
    public void gotoMarker(IMarker marker) {
        if (rootNode == null) {
            return;
        }
        try {
            String location = (String) marker.getAttribute(IMarker.LOCATION);
            String[] splited = location.split("[/]");
            boolean success = true;
            ITdoNode found = rootNode;
            for (int i = 0; i < splited.length; i++) {
                try {
                    Integer idx = Integer.valueOf(splited[i]);
                    found = (ITdoNode) found.getChildren().get(idx.intValue());
                } catch (NumberFormatException e1) {
                    success = false;
                    break;
                } catch (IndexOutOfBoundsException e2) {
                    success = false;
                    break;
                }
            }

            if (success && found != null) {
                int rowIdx = model.getModelRowIndexOf(found);
                if (rowIdx != -1) {
                    int tableRowIdx = model.mapRowIndexToModel(rowIdx)
                            + model.getFixedRowCount();
                    table.setSelection(2, tableRowIdx, true, true);
                }
            }
        } catch (CoreException e) {
            // LOG.logError("TODO", e);
        }

    }
}
