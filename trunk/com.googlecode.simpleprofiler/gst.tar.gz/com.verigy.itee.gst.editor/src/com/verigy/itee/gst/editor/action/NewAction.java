/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.jface.action.IAction;

import com.verigy.itee.gst.editor.model.TdoNodeFactory;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;


/**
 * @author alanlin
 */
public abstract class NewAction extends AbstractUpdatableAction {
	protected final static String ADD = "add";
	protected final static String INSERT = "insert";

	protected String origText;
	protected String actionType;


	/**
	 * The subclass must specify the original text which can be detacted later on.
	 * @param origText the original text with a replacable suffix "%s".
	 */
	public NewAction(String origText) {
		this.origText = origText;
		this.actionType = null;
	}

	@Override

	protected boolean doRun(IAction action) {
		ITdoNode selectedNode = getFirstSelectedNode();
      String[] idSegs = action.getId().split("[.]");
      String lastSeg = idSegs[idSegs.length - 1];

      // figure out action type through definition id
      actionType = ADD;
      if (lastSeg.startsWith(INSERT)) {
          actionType = INSERT;
      }

		if (selectedNode != null) {
			if(ADD.equals(actionType)) {
			    ITdoNode node = TdoNodeFactory.getInstance().createTdoSiblingNode(selectedNode, getNodeType(), "");
			    //TODO Benny more check on the index
			    int index = selectedNode.getParent().getChildren().indexOf(selectedNode);
			    ((ITdoNode)selectedNode.getParent()).addChild(node, index + 1);
				return true;
			}else if (INSERT.equals(actionType)) {
				ITdoNode node = TdoNodeFactory.getInstance().createTdoChildNode(selectedNode, getNodeType(), "");
				selectedNode.addChild(node,0);
			    return true;
			}
		}

		return false;
	}

	protected void updateActionType(IAction action, String actionTypeStr) {
		if (ADD.equals(actionTypeStr) || INSERT.equals(actionTypeStr)) {
			String actionText = origText;

			actionType = actionTypeStr;
		} else {
			actionType = actionTypeStr;
		}
	}

	abstract protected GenericNodeType getNodeType();
}
