/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.contentassist;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author alanlin
 *
 */
public class FakeModelInfo {
    private final static String EMPTY_STR = "";
    public static class StructureInfo {
        public static Set<String> sets = new HashSet<String>();
        public StructureInfo(String type, String name) {
            this.type = type;
            this.name = name;
            this.children = new ArrayList<FakeModelInfo.StructureInfo>();
        }

        public void addChild(StructureInfo child) {
            this.children.add(child);
        }

        public StructureInfo[] getChildren() {
            return children.toArray(new StructureInfo[children.size()]);
        }

        public StructureInfo getChildWithTypeName(String type) {
            if (type != null && !type.isEmpty()) {
                if (StructureInfo.sets.contains(type)) {
                    for (StructureInfo c: getChildren()) {
                        if (c.name.equals(type)) {
                            return c;
                        }
                    }
                }
                for (StructureInfo c : getChildren()) {
                    if (c.type.equals(type)) {
                        return c;
                    }
                }

            }
            return null;
        }

        public String[] getChildrenNames() {
            String[] names = new String[children.size()];
            for (int i = 0; i < names.length; i++) {
                names[i] = children.get(i).name;
            }

            return names;
        }

        private final String type;
        private final String name;
        private final List<StructureInfo> children;
    }

    private final StructureInfo root;

    /**
     *
     */
    public FakeModelInfo() {
        super();
        root = generateFakeModelInfo();
    }

    public StructureInfo getRoot() {
        return root;
    }

    private StructureInfo generateFakeModelInfo() {
        StructureInfo rootNode = new StructureInfo(EMPTY_STR, "root");

        // spec
        StructureInfo spec = new StructureInfo("SPEC", "spec");
        rootNode.addChild(spec);

        StructureInfo firstLevel;
        firstLevel = new StructureInfo("RES", EMPTY_STR);
        spec.addChild(firstLevel);

        // timing
        StructureInfo secondLevel = new StructureInfo("SET", "timing");
        firstLevel.addChild(secondLevel);
        StructureInfo.sets.add(secondLevel.name);


        for (int i = 1; i <= 8; i++) {
            secondLevel.addChild(new StructureInfo("PROP", "d" + i));
            secondLevel.addChild(new StructureInfo("PROP", "r" + i));
        }

        secondLevel.addChild(new StructureInfo("PROP", "tx"));
        secondLevel.addChild(new StructureInfo("PROP", "period"));

        // clock
        secondLevel = new StructureInfo("SET", "clock");
        firstLevel.addChild(secondLevel);
        StructureInfo.sets.add(secondLevel.name);

        secondLevel.addChild(new StructureInfo("PROP", "period_res"));
        secondLevel.addChild(new StructureInfo("PROP", "clksource"));
        secondLevel.addChild(new StructureInfo("PROP", "domain"));

        // waveform
        secondLevel = new StructureInfo("SET", "wavetable");
        firstLevel.addChild(secondLevel);
        StructureInfo.sets.add(secondLevel.name);

        secondLevel.addChild(new StructureInfo("PROP", "name"));
        secondLevel.addChild(new StructureInfo("PROP", "states"));
        secondLevel.addChild(new StructureInfo("PROP", "xmode"));
        secondLevel.addChild(new StructureInfo("PROP", "selector"));

        secondLevel = new StructureInfo("SET", "wavetable");
        StructureInfo.sets.add(secondLevel.name);
        firstLevel.addChild(secondLevel);

        secondLevel.addChild(new StructureInfo("PROP", "def"));

        // level
        secondLevel = new StructureInfo("SET", "level");
        firstLevel.addChild(secondLevel);
        StructureInfo.sets.add(secondLevel.name);

        secondLevel.addChild(new StructureInfo("PROP", "vil"));
        secondLevel.addChild(new StructureInfo("PROP", "vih"));
        secondLevel.addChild(new StructureInfo("PROP", "vol"));
        secondLevel.addChild(new StructureInfo("PROP", "voh"));
        secondLevel.addChild(new StructureInfo("PROP", "vth"));
        secondLevel.addChild(new StructureInfo("PROP", "vcl"));
        secondLevel.addChild(new StructureInfo("PROP", "vch"));
        secondLevel.addChild(new StructureInfo("PROP", "term"));
        secondLevel.addChild(new StructureInfo("PROP", "iol"));
        secondLevel.addChild(new StructureInfo("PROP", "ioh"));
        secondLevel.addChild(new StructureInfo("PROP", "vt"));

        // levels
        secondLevel = new StructureInfo("SET", "levels");
        firstLevel.addChild(secondLevel);
        StructureInfo.sets.add(secondLevel.name);

        secondLevel.addChild(new StructureInfo("PROP", "vil"));
        secondLevel.addChild(new StructureInfo("PROP", "vih"));
        secondLevel.addChild(new StructureInfo("PROP", "vol"));
        secondLevel.addChild(new StructureInfo("PROP", "voh"));
        secondLevel.addChild(new StructureInfo("PROP", "vth"));
        secondLevel.addChild(new StructureInfo("PROP", "vcl"));
        secondLevel.addChild(new StructureInfo("PROP", "vch"));
        secondLevel.addChild(new StructureInfo("PROP", "term"));
        secondLevel.addChild(new StructureInfo("PROP", "iol"));
        secondLevel.addChild(new StructureInfo("PROP", "ioh"));
        secondLevel.addChild(new StructureInfo("PROP", "vt"));



        //thirdLevel new
        //tmp = new StructureInfo("timing");
        //spec.addChild(tmp);



        return rootNode;
    }

}
