/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.gsttable;

/**
 * @author alanlin
 *
 */
public interface KMouseClickedListener {
	public void onMouseClicked(int col, int row, int stateMask);
}
