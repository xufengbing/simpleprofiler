/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import java.util.Map;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.ui.progress.UIJob;

import com.verigy.itee.gst.editor.ktable.model.IUdaObjectOperationSupport;
import com.verigy.itee.gst.editor.ktable.selection.IGSTSelectionProvider;
import com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement;
import com.verigy.itee.gst.explorer.ate.ITdoNode;

import de.kupzog.ktable.KTable;
import de.kupzog.ktable.KTableModel;

/**
 * @author bennwang
 *
 */

//TODO Benny Refactor the methods
public class AbstractGSTHanlder extends AbstractHandler {

    private Map parameters;

    @Override
    public Object execute(ExecutionEvent event) throws ExecutionException {
        parameters = event.getParameters();
        ISelection selection = HandlerUtil.getActiveWorkbenchWindow(event).getActivePage().getSelection();
        if (selection instanceof IStructuredSelection) {
            StructuredSelection structuredSelection = (StructuredSelection) selection;
            IGenericNodeSelectionElement nodeSelection = (IGenericNodeSelectionElement) structuredSelection
                    .getFirstElement();

            final IEditorPart editor = nodeSelection == null ? null : nodeSelection.getEditor();
            ITdoNode tdoNode = nodeSelection == null ? null : nodeSelection.getSelectedNode();
            if(null == nodeSelection) {
                return null;
            }

            final ITdoNode focus = operate(tdoNode);

            operateInUI(nodeSelection);

            final KTable table = nodeSelection.getTable();
            if(null != table && !table.isDisposed()) {
                refreshKTableModel(table);
                UIJob job = new UIJob("Refreshing Table") {
                    @Override
                    public IStatus runInUIThread(IProgressMonitor monitor) {
                        table.redraw();
                        focusOn(editor, table, focus);
                        return Status.OK_STATUS;
                    }
                };
                job.schedule(10);
            }
        }

        return null;
    }

    /**
     * The operation on the selected node
     * @param node {@link ITdoNode}
     * @return {@link ITdoNode} The node to be focused
     */
    protected ITdoNode operate(ITdoNode node) {
        //do nothing
        return node;
    }

    /**
     *
     * @param node {@link IGenericNodeSelectionElement}
     */
    protected void operateInUI(IGenericNodeSelectionElement node) {
        //do nothing
    }

    /**
     * @param node {@link IGenericNodeSelectionElement}
     */
    protected void refreshKTableModel(KTable table) {

        if (table != null && !table.isDisposed()) {
            KTableModel model = table.getModel();
            if (model instanceof IUdaObjectOperationSupport) {
                ((IUdaObjectOperationSupport) model).refreshKTableDataModel();
            }
        }


    }


    /**
     * Focuses on the selected object. If the specified node can't be found at
     * current active editor, the focus will not change.
     * @param editor current editor
     * @param table The table
     * @param node The node to be focused
     */
    protected void focusOn(IEditorPart editor, KTable table, ITdoNode node) {
        if (editor != null) {
            ISelectionProvider provider = editor.getSite().getSelectionProvider();
            if (provider instanceof IGSTSelectionProvider) {
                IGSTSelectionProvider gstSelectionProvider = (IGSTSelectionProvider) provider;
                //TODO Below is workaound. Alan check the weird focus issue
                table.clearSelection();
                if (node == null) {
                    provider.setSelection(StructuredSelection.EMPTY);
                } else {
                    gstSelectionProvider.selectObject(table, node);
                }
            }
        }

    }



    protected Map getParameters() {
        return this.parameters;
    }

}
