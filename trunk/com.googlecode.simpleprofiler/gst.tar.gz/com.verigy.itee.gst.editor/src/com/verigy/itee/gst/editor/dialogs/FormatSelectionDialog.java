/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.dialogs;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.dialogs.SelectionDialog;

/**
 * @author alanlin
 *
 */
public class FormatSelectionDialog extends SelectionDialog {
	private TableViewer allViewer;
	private TableViewer currViewer;
	private final Set<String> allFormats;
	private final Set<String> currentFormats;

	private final HashSet<String> selectedElements = new LinkedHashSet<String>();

	/**
	 * Dialog used to format a table
	 * @param parentShell {@link Shell}
	 * @param currentFormats The current format of the table
	 * @param allFormats The available format
	 */
	public FormatSelectionDialog(Shell parentShell, final Set<String> currentFormats, final Set<String> allFormats) {
		super(parentShell);
		this.allFormats = allFormats;
		this.currentFormats = currentFormats;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		initializeDialogUnits(parent);

		Composite composite = (Composite) super.createDialogArea(parent);
		composite.setLayout(new GridLayout());
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));

		Composite leftCenterRightComposite = new Composite(composite, SWT.NONE);
		GridData gridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		gridData.heightHint = convertHeightInCharsToPixels(20);
		leftCenterRightComposite.setLayoutData(gridData);
		GridLayout gridLayout = new GridLayout(3, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		leftCenterRightComposite.setLayout(gridLayout);

		Composite leftComposite = new Composite(leftCenterRightComposite,
				SWT.NONE);
		gridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		gridData.widthHint = convertWidthInCharsToPixels(40);
		leftComposite.setLayoutData(gridData);
		gridLayout = new GridLayout(1, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		leftComposite.setLayout(gridLayout);

		Composite centerComposite = new Composite(leftCenterRightComposite,
				SWT.NONE);
		gridLayout = new GridLayout(1, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		centerComposite.setLayout(gridLayout);
		centerComposite.setLayoutData(new GridData(SWT.CENTER, SWT.TOP, false,
				false));

		Composite rightComposite = new Composite(leftCenterRightComposite,
				SWT.NONE);
		gridData = new GridData(SWT.FILL, SWT.FILL, true, true);
		gridData.widthHint = convertWidthInCharsToPixels(40);
		rightComposite.setLayoutData(gridData);
		gridLayout = new GridLayout(1, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		rightComposite.setLayout(gridLayout);

		createAllAvailableTable(leftComposite);
		createSelectedTable(rightComposite);
		createButtons(centerComposite);
		Dialog.applyDialogFont(composite);
		composite.pack();
		return composite;
	}

	@Override
	protected void okPressed() {
		setSelectionResult(currentFormats.toArray());
		super.okPressed();
	}

	private void createSelectedTable(Composite parent) {
		Label label = new Label(parent, SWT.NONE);
		label.setLayoutData(new GridData(SWT.LEAD, SWT.CENTER, false, false));
		label.setText("Current Formats");

		currViewer = new TableViewer(parent, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		currViewer.getTable().setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		currViewer.setLabelProvider(new LabelProvider());
		currViewer.setContentProvider(new ArrayContentProvider());

		currViewer.setInput(currentFormats);
	}

	private void createAllAvailableTable(Composite parent) {
		Label label = new Label(parent, SWT.NONE);
		label.setLayoutData(new GridData(SWT.LEAD, SWT.CENTER, false, false));
		label.setText("All Available Formats");

		allViewer = new TableViewer(parent, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.MULTI);
		allViewer.getTable().setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		allViewer.setLabelProvider(new LabelProvider());
		allViewer.setContentProvider(new ArrayContentProvider());

		allViewer.setInput(allFormats);
	}

	//TODO Benny refactor to remove the duplicate code
	private void createButtons(Composite parent) {
		Label spacer = new Label(parent, SWT.NONE);
		spacer.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));

		final Button addButton = new Button(parent, SWT.PUSH);
		addButton.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));
		addButton.setText("Add -->");
		addButton.setEnabled(!allViewer.getSelection().isEmpty());

		final Button addAllButton = new Button(parent, SWT.PUSH);
		addAllButton
				.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));
		addAllButton
				.setText("Add All -->");
		addAllButton.setEnabled(allViewer.getTable().getItems().length > 0);

		final Button removeButton = new Button(parent, SWT.PUSH);
		removeButton
				.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));
		removeButton
				.setText("<-- Remove");
		removeButton.setEnabled(!currViewer.getSelection().isEmpty());

		final Button removeAllButton = new Button(parent, SWT.PUSH);
		removeAllButton.setLayoutData(new GridData(SWT.CENTER, SWT.TOP, false,
				false));
		removeAllButton
				.setText("<-- Remove All");
		removeAllButton.setEnabled(!currentFormats.isEmpty());

		allViewer.addSelectionChangedListener(new ISelectionChangedListener() {
			@Override
            public void selectionChanged(SelectionChangedEvent event) {
	             addButton.setEnabled(!allViewer.getSelection().isEmpty());
	                removeButton.setEnabled(!currViewer.getSelection().isEmpty());
	                addAllButton.setEnabled(!allFormats.isEmpty());
	                removeAllButton.setEnabled(!currentFormats.isEmpty());

			}
		});

		addButton.addSelectionListener(new SelectionAdapter() {
			@Override
            public void widgetSelected(SelectionEvent e) {
				IStructuredSelection selection = (IStructuredSelection)allViewer.getSelection();
				if(null != selection && !selection.isEmpty()) {
				    currentFormats.addAll(selection.toList());
				    allFormats.removeAll(selection.toList());
	                update();
				}
                addButton.setEnabled(!allViewer.getSelection().isEmpty());
                removeButton.setEnabled(!currViewer.getSelection().isEmpty());
                addAllButton.setEnabled(!allFormats.isEmpty());
                removeAllButton.setEnabled(!currentFormats.isEmpty());

			}
		});

		allViewer.addDoubleClickListener(new IDoubleClickListener() {
			@Override
            public void doubleClick(DoubleClickEvent event) {
	             IStructuredSelection selection = (IStructuredSelection)allViewer.getSelection();
	                if(null != selection && !selection.isEmpty()) {
	                    currentFormats.addAll(selection.toList());
	                    allFormats.removeAll(selection.toList());
	                }
	                addButton.setEnabled(!allViewer.getSelection().isEmpty());
	                removeButton.setEnabled(!currViewer.getSelection().isEmpty());
	                addAllButton.setEnabled(!allFormats.isEmpty());
	                removeAllButton.setEnabled(!currentFormats.isEmpty());
	                update();

			}
		});

		currViewer.addSelectionChangedListener(new ISelectionChangedListener() {
			@Override
            public void selectionChanged(SelectionChangedEvent event) {
	             addButton.setEnabled(!allViewer.getSelection().isEmpty());
                removeButton.setEnabled(!currViewer.getSelection().isEmpty());
                addAllButton.setEnabled(!allFormats.isEmpty());
                removeAllButton.setEnabled(!currentFormats.isEmpty());

			}
		});

		removeButton.addSelectionListener(new SelectionAdapter() {
			@Override
            public void widgetSelected(SelectionEvent e) {
                IStructuredSelection selection = (IStructuredSelection)currViewer.getSelection();
                if(null != selection && !selection.isEmpty()) {
                    allFormats.addAll(selection.toList());
                    currentFormats.removeAll(selection.toList());
                }
                addButton.setEnabled(!allViewer.getSelection().isEmpty());
                removeButton.setEnabled(!currViewer.getSelection().isEmpty());
                addAllButton.setEnabled(!allFormats.isEmpty());
                removeAllButton.setEnabled(!currentFormats.isEmpty());

                update();
			}
		});

		currViewer.addDoubleClickListener(new IDoubleClickListener() {
			@Override
            public void doubleClick(DoubleClickEvent event) {
                IStructuredSelection selection = (IStructuredSelection)currViewer.getSelection();
                if(null != selection && !selection.isEmpty()) {
                    allFormats.addAll(selection.toList());
                    currentFormats.removeAll(selection.toList());
                }
                addButton.setEnabled(!allViewer.getSelection().isEmpty());
                removeButton.setEnabled(!currViewer.getSelection().isEmpty());
                addAllButton.setEnabled(!allFormats.isEmpty());
                removeAllButton.setEnabled(!currentFormats.isEmpty());
                update();
			}
		});

		addAllButton.addSelectionListener(new SelectionAdapter() {
			/*
			 * (non-Javadoc)
			 *
			 * @see
			 * org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse
			 * .swt.events.SelectionEvent)
			 */
			@Override
			public void widgetSelected(SelectionEvent e) {
			    currentFormats.addAll(allFormats);
			    allFormats.clear();
			    addButton.setEnabled(!allViewer.getSelection().isEmpty());
			    removeButton.setEnabled(!currViewer.getSelection().isEmpty());
			    addAllButton.setEnabled(!allFormats.isEmpty());
			    removeAllButton.setEnabled(!currentFormats.isEmpty());
			    update();
			}
		});

		removeAllButton.addSelectionListener(new SelectionAdapter() {
			/*
			 * (non-Javadoc)
			 *
			 * @see
			 * org.eclipse.swt.events.SelectionAdapter#widgetSelected(org.eclipse
			 * .swt.events.SelectionEvent)
			 */
			@Override
			public void widgetSelected(SelectionEvent e) {
			    allFormats.addAll(currentFormats);
			    currentFormats.clear();
			    addButton.setEnabled(!allViewer.getSelection().isEmpty());
			    removeButton.setEnabled(!currViewer.getSelection().isEmpty());
			    addAllButton.setEnabled(!allFormats.isEmpty());
			    removeAllButton.setEnabled(!currentFormats.isEmpty());
			    update();
			}
		});
	}

	void update() {
	    allViewer.refresh();
	    currViewer.refresh();
	}

}
