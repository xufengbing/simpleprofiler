/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.gsttable;

import de.kupzog.ktable.KTable;

/**
 * @author alanlin
 *
 */
public interface KHoverCellChangeListener {
	/**
	 * The method is called when the hovered cell is changed. 
	 * @param x1 the column index of the old hovered cell.
	 * @param y1 the row index of the old hovered cell.
	 * @param x2 the column index of the new hovered cell.
	 * @param y2 the row index of the new hovered cell.
	 * @param table the {@linkplain KTable} on which the hovered cell is change.
	 */
	public void onHoveredCellChange(int x1, int y1, int x2, int y2, KTable table);
}
