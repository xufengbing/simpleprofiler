/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.prefs;

/**
 * @author alanlin
 */
public class PreferenceConstants {
    public final static String IMPORT_TYPE = "com.verigy.itee.gst.type.import";
    public final static String VAR_TYPE = "com.verigy.itee.gst.type.var";
    public final static String RES_TYPE = "com.verigy.itee.gst.type.res";
    public final static String SET_TYPE = "com.verigy.itee.gst.type.set";
    public final static String PROP_TYPE = "com.verigy.itee.gst.type.prop";
    public final static String SELECTION_PATTERN = "com.verigy.itee.gst.selection.pattern";

    public final static String ASK = "Always Ask";
    public final static String NONE = "None";
    public final static String AUTO = "Auto";
}
