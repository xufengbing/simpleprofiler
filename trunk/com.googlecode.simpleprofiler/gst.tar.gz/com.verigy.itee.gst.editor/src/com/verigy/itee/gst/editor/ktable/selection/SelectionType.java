/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.selection;

/**
 * This enumeration indicates the selection type on ktable.
 * @author alanlin
 */
public enum SelectionType {
        /**
         * empty
         */
        EMPTY,
        /**
         * single-whole-row
         */
        SINGLE_WHOLE_ROW,
        /**
         * multi-whole-row
         */
        MULTI_WHOLE_ROW,
        /**
         * single-cell
         */
        SINGLE_CELL,
        /**
         * multi-cell
         */
        MULTI_CELL,
        /**
         * single-whole-column
         */
        SINGLE_WHOLE_COLUMN,
        /**
         * multi-whole-column
         */
        MULTI_WHOLE_COLUMN
}
