/*******************************************************************************
 * Copyright (c) 2006 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.selection;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.ui.IActionFilter;
import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.editor.model.IGenericNode;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;

import de.kupzog.ktable.KTable;

/**
 * An preliminary generic selection element which consists of the selected
 * generic node object(s) which implements {@linkplain IGenericNode} and the selected
 * object type which can be gotten from ATE server and the selected column. The
 * selected object type and the current selected column are string.
 *
 * @author alanlin
 */
public interface IGenericNodeSelectionElement extends IActionFilter, IAdaptable {
    /**
     * @return Returns the first selected data to caller or <code>null</code> if
     * there is no {@linkplain IGenericNode} object is selected.
     */
    public IGenericNode getElement();

    /**
     * @return Returns the selected tdo node
     */
    public ITdoNode getSelectedNode();

    /**
     * This method returns the column string, a.k.a, the column header,
     * of the current selection to caller. The current selection here means the last
     * clicked cell if there is multiply selections. If user clicks on the row
     * header, it returns "HEADER".
     *
     * @return the column of the current selection,
     */
    public String getColumn();

    /**
     * @return Returns the type of current selected object.
     */
    public GenericNodeType getType();

    /**
     * @return Returns the container of this node.
     */
    public GenericNodeType belongTo();


    /**
     * @return Returns the selection type of current selection. Please refer to
     * {@linkplain SelectionType} for all available selection types.
     */
    public SelectionType getSelectionType();

    /**
     * @return Returns the row index of this selection
     */
    public int getModelRowIndex();

    /**
     * @return Returns the selection provider.
     */
    public KTable getTable();

	/**
	 * @return Returns the editor
	 */
	public IEditorPart getEditor();
    /**
     * Empty Element class
     */
    public class EmptyElement implements IGenericNodeSelectionElement {
        private static final String UNKNOWN = "UNKNOWN";
		@Override
		public String getColumn() {
			return UNKNOWN;
		}

		@Override
		public SelectionType getSelectionType() {
			return SelectionType.EMPTY;
		}

		@Override
		public GenericNodeType getType() {
			return GenericNodeType.UNKNOWN;
		}

		@Override
		public boolean testAttribute(Object target, String name, String value) {
			return false;
		}

		@Override
		public Object getAdapter(Class adapter) {
			return null;
		}

		@Override
		public IGenericNode getElement() {
			return null;
		}

		@Override
		public KTable getTable() {
			return null;
		}

		@Override
		public IEditorPart getEditor() {
			// TODO Auto-generated method stub
			return null;
		}

        @Override
        public GenericNodeType belongTo() {
            return GenericNodeType.UNKNOWN;
        }

        @Override
        public ITdoNode getSelectedNode() {
            return null;
        }

        @Override
        public int getModelRowIndex() {
            return -1;
        }
    }

    public static IGenericNodeSelectionElement EMPTY_ELEMENT = new EmptyElement();
}
