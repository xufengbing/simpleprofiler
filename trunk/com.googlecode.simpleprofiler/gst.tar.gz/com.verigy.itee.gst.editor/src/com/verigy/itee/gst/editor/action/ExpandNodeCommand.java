/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.editor.ktable.selection.IGenericNodeSelectionElement;
import com.verigy.itee.gst.explorer.ate.ITdoNode;
import com.verigy.itee.ktabletree.KTableTree;
import com.verigy.itee.ktabletree.KTableTreeModel;

import de.kupzog.ktable.KTable;

/**
 * @author bennwang
 *
 */
public class ExpandNodeCommand extends AbstractGSTHanlder {


    @Override
    protected void operateInUI(IGenericNodeSelectionElement node) {
        if(null == node) {
            return;
        }
        String parameter = (String)getParameters().get("com.verigy.itee.gst.editor.commandpara.expand");
        if(null == parameter) {
            return;
        }
        KTable tableTree = node.getTable();
        if(tableTree instanceof KTableTree) {
            int rowIndex = node.getModelRowIndex();
            rowIndex = ((KTableTreeModel)tableTree.getModel()).mapRowIndexToTable(rowIndex);
            if("EXPAND".equals(parameter)){
                ((KTableTree)tableTree).expand(rowIndex);
            }else if ("COLLAPSE".equals(parameter)){
                ((KTableTree)tableTree).collapse(rowIndex);
            }
        }
    }

    @Override
    protected void refreshKTableModel(KTable table) {
        //do nothing since this command will not change model
    }

    @Override
    protected void focusOn(IEditorPart editor, KTable table, ITdoNode node) {
        //do nothing
    }
}
