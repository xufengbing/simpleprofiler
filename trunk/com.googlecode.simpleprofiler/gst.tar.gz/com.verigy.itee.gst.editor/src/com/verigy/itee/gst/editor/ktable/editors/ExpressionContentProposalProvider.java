/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.editors;

import java.util.ArrayList;

import org.eclipse.jface.fieldassist.IContentProposal;
import org.eclipse.jface.fieldassist.IContentProposalProvider;

import com.verigy.itee.gst.explorer.utils.FuncUtil;

/**
 * @author alanlin
 *
 */
public class ExpressionContentProposalProvider implements IContentProposalProvider {
    private static class Proposal implements IContentProposal {

        private final String fContent;

        private final String fLabel;

        private final String fDescription;

        private final int fCursorPosition;

        Proposal(String content, String label, String description, int cursorPosition) {
            fContent = content;
            fLabel = label;
            fDescription = description;
            fCursorPosition = label.length();
        }

        @Override
        public String getContent() {
            return fContent;
        }

        @Override
        public String getLabel() {
            return fLabel;
        }

        @Override
        public String getDescription() {
            return fDescription;
        }

        @Override
        public int getCursorPosition() {
            return fCursorPosition;
        }
    }

    private final String[] candidates;

    /**
     * Constructor
     *
     * @param candidates list of candidates
     */
    public ExpressionContentProposalProvider(String[] candidates) {
        this.candidates = candidates == null ? new String[0] : candidates;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.eclipse.jface.fieldassist.IContentProposalProvider#getProposals(java.lang.String,
     *      int)
     */
    @Override
    public IContentProposal[] getProposals(String contents, int position) {
        String[] splitedContents = FuncUtil.retrieveVarInExpression(contents);
        String contentNeededToBeMatch = splitedContents.length == 0 ? "" : splitedContents[splitedContents.length - 1];

        ArrayList<Proposal> proposals = new ArrayList<Proposal>();
        for (int i = 0; i < candidates.length; i++) {
//            if (position == 0
//                    || candidates[i].substring(0,
//                            Math.min(candidates[i].length(), position)).equals(
//                                    contentNeededToBeMatch.substring(0, position))) {
            if (candidates[i].length() >= contentNeededToBeMatch.length()
                    && candidates[i].substring(0, contentNeededToBeMatch.length())
                            .equalsIgnoreCase(contentNeededToBeMatch)) {
                proposals.add(new Proposal(candidates[i], candidates[i], null, 0));
            }
        }
        return proposals.toArray(new Proposal[proposals.size()]);
    }
}
