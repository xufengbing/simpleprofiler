/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.action;

import org.eclipse.core.runtime.Assert;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;

import com.verigy.itee.gst.editor.model.FloatingTdoNode;
import com.verigy.itee.gst.editor.model.TdoNodeFactory;
import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.ITdoNode;

/**
 * @author bennwang
 *
 */
public class InputCommand extends AbstractGSTHanlder {

    @Override
    protected ITdoNode operate(ITdoNode node) {
        if(!(node instanceof FloatingTdoNode)) {
            return null;
        }
        FloatingTdoNode selectedNode = (FloatingTdoNode)node;
        ITdoNode parent = (ITdoNode)selectedNode.getParent();
        Assert.isNotNull(parent);
        String valString = selectedNode.getName();
        String[] pair = valString.split(":");
        boolean checker = false;
        if(null != pair && pair.length ==2) {
            //Don't care the case
            GenericNodeType type = GenericNodeType.convertFrom(pair[0].toUpperCase());
            if(parent.getNodeType().checkChildType(type)) {
                checker = true;
                selectedNode.setNodeType(type);
                selectedNode.setName(pair[1]);
            }
        }
        if(checker != true) {
            MessageDialog.openError(Display.getCurrent().getActiveShell(), "Error", "Wrong node type.");
            return null;
        }

        int index = parent.getChildren().indexOf(selectedNode);
        //Check if this floating node is the fisrt child
        ITdoNode newNode = null;
        if(0 == index) {
            newNode = TdoNodeFactory.getInstance().createTdoChildNode(parent, selectedNode.getNodeType(), selectedNode.getName());
        }else {
            newNode = TdoNodeFactory.getInstance().createTdoSiblingNode((ITdoNode)parent.getChildren().get(index -1), selectedNode.getNodeType(), selectedNode.getName());
        }
        newNode.setValue(selectedNode.getValue());
        parent.addChild(newNode, index);
        parent.removeChild(selectedNode);
        return newNode;
    }
}
