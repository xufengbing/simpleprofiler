/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.editor.ktable.editors;

import org.eclipse.jface.fieldassist.TextContentAdapter;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;

import com.verigy.itee.gst.explorer.utils.FuncUtil;

/**
 * @author alanlin
 *
 */
public class TextContentAdapter2 extends TextContentAdapter {
    @Override
    public void insertControlContents(Control control, String text, int cursorPosition) {
        String origText = ((Text) control).getText();
        int index = origText.length() - 1;
        while (index > 0) {
            if (IsDelimited(origText.charAt(index))) {
                break;
            }
            index--;
        }

        String newText = origText.substring(0, index + 1) + text;
        ((Text) control).setText(newText);

        // Insert will leave the cursor at the end of the inserted text. If this
        // is not what we wanted, reset the selection.
        if (cursorPosition < text.length()) {
            ((Text) control).setSelection(index,
                    newText.length() - 1);
        }
    }

    /**
     * @param charAt
     * @return
     */
    private boolean IsDelimited(char charAt) {
        boolean result = false;
        for (char d : FuncUtil.delimited) {
            if (d == charAt) {
                result = true;
                break;
            }
        }
        return result;
    }
}
