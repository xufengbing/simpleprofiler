$comment = " 
   ------------------------------------------------------------------ 
  
     ATTN:              DO NOT CHANGE THIS FILE!!!! 
  
           This is an automatically generated file used to dump 
           module info computed from the Makefile.local into a 
           perl file. This file is used specifically by the build 
           process, and the format may change without warning. 
  
     Module: workspace/com.verigy.itee.gst.explorer 
  
   ------------------------------------------------------------------ 
    Copyright: (C) 2011, Agilent Technologies.  All rights reserved. 
   ------------------------------------------------------------------ 
 "; 
  
 $module_info = { 
     "NAME"                        => "com.verigy.itee.gst.explorer", 
     "DEST"                        => "workspace", 
     "PROJECT_TYPE"                => "eclipse_plugin", 
     "USED_AR_LIBS"                => "", 
     "USED_SH_LIBS"                => "", 
     "USED_SYS_LIBS"               => "", 
     "USED_OBJECT_LIBS"            => "", 
     "USED_RELOCATABLE_FILES"      => "", 
     "CONTAINED_AR_LIBS"           => "", 
     "CONTAINED_SH_LIBS"           => "", 
     "CONTAINED_SYS_LIBS"          => "", 
     "CONTAINED_OBJECT_LIBS"       => "", 
     "CONTAINED_RELOCATABLE_FILES" => "", 
     "RESOLVE_USED_ALTERNATIVES"   => "", 
     "SH_LIB_REPLACEMENTS"         => "", 
     "BIN_SUBDIR"                  => "bin", 
     "LIB_SUBDIR"                  => "lib", 
     "SHLIB_SUBDIR"                => "sh_lib", 
     "COMPONENTS_SHLIB_SUBDIR"     => "sh_lib", 
     "OBJLIB_SUBDIR"               => "obj_lib", 
     "ARCHIVE_LIBRARY_SUFFIX"      => "a", 
     "SHARED_LIBRARY_SUFFIX"       => "so", 
     "OBJECT_LIBRARY_SUFFIX"       => "o", 
     "JAVA_ARCHIVE"                => "/opt/93000/src/workspace/java/com.verigy.itee.gst.explorer.jar", 
     "REQUIRED_MODULES"            => " eclipseRE", 
     "EXTERNAL_TARGETS"            => "workspace/com.verigy.itee.gst.explorer/.build_93k_plugin ", 
     "INTERNAL_TARGETS"            => " ", 
     "CUSTOMER_TARGETS"            => "", 
     "DOCS_INT_TARGETS"            => "", 
     "DOCS_EXT_TARGETS"            => "", 
     "REG_TEST_TARGETS"            => "", 
     "BLD_TEST_TARGETS"            => "", 
     "OTHERUSE_TARGETS"            => "", 
     "GENERATED_SYMLINKS"          => "", 
     "GENERATED_EXT_SYMLINKS"      => "", 
     "SHARED_LIBRARY_TARGETS"      => "", 
     "DO_NOT_PARALLELLIZE_LEAF"     => "", 
     "SELF_CONTAINED_LIB"          => "", 
 };
