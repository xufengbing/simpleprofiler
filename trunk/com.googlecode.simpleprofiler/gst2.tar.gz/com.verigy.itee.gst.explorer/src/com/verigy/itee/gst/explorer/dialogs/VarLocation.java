/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.dialogs;

/**
 * @author alanlin
 *
 */
public class VarLocation {
    public VarLocation(String var, String location) {
        this.var = var;
        this.location = location;
    }

    public final String var;

    public final String location;
}
