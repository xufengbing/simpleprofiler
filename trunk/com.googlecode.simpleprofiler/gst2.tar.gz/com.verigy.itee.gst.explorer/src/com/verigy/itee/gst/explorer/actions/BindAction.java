package com.verigy.itee.gst.explorer.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.actions.ActionDelegate;

import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.core.CorePlugin;
import com.verigy.itee.core.ILogger;
import com.verigy.itee.gst.explorer.Activator;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.markers.AteMarkerFactory;
import com.verigy.itee.gst.explorer.markers.DefaultMarkerFactory;
import com.verigy.itee.gst.explorer.markers.IMarkerFactory;
import com.verigy.itee.gst.explorer.markers.ProblemManager;
import com.verigy.itee.gst.explorer.utils.Util;

public class BindAction extends ActionDelegate {
    private static final ILogger LOG = CorePlugin.getLogger(Activator.PLUGIN_ID);

    private IUTDEntity data;

    private IStructuredSelection selection = StructuredSelection.EMPTY;

    @Override
    public void selectionChanged(IAction action, ISelection sel) {
        if (sel instanceof IStructuredSelection) {
            selection = (IStructuredSelection) sel;
            if (!selection.isEmpty() && selection.size() == 1
                    && selection.getFirstElement() instanceof IUTDEntity) {
                data = ((IUTDEntity) selection.getFirstElement());
            }
        } else {
            selection = StructuredSelection.EMPTY;
        }
    }

    @Override
    public void run(IAction action) {
        InMemoryController.getInstance().bind(data);

        // manually trigger this as we have no events yet
        ProblemManager problemManager = ProblemManager.getInstance();
        IMarkerFactory markerFactory;
        try {
            markerFactory = new AteMarkerFactory();
        } catch (CoreException93k e) {
            markerFactory = new DefaultMarkerFactory();
            LOG.logError("Failed to get AteMarkerFactory", e);
        }
        problemManager.setMarkerFactory(markerFactory);
        problemManager.updateProblems(data);

        Util.refreshExplorer();
    }
}
