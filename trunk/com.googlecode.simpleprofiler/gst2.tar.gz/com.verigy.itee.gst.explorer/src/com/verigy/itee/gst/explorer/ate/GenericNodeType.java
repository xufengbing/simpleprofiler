package com.verigy.itee.gst.explorer.ate;


public enum GenericNodeType {
	UNKNOWN(0, "U"),
	SPEC(1, "S"),
	IMPORT(2, "I"),
	VAR(2, "V"),
	RES(2, "R"),
	SET(3, "S"),
	PROP(4, "P"),
	COMM(7, ""),
	INSTRUMENT(1,"I"),
	NET(2,"N"),
	GROUP(2,"G"),
	CONFIG(11,"C");




	private int level;
	private String representation;
	private GenericNodeType(int level, String res) {
		this.level = level;
		this.representation = res;
	}

	/**
	 * @return Returns the indent level in the xml file.
	 */
	public int getLevel() {
		return level;
	}

    /**
     * @param type the type id which is retrieved from ATE
     * @return Returns the corresponding {@linkplain GenericNodeType}.
     */
    public static GenericNodeType convertFrom(int type) {
        String typeStr = IDService.getInstance().getString(type);
        GenericNodeType result = GenericNodeType.UNKNOWN;
        if (typeStr != null && !typeStr.isEmpty()) {
            for (GenericNodeType t : values()) {
                if (typeStr.equalsIgnoreCase(t.name())) {
                    result = t;
                    break;
                }
            }
        }

        return result == null ? GenericNodeType.UNKNOWN : result;
    }

    /**
     * @param typeStr the type string which is retrieved from ATE
     * @return Returns the corresponding {@linkplain GenericNodeType}.
     */
    public static GenericNodeType convertFrom(String typeStr) {
        GenericNodeType result = GenericNodeType.UNKNOWN;
        if (typeStr != null && !typeStr.isEmpty()) {
            for (GenericNodeType t : values()) {
                if (typeStr.equalsIgnoreCase(t.name())) {
                    result = t;
                    break;
                }
            }
        }

        return result == null ? GenericNodeType.UNKNOWN : result;
    }

    /**
     * Checks if specified type is a child type of this type.
     * @param childType the type of a child
     * @return Returns true if the specified type can be the type of its child.
     * Otherwise, returns false;
     */
    public boolean checkChildType(GenericNodeType childType) {
        if (childType != null && !GenericNodeType.UNKNOWN.equals(childType)) {
            int gap = childType.level - this.level;
            if (gap == 1) {
                return true;
            } else if (gap == 2 && GenericNodeType.PROP.equals(childType)) {
                return true;
            }

            return false;
        }

        return false;
    }

    /**
     * @return Returns the representation string
     */
    public String getRepresentation() {
        return representation;
    }
}
