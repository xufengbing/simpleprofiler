/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.markers;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;

import xoc.svc.pcoll.ZProblemCollection;

import com.verigy.itee.core.CorePlugin;
import com.verigy.itee.core.ILogger;
import com.verigy.itee.gst.explorer.Activator;

/**
 * @author aloskuto
 *
 */
public class DefaultMarkerFactory implements IMarkerFactory {

    private static final ILogger LOG = CorePlugin.getLogger(Activator.PLUGIN_ID);

    @Override
    public Set<IMarker> createMarkers(ZProblemCollection coll){
        Set<IMarker> markers = new HashSet<IMarker>();
        try {
            IResource[] members = CorePlugin.getDeviceProject().members();
            IResourceVisitor visitor = new IResourceVisitor() {

                @Override
                public boolean visit(IResource resource) throws CoreException {
                    String name = resource.getName();
                    if(name.endsWith(".spec") && resource.isAccessible()){
                        Map<String, Object> attributes = new HashMap<String, Object>();
                        attributes.put(PROP_SOURCE_ID, "Andrei's brain");
                        attributes.put(PROP_NAME, name);
                        attributes.put(PROP_PATH, resource.getLocation().toOSString());
                        attributes.put(PROP_CONTEXT, name + "_context");
                        attributes.put(PROP_TDO, name + "_tdo");

                        // TODO we should get this from ATE
                        attributes.put(IMarker.PRIORITY, Integer.valueOf(IMarker.PRIORITY_HIGH));
                        attributes.put(IMarker.SEVERITY, Integer.valueOf(IMarker.SEVERITY_ERROR));
                        attributes.put(IMarker.MESSAGE, "bind of bla bla with blu blu failed");
                        attributes.put(IMarker.LOCATION, "bind location");
                        // TODO we can use it
                        //attributes.put(IDE.EDITOR_ID_ATTR, "bind location");

                        createMarker(resource, attributes);
                    }
                    return resource.getType() != IResource.FILE;
                }
            };

            for (IResource iResource : members) {
                iResource.accept(visitor);
            }
        } catch (CoreException e) {
             LOG.logError("Failed to get device files", e);
        }
        return markers;
    }

    @Override
    public IMarker createMarker(IResource resource, Map<String, Object> attributes) throws CoreException {
        IMarker marker = resource.createMarker(IMarkerFactory.MARKER_TYPE);
        marker.setAttributes(attributes);
        return marker;
    }
}
