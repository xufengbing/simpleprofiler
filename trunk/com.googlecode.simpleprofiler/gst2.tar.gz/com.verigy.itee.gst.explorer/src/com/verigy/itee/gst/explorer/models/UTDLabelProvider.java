/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.jface.viewers.IFontProvider;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.PlatformUI;

import com.verigy.itee.gst.explorer.internal.ConfigEntity;
import com.verigy.itee.gst.explorer.internal.FolderEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.MeasurementRunEntity;
import com.verigy.itee.gst.explorer.internal.PatternEntity;
import com.verigy.itee.gst.explorer.internal.SpecEntity;
import com.verigy.itee.gst.explorer.internal.TestDataLinkEntity;
import com.verigy.itee.gst.explorer.internal.TestFlowEntity;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;
import com.verigy.itee.gst.explorer.internal.TestSuiteEntity;
import com.verigy.itee.gst.explorer.internal.TestSuiteLinkEntity;
import com.verigy.itee.gst.explorer.internal.WaveTableEntity;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * Label Provider for com.verigy.itee.gst.explorer.utdNavigatorContent
 *
 * @author leenshi
 *
 */
public class UTDLabelProvider implements ILabelProvider, IColorProvider, IFontProvider {
    private Color backgroundColor = null;

    private Font font = null;

    /**
     * Constructor
     */
    public UTDLabelProvider() {
        backgroundColor = PlatformUI.getWorkbench().getDisplay()
                .getSystemColor(SWT.COLOR_INFO_BACKGROUND);
        FontData[] fontDatas = PlatformUI.getWorkbench().getDisplay().getSystemFont()
                .getFontData();
        for (FontData data : fontDatas) {
            data.setStyle(data.getStyle() | SWT.BOLD);// |SWT.ITALIC);
        }
        font = new Font(PlatformUI.getWorkbench().getDisplay(), fontDatas);
    }

    @Override
    public Image getImage(Object element) {
        if (element instanceof TestProgramEntity) {
            return Util.getImage(Util.TEST_PROGRAM_NODE);
        }
        if (element instanceof SpecEntity) {
            return Util.getImage(Util.SPEC_NODE);
        }
        if (element instanceof ConfigEntity) {
            return Util.getImage(Util.CONFIG_NODE);
        }
        if (element instanceof PatternEntity) {
            return Util.getImage(Util.PATTERN_NODE);
        }
        if (element instanceof MeasurementRunEntity) {
            return Util.getImage(Util.MESUREMENT_RUN_NODE);
        }
        if (element instanceof TestFlowEntity) {
            return Util.getImage(Util.TEST_FLOW_NODE);
        }
        if (element instanceof TestSuiteEntity) {
            return Util.getImage(Util.TEST_SUITE_NODE);
        }
        if (element instanceof TestSuiteLinkEntity) {
            return Util.getImage(Util.TEST_SUITE_LINK_NODE);
        }
        if (element instanceof TestDataLinkEntity) {
            return Util.getImage(Util.TEST_DATE_LINK_NODE);
        }
        if (element instanceof FolderEntity) {
            return Util.getImage(Util.FOLDER_NODE);
        }
        if (element instanceof WaveTableEntity) {
            return Util.getImage(Util.WAVE_TABLE_NODE);
        }
        return null;
    }

    @Override
    public String getText(Object element) {
        if (element instanceof IUTDEntity) {
            return ((IUTDEntity) element).getName();
        }
        if (element instanceof IResource) {
            return ((IResource) element).getName();
        }
        return null;
    }

    @Override
    public void addListener(ILabelProviderListener listener) {
        // TODO Auto-generated method stub

    }

    @Override
    public void dispose() {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean isLabelProperty(Object element, String property) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void removeListener(ILabelProviderListener listener) {
        // TODO Auto-generated method stub

    }

    @Override
    public Color getBackground(Object element) {
        if (element instanceof IUTDEntity) {
            return backgroundColor;
        }
        return null;
    }

    @Override
    public Color getForeground(Object element) {
//        if (element instanceof IUTDEntity) {
//            return backgroundColor;
//        }
        return null;
    }

    @Override
    public Font getFont(Object element) {
//        if (element instanceof IUTDEntity) {
//            return font;
//        }
        return null;
    }

}
