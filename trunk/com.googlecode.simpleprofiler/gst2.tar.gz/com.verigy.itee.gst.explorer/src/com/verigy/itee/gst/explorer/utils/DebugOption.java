package com.verigy.itee.gst.explorer.utils;

public class DebugOption {

	public static final boolean DEBUG = false;

	public static final boolean DEBUG_PERF = false;

	public static final boolean DEBUG_OUT = false;

}
