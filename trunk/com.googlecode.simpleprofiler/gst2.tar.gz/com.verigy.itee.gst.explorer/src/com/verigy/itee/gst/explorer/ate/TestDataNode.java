/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.ate;

import java.util.ArrayList;
import java.util.List;


/**
 * @author bennwang
 *
 */
public class TestDataNode implements IZTestDataNode {

    protected final int address;
    protected IZTestDataNode parent = null;
    protected ArrayList<IZTestDataNode> children = null;
    private String name = null;
    private String value = null;

    /**
     * @param parent The parent node
     * @param address The node address
     *
     */
    public TestDataNode(final IZTestDataNode parent, int address) {
        this.parent = parent;
        this.address = address;
    }

    /**
     * @param parent The parent node
     * @param address The node address
     * @param name The node name
     *
     */
    public TestDataNode(final IZTestDataNode parent, int address, String name) {
        this.parent = parent;
        this.address = address;
        this.name = name;
    }

    @Override
    public final long getAddress() {
        return this.address;
    }

    @Override
    public List<IZTestDataNode> getChildren() {
        if(null == children) {
            children = UDAccessor.getInstance().getChildren(this);
        }
        return children;
    }

    @Override
    public IZTestDataNode getParent() {
        return parent;
    }

    /**
     * Get the node name from UDA
     * @return Name
     */
    protected String getNameFromUDA() {
        if(null == name) {
            name = UDAccessor.getInstance().getNodeNameFor(address);
        }
        return name;
    }

    @Override
    public String getName() {
        String nameFromUDA = getNameFromUDA();
        if(null == nameFromUDA && null == this.name) {
            return "";
        }
        return this.name;
    }

    /**
     * @return Value from UDA
     */
    protected String getValueFromUDA() {
        if(null == value) {
            value = UDAccessor.getInstance().getNodeValueFor(address);
        }
        return value;
    }

    @Override
    public String getValue() {
        String valueFromUDA = getValueFromUDA();
        if(null == valueFromUDA && null == this.value) {
            return "";
        }
        return this.value;
    }

    /**
     * Set the new name to the under layer
     *
     * @param newName the new name
     */
    protected void setNameToUDA(String newName) {
        UDAccessor.getInstance().setNodeNameFor(newName, address);
    }


    @Override
    public boolean setName(String name) {
        setNameToUDA(name);
        //TODO Benny use the update to get the new name
        this.name = name;
        return true;
    }

    /**
     * Set the new value to UDA
     *
     * @param newValue the new value
     */
    protected void setValueToUDA(final String newValue) {
        UDAccessor.getInstance().setNodeValueFor(newValue, address);
    }


    @Override
    public boolean setValue(String value) {
        setValueToUDA(value);
        this.value = value;
        return true;
    }

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean hasChild() {
        return getChildren().size() > 0 ? true : false;
    }

    @Override
    public IZTestDataNode getChildByName(String name) {
        for (IZTestDataNode child : getChildren()) {
            if (child.getName().equals(name)) {
                return child;
            }
        }
        return null;
    }

}
