/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author leenshi
 *
 */
public class TestDataEntityTemplateCollection {

    private final static String DEFAULT_TEMPLATE_PATH= "templates/default_template.xml";

    private TestDataEntityTemplate root;

    /**
     * constructor
     */
    public TestDataEntityTemplateCollection() {
        init();
    }

    private void init() {
        root = new TestDataEntityTemplate(null, "Template Root");

        Element rootElem = Util.readXmlFile(Util.newURL(DEFAULT_TEMPLATE_PATH));
        if (rootElem == null) {
            return;
        }

        System.out.println("Start parse template==============");
        // read category
        NodeList categoryList = rootElem.getElementsByTagName("category");
        for (int i = 0; i < categoryList.getLength(); i++) {
            Element categoryElem = (Element) categoryList.item(i);

            // read category attributes
            String id = categoryElem.getAttribute("id");
            String suffix = categoryElem.getAttribute("suffix");
            System.out.println("Category: id=" + id + ", suffix=" + suffix);

            // create category object
            TestDataEntityTemplate category = new TestDataEntityTemplate(root, id);

            // read column names of the category
            NodeList nodeList = categoryElem.getElementsByTagName("columns");
            String[][] columns;
            if (nodeList.getLength() > 0) {
                NodeList columnList = ((Element) nodeList.item(0))
                        .getElementsByTagName("column");
                columns = new String[columnList.getLength()][2];
                for (int j = 0; j < columnList.getLength(); j++) {
                    Element elem = (Element) columnList.item(j);
                    columns[j][0] = elem.getAttribute("id");
                    columns[j][1] = elem.getAttribute("multiple");
                    System.out.println("column=" + columns[j][0] + "," + columns[j][1]);
                }
            } else {
                columns = new String[0][0];
            }

            // read template
            nodeList = categoryElem.getElementsByTagName("template");
            for (int j = 0; j < nodeList.getLength(); j++) {
                Element elem = (Element) nodeList.item(j);
                String templateId = elem.getAttribute("id");
                System.out.println("template: id=" + id);

                // read enabled column list in the template
                NodeList enabledList = elem.getElementsByTagName("enabled");
                List<String> enabled = new ArrayList<String>();
                if (enabledList != null) {
                    for (int k = 0; k < enabledList.getLength(); k++) {
                        Element enabledElem = (Element) enabledList.item(k);
                        String value = enabledElem.getAttribute("id");
                        if (!value.isEmpty()) {
                            enabled.add(value);
                        }
                        System.out.println("enabled column=" + value);
                    }
                }

                // create template object
                TestDataEntityTemplate template = new TestDataEntityTemplate(category,
                        templateId, suffix);
                for (int k = 0; k < columns.length; k++) {
                    String value = columns[k][0];
                    boolean multiple = false;
                    if ("true".equalsIgnoreCase(columns[k][1])) {
                        multiple = true;
                    }
                    if (enabled.contains(value)) {
                        template.addColumn(value, true, multiple);
                    } else {
                        template.addColumn(value, false, multiple);
                    }
                }
            }

            // create empty template object
            TestDataEntityTemplate template = new TestDataEntityTemplate(category,
                    "Empty Template", suffix);
            for (int k = 0; k < columns.length; k++) {
                String value = columns[k][0];
                boolean multiple = false;
                if ("true".equalsIgnoreCase(columns[k][1])) {
                    multiple = true;
                }
                template.addColumn(value, false, multiple);
            }
        }
        System.out.println("End parse template==============");
    }

    /**
     * @return Returns the templates.
     */
    public TestDataEntityTemplate getRoot() {
        return root;
    }
}
