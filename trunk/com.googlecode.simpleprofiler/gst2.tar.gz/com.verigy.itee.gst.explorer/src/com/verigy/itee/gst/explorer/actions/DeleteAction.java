/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.actions.BaseSelectionListenerAction;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;

/**
 * Delete test data entity
 *
 * @author leenshi
 *
 */
public class DeleteAction extends BaseSelectionListenerAction {

    private final List<IUTDEntity> data = new ArrayList<IUTDEntity>();

    /**
     * constructor
     */
    public DeleteAction() {
        super("Delete");
    }

    // @Override
    // public boolean isEnabled() {
    // ISelection selection = provider.getSelection();
    // if (!selection.isEmpty()) {
    // IStructuredSelection strSelection = (IStructuredSelection) selection;
    // if (strSelection.size() == 1) {
    // data = strSelection.getFirstElement();
    // return data instanceof IUTDEntity;
    // }
    // }
    // return false;
    // }

    @Override
    public void run() {
        // System.out.println("delete");
        if (data.size() > 0) {
            Iterator<IUTDEntity> iter = data.iterator();
            while (iter.hasNext()) {
                InMemoryController.getInstance().deleteEntity(iter.next());
            }
        }
    }

    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
        // System.out.println("delete.updateSelection()");
        data.clear();

        if (selection.isEmpty()) {
            return false;
        }

        Iterator iter = selection.iterator();
        IZTestDataNode parent = null;
        while (iter.hasNext()) {
            Object selected = iter.next();
            if (!(selected instanceof IUTDEntity)
                    || (selected instanceof TestProgramEntity)) {
                return false;
            }
            IUTDEntity entity = (IUTDEntity) selected;
            if (parent != null && parent != entity.getParent()) {
                return false;
            }
            parent = entity.getParent();
            data.add(entity);
        }
        return true;
    }
}
