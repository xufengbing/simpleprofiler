/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import org.eclipse.core.resources.IResource;

/**
 * Test Data Link Entity
 * @author leenshi
 *
 */
public class TestDataLinkEntity extends FolderEntity {

    private final IResource linkFile;

    /**
     * @param parent parent entity
     * @param linkName the alias name for the target folder
     * @param address node address points to the linked folder in the file system
     * @param resource test data link file
     * @param targetResource target folder
     */
    public TestDataLinkEntity(IUTDContainerEntity parent, int address, String linkName,
            IResource resource, IResource targetResource) {
        super(parent, address, linkName, targetResource);
        linkFile = resource;
    }

    @Override
    public String getPackageName() {
        return ((IUTDContainerEntity) parent).getPackageName() + "/" + getName();
    }
}
