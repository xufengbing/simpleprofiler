/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.ListenerList;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.IDecoration;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ILightweightLabelDecorator;
import org.eclipse.jface.viewers.LabelProviderChangedEvent;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;

import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;
import com.verigy.itee.gst.explorer.markers.IProblemChangedListener;
import com.verigy.itee.gst.explorer.markers.ProblemManager;

/**
 * Label Decorator for com.verigy.itee.gst.explorer.utdNavigatorContent
 *
 * @author leenshi
 *
 */
public class UTDDecorator implements ILightweightLabelDecorator {

    private ListenerList listeners;

    private IProblemChangedListener problemChangedListener;

    @Override
    public void decorate(Object element, IDecoration decoration) {
        if (element instanceof IUTDEntity) {
            if (hasErrorMarker((IUTDEntity) element)) {
                ImageDescriptor imageDescriptor = PlatformUI.getWorkbench()
                        .getSharedImages()
                        .getImageDescriptor(ISharedImages.IMG_DEC_FIELD_ERROR);
                if (imageDescriptor == null) {
                    // It is an eclipse bug (Bugzilla - Bug 304397) that this image does
                    // not
                    // exist in Workbench Image Registry yet.
                    imageDescriptor = JFaceResources.getImageRegistry().getDescriptor(
                            "org.eclipse.jface.fieldassist.IMG_DEC_FIELD_ERROR");
                }
                decoration.addOverlay(imageDescriptor, IDecoration.BOTTOM_RIGHT);
            }
        }
        if (element instanceof TestProgramEntity) {
            decoration.addSuffix(" (In Memory)");
        }
    }

    @Override
    public void addListener(ILabelProviderListener listener) {
        if (listeners == null) {
            listeners = new ListenerList();
        }
        listeners.add(listener);
        if (problemChangedListener == null) {
            problemChangedListener = new IProblemChangedListener() {

                @Override
                public void problemsChanged(IUTDEntity[] changedEntities,
                        boolean markerChanged) {
                    fireProblemsChanged(changedEntities, markerChanged);
                }

            };
            ProblemManager.getInstance().addListener(problemChangedListener);
        }
    }

    @Override
    public void dispose() {
        if (problemChangedListener != null) {
            ProblemManager.getInstance().removeListener(problemChangedListener);
            problemChangedListener = null;
        }
    }

    @Override
    public boolean isLabelProperty(Object element, String property) {
        return false;
    }

    @Override
    public void removeListener(ILabelProviderListener listener) {
        if (listeners != null) {
            listeners.remove(listener);
            if (listeners.isEmpty() && problemChangedListener != null) {
                ProblemManager.getInstance().removeListener(problemChangedListener);
                problemChangedListener = null;
            }
        }
    }

    private boolean hasErrorMarker(IUTDEntity entity) {
        IMarker[] markers = ProblemManager.getInstance().findMarkers(entity);
        if (markers.length > 0) {
            return true;
        }
        return false;
    }

    /**
     * @param changedEntities
     *            related test data entities
     * @param markerChanged
     *            true if marker is changed
     */
    protected void fireProblemsChanged(IUTDEntity[] changedEntities, boolean markerChanged) {
        if (listeners != null && !listeners.isEmpty()) {
            for (Object listener : listeners.getListeners()) {
                ((ILabelProviderListener) listener)
                        .labelProviderChanged(new LabelProviderChangedEvent(this,
                                changedEntities));
            }
        }
    }
}
