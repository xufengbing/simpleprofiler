/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author leenshi
 *
 */
public class TestDataEntityTemplate {

    /**
     * Store column information
     *
     */
    public static class Column {
        private final String columnName;

        private final boolean defaultStatus;

        private boolean columnStatus;

        private final boolean multiple;

        private int count;

        /**
         * @return Returns the columnName.
         */
        public String getColumnName() {
            return columnName;
        }

        /**
         * @return Returns the columnStatus.
         */
        public boolean isColumnSelected() {
            return columnStatus;
        }

        /**
         * @param status
         *            The account to set.
         */
        public void setColumnSelected(boolean status) {
            this.columnStatus = status;
        }

        /**
         * @return Returns the defaultStatus.
         */
        public boolean isDefaultSelected() {
            return defaultStatus;
        }

        /**
         * @return true if can have multiple columns.
         */
        public boolean isMultiple() {
            return multiple;
        }

        /**
         * @return Returns the count.
         */
        public int getCount() {
            return count;
        }

        /**
         * @param count
         *            The count to set.
         */
        public void setCount(int count) {
            if (count < 1) {
                this.count = 1;
            } else {
                this.count = count;
            }
        }

        /**
         * @param name
         *            column name
         * @param status
         *            column selected status
         * @param multi
         *            if the column can be multiple
         */
        public Column(String name, boolean status, boolean multi) {
            columnName = name;
            columnStatus = status;
            defaultStatus = status;
            count = 1;
            multiple = multi;
        }

    }

    private final String name;

    private final String suffix;

    private final TestDataEntityTemplate parent;

    private List<TestDataEntityTemplate> children;

    private final List<Column> columns = new ArrayList<TestDataEntityTemplate.Column>();

    /**
     * @param parent category object
     * @param name template name
     */
    public TestDataEntityTemplate(TestDataEntityTemplate parent, String name) {
        this(parent, name, "");
    }
    /**
     * @param parent category object
     * @param name template name
     * @param suffix suffix of entity file
     */
    public TestDataEntityTemplate(TestDataEntityTemplate parent, String name, String suffix) {
        this.parent = parent;
        this.name = name;
        if (parent != null) {
            parent.addChild(this);
        }
        this.suffix = suffix;
    }

    /**
     * @return template name
     */
    public String getName() {
        return name;
    }

    /**
     * @return category object
     */
    public TestDataEntityTemplate getParent() {
        return parent;
    }

    /**
     * @return true if has children
     */
    public boolean hasChildren() {
        if (children == null || children.size() == 0) {
            return false;
        }
        return true;
    }

    /**
     * @return child templates (category method)
     */
    public List<TestDataEntityTemplate> getChildren() {
        return children;
    }

    /**
     * @param child add child template (category method)
     */
    public void addChild(TestDataEntityTemplate child) {
        if (children == null) {
            children = new ArrayList<TestDataEntityTemplate>();
        }
        children.add(child);
    }

    /**
     * @param colName column name
     * @param status column selected status
     * @param multiple if the column can be multiple
     */
    public void addColumn(String colName, boolean status, boolean multiple) {
        Column column = new Column(colName, status, multiple);
        columns.add(column);
    }

    /**
     * @return column list
     */
    public List<Column> getColumns() {
        return columns;
    }

    /**
     * @return entity file suffix of this template
     */
    public String getSuffix(){
        return suffix;
    }

    /**
     * @return true if this template is a Config template
     */
    public boolean isConfig(){
        return Util.CONFIG_NODE.equals(getSuffix());
    }

    /**
     * @return true if this template is a Spec template
     */
    public boolean isSpec(){
        return Util.SPEC_NODE.equals(getSuffix());
    }

    /**
     * @return file content
     */
    public String createContent() {
        StringBuffer content = new StringBuffer();

        if(isConfig()) {
            content.append("<configuration_sheet ");
            fillFormatString(content);
            content.append(">\n</configuration_sheet>");
        } else if (isSpec()) {
            content.append("<spec_sheet ");
            fillFormatString(content);
            content.append(">\n</spec_sheet>");
        }

        return content.toString();
    }

    private void fillFormatString(StringBuffer content) {
        boolean hasFormat = false;
        Iterator<Column> iter = columns.iterator();
        while (iter.hasNext()) {
            Column column = iter.next();
            if (column.columnStatus) {
                if (!hasFormat) {
                    content.append(" metaData=\"");
                    hasFormat = true;
                } else {
                    content.append(",");
                }
                if (column.count > 1) {
                    for (int i = 1; i <= column.count; i++) {
                        if (i > 1) {
                            content.append(",");
                        }
                        String colName = column.columnName + " " + i;
                        content.append(colName);
                    }
                } else {
                    content.append(column.columnName);
                }
            }
        }
        if (hasFormat) {
            content.append("\"");
        }
    }

    /**
     * @param colName column name
     * @return column object which's name equals to colName
     */
    public Column getColumnByName(String colName) {
        if (colName == null) {
            return null;
        }
        Iterator<Column> iter = columns.iterator();
        while (iter.hasNext()) {
            Column column = iter.next();
            if (column.getColumnName().equals(colName)) {
                return column;
            }
        }
        return null;
    }

    /**
     * @return string of column list
     */
    public String getColumnString(){
        boolean hasFormat = false;
        StringBuffer content = new StringBuffer();
        Iterator<Column> iter = columns.iterator();
        while (iter.hasNext()) {
            Column column = iter.next();
            if (column.columnStatus) {
                if (!hasFormat) {
                    hasFormat = true;
                } else {
                    content.append(",");
                }
                if (column.count > 1) {
                    for (int i = 1; i <= column.count; i++) {
                        if (i > 1) {
                            content.append(",");
                        }
                        String colName = column.columnName + " " + i;
                        content.append(colName);
                    }
                } else {
                    content.append(column.columnName);
                }
            }
        }
        return content.toString();
    }

}
