/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.markers;

import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import xoc.svc.pcoll.ZProblemCollection;

import com.verigy.itee.gst.explorer.Activator;

/**
 * @author aloskuto
 *
 */
public interface IMarkerFactory {
    String MARKER_TYPE = Activator.PLUGIN_ID + ".gstmarker";

    String PROP_PATH = "PROBLEM_PHYSICAL_PATH";
    String PROP_NAME = "PROBLEM_LOGICAL_NAME";
    String PROP_CONTEXT = "PROBLEM_CONTEXT";
    String PROP_TDO = "PROBLEM_TEST_DATA_OBJECT";
    String PROP_SOURCE_ID = "PROBLEM_SOURCE_ID";

    /**
     * @param coll may be null
     * @return non null
     */
    Set<IMarker> createMarkers(ZProblemCollection coll);

    /**
     * @param resource non null
     * @param attributes non null
     * @return non null marker
     * @throws CoreException
     */
    IMarker createMarker(IResource resource, Map<String, Object> attributes) throws CoreException;

}