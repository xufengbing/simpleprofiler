/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.ate;

import java.util.List;

/**
 * @author bennwang
 *
 */
public interface IZTestDataNode {

    /**
     * The unique long type address to identify a node
     *
     * @return The node address
     */
    long getAddress();

    /**
     * Get the children nodes
     *
     * @return The children nodes
     */
    List<IZTestDataNode> getChildren();

    /**
     * TODO Benny move this method to ITdoNode
     * Gets the child by the given name. If there is no child matched, returns
     * null.
     * @param name the name of the child.
     * @return Returns the child with given name.
     */
    IZTestDataNode getChildByName(String name);

    /**
     * Get the parent node
     *
     * @return The parent node
     */
    IZTestDataNode getParent();

    /**
     * Get the node name
     *
     * @return The node name
     */
    String getName();

    /**
     * Get the node value
     *
     * @return The node value
     */
    String getValue();

    /**
     * Set the node name
     *
     * @param name
     * @return boolean
     */
    boolean setName(String name);

    /**
     * Set the node value
     * @param value
     * @return boolean
     */
    boolean setValue(String value);

    /**
     * Check if this node has a child
     * @return boolean
     */
    boolean hasChild();

    /**
     * Update itself and its children when an event is received
     */
    void update();
}
