/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.dialogs;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.ui.dialogs.SelectionDialog;

import com.verigy.itee.gst.explorer.dialogs.DeclarationHelpClass.EntityLocation;
import com.verigy.itee.gst.explorer.dialogs.DeclarationHelpClass.VarList;

/**
 * @author alanlin
 *
 */
public class GoToDeclarationDialog extends SelectionDialog {
    private final VarList[] lists;

    /**
     * @param parentShell the parent shell
     */
    public GoToDeclarationDialog(Shell parentShell, VarList[] lists) {
        super(parentShell);
        this.lists = lists;

        setTitle("Go To Declaration");
        setShellStyle(getShellStyle() | SWT.RESIZE);
    }


    @Override
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite) super.createDialogArea(parent);

        TreeViewer treeViewer = new TreeViewer(composite, SWT.SINGLE);
        Tree tree = treeViewer.getTree();
        tree.setLayoutData(new GridData(GridData.FILL_BOTH));
        tree.setLinesVisible(true);
        tree.setHeaderVisible(true);

        TreeColumn tc = new TreeColumn(tree, SWT.LEFT);
        tc.setText("Variable");
        tc.setWidth(150);

        tc = new TreeColumn(tree, SWT.LEFT);
        tc.setText("Entity Name");
        tc.setWidth(150);

        tc = new TreeColumn(tree, SWT.LEFT);
        tc.setText("Location");
        tc.setWidth(150);

        treeViewer.setContentProvider(new ITreeContentProvider() {
            @Override
            public Object[] getChildren(Object parentElement) {
                if (parentElement instanceof VarList) {
                    return ((VarList) parentElement).lists.toArray();
                }
                return null;
            }

            @Override
            public Object getParent(Object element) {
                if (element instanceof VarList) {
                    return null;
                }

                if (element instanceof EntityLocation) {
                    return ((EntityLocation) element).parent;
                }
                return null;
            }

            @Override
            public boolean hasChildren(Object element) {
                if (element instanceof VarList) {
                    return ((VarList) element).lists.size() != 0;
                }

                return false;
            }

            @Override
            public Object[] getElements(Object inputElement) {
                if (inputElement instanceof VarList[]) {
                    return (VarList[]) inputElement;
                }
                return new Object[0];
            }

            @Override
            public void dispose() {
                // do nothing
            }

            @Override
            public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
                // do nothing
            }
        });

        treeViewer.setLabelProvider(new TableLabelProvider());
        treeViewer.setInput(lists);

        treeViewer.expandAll();

        setInitialSelections(new Object[] {lists[0].lists.get(0)});

        treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {
            @Override
            public void selectionChanged(SelectionChangedEvent event) {
                updateButtons(event.getSelection());
            }
        });

        return dialogArea;
    }

    protected void updateButtons(ISelection selection) {
        if (selection instanceof IStructuredSelection) {
            IStructuredSelection structuredSelection = (IStructuredSelection) selection;
            Object element = structuredSelection.getFirstElement();

            if (element instanceof EntityLocation) {
                getOkButton().setEnabled(true);
                setSelectionResult(new Object[]{element});
                return;
            }
        }
        getOkButton().setEnabled(false);
        setSelectionResult(new Object[0]);
    }

    class TableLabelProvider extends LabelProvider implements ITableLabelProvider {
        @Override
        public Image getColumnImage(Object element, int columnIndex) {
            return null;
        }

        @Override
        public String getColumnText(Object element, int columnIndex) {
            if (element instanceof VarList) {
                if (columnIndex == 0) {
                    return ((VarList) element).var;
                }
            }

            if (element instanceof EntityLocation) {
                EntityLocation entityLocation = (EntityLocation) element;
                String returnValue = "";
                switch (columnIndex) {
                case 0:
                    break;
                case 1:
                    returnValue = entityLocation.entity.getName();
                    break;
                case 2:
                    returnValue = entityLocation.location;
                    break;
                default:
                    break;
                }

                return returnValue;
            }
            return "";
        }
    }
}
