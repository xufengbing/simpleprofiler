/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import org.eclipse.core.resources.IResource;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

/**
 * Interface for Test Date Entity
 * @author leenshi
 *
 */
public interface IUTDEntity extends IZTestDataNode{

	/**
	 * @return Relevant resource in file system
	 */
	public IResource getResource();

	/**
	 * @param path Resource path in file system
	 */
	public void setResource(IResource path);

	/**
	 * @return true if build action is succeed
	 */
	public boolean getBindStatus();

	/**
	 * @param status Build result
	 */
	public void setBindStatus(boolean status);

	/**
	 * @return Entity type
	 */
	public String getType();

	/**
	 * @return Returns the meta data for a TDE or empty string
	 * if the entity is not a TDE entity.
	 */
	public String getMetaData();

	/**
	 * Sets the meta data for a TDE. If the entity is not an TDE, nothing
	 * happens.
	 * @param metaData the meta data to be set.
	 */
	public void setMetaData(String metaData);

	/**
	 * @param parentNode parent node
	 */
	public void setParent(IZTestDataNode parentNode);
}
