/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.dialogs;

import java.util.ArrayList;
import java.util.List;

import com.verigy.itee.gst.explorer.internal.IUTDEntity;

/**
 * @author alanlin
 *
 */
public class DeclarationHelpClass {
    public static class VarList {
        public VarList(String var) {
            this.var = var;
            this.lists = new ArrayList<DeclarationHelpClass.EntityLocation>();
        }

        public void addList(EntityLocation el) {
            lists.add(el);
            el.parent = this;
        }

        @Override
        public int hashCode() {
            return var.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }

            if (obj instanceof VarList) {
                VarList varList = (VarList) obj;

                return this.var.equals(varList.var);
            }

            return false;
        }

        public String var;
        public List<EntityLocation> lists;
    }

    public static class EntityLocation {
        public final IUTDEntity entity;
        public final String location;

        public VarList parent;

        public EntityLocation(IUTDEntity entity, String location) {
            this.entity = entity;
            this.location = location;

        }
    }
}
