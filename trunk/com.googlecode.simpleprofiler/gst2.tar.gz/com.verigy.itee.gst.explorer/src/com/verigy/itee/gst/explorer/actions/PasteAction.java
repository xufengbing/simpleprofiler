/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import java.util.Iterator;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.ui.actions.BaseSelectionListenerAction;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.internal.IUTDContainerEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;
import com.verigy.itee.gst.explorer.models.UTDEntityTransfer;

/**
 * Paste test data entity
 *
 * @author leenshi
 *
 */
public class PasteAction extends BaseSelectionListenerAction {

    private final Clipboard clipboard;

    private IZTestDataNode parentNode;

    /**
     * @param board clip board
     */
    public PasteAction(Clipboard board) {
        super("Paste");
        clipboard = board;
    }

//    @Override
//    public boolean isEnabled() {
//        System.out.println("paste.isenabled()");
//         StackTraceElement[] elems = Thread.currentThread().getStackTrace();
//         for(StackTraceElement elem : elems){
//         System.out.println(elem);
//         }
//        ISelection selection = provider.getSelection();
//        if (selection.isEmpty()) {
//            return false;
//        }
//
//        parentNode = null;
//
//        IStructuredSelection strSelection = (IStructuredSelection) selection;
//        if (strSelection.size() == 1) {
//            Object selected = strSelection.getFirstElement();
//            if (!(selected instanceof IUTDEntity)) {
//                return false;
//            }
//            if (selected instanceof IUTDContainerEntity) {
//                parentNode = (IZTestDataNode) selected;
//            } else {
//                parentNode = ((IUTDEntity) selected).getParent();
//            }
//            return true;
//        }
//        Iterator iter = strSelection.iterator();
//        while (iter.hasNext()) {
//            Object selected = iter.next();
//            if (!(selected instanceof IUTDEntity)
//                    || (selected instanceof TestProgramEntity)) {
//                return false;
//            }
//            IUTDEntity entity = (IUTDEntity) selected;
//            if (parentNode != null && parentNode != entity.getParent()) {
//                return false;
//            }
//            parentNode = entity.getParent();
//        }
//        if (parentNode == null) {
//            return false;
//        }
//
//        return true;
//    }

    @Override
    public void run() {
//        System.out.println("paste");
        if (parentNode != null) {
            Object content = clipboard.getContents(UTDEntityTransfer.getInstance());
            if (!(content instanceof long[])) {
                return;
            }

            long[] addresses = (long[]) content;
            for (int i = 0; i < addresses.length; i++) {
                InMemoryController.getInstance().pasteEntity(parentNode, addresses[i]);
            }
        }
    }

    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
//        System.out.println("paste.updateSelection()");
        parentNode = null;

        if (selection.isEmpty()) {
            return false;
        }

        if (selection.size() == 1) {
            Object selected = selection.getFirstElement();
            if (!(selected instanceof IUTDEntity)) {
                return false;
            }
            if (selected instanceof IUTDContainerEntity) {
                parentNode = (IZTestDataNode) selected;
            } else {
                parentNode = ((IUTDEntity) selected).getParent();
            }
        } else {
        Iterator iter = selection.iterator();
        while (iter.hasNext()) {
            Object selected = iter.next();
            if (!(selected instanceof IUTDEntity)
                    || (selected instanceof TestProgramEntity)) {
                return false;
            }
            IUTDEntity entity = (IUTDEntity) selected;
            if (parentNode != null && parentNode != entity.getParent()) {
                return false;
            }
            parentNode = entity.getParent();
        }
        }
        if (parentNode == null) {
            return false;
        }

        Object content = clipboard.getContents(UTDEntityTransfer.getInstance());
        if(content == null || !(content instanceof long[])){
            return false;
        }

        return true;
    }
}
