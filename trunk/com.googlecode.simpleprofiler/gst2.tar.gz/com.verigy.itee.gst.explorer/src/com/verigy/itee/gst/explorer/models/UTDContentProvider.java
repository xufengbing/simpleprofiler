/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import com.verigy.itee.gst.explorer.internal.IUTDContainerEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;

/**
 * Content Provider for com.verigy.itee.gst.explorer.utdNavigatorContent
 *
 * @author leenshi
 *
 */
public class UTDContentProvider implements ITreeContentProvider {

    @Override
    public Object[] getChildren(Object parentElement) {
        if (parentElement instanceof IProject
                && InMemoryController.getInstance().getCurrentProject() == parentElement) {
            IUTDEntity testProgram = InMemoryController.getInstance().getRoot();
            if (testProgram == null) {
                return new Object[0];
            }
            Object[] childrens = new Object[1];
            childrens[0] = testProgram;
            return childrens;
        }
        if (parentElement instanceof IUTDContainerEntity) {
            return ((IUTDContainerEntity) parentElement).getChildren().toArray();
        }
        return new Object[0];
    }

    @Override
    public Object getParent(Object element) {
        if (element instanceof IUTDEntity) {
            return ((IUTDEntity) element).getParent();
        }
        if (element instanceof IResource) {
            return ((IResource) element).getParent();
        }
        return null;
    }

    @Override
    public boolean hasChildren(Object element) {
        if (element instanceof IContainer) {
            return true;
        }
        if (element instanceof IUTDContainerEntity) {
            return ((IUTDContainerEntity) element).hasChild();
        }
        return false;
    }

    @Override
    public Object[] getElements(Object inputElement) {
        return getChildren(inputElement);
    }

    @Override
    public void dispose() {
        // TODO Auto-generated method stub

    }

    @Override
    public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
        // TODO Auto-generated method stub

    }

}
