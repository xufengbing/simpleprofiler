/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.ide.IGotoMarker;
import org.eclipse.ui.navigator.CommonNavigator;
import org.eclipse.ui.navigator.CommonViewer;
import org.eclipse.ui.navigator.INavigatorContentService;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import xoc.ate.cor.uda.ZTestDataNode;
import xoc.ate.cor.uda.ZTestDataTreeFocus;
import xoc.ate.cor.uda.ZUda;
import xoc.ate.cor.uda.ZUvarLong;
import xoc.ate.cor.uda.ZUvarLongSeq;
import xoc.ate.cor.uda.ZUvarString;

import com.verigy.itee.core.CorePlugin;
import com.verigy.itee.core.ILogger;
import com.verigy.itee.gst.explorer.Activator;
import com.verigy.itee.gst.explorer.ate.IDService;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.UDAccessor;
import com.verigy.itee.gst.explorer.dialogs.DeclarationHelpClass;
import com.verigy.itee.gst.explorer.dialogs.DeclarationHelpClass.EntityLocation;
import com.verigy.itee.gst.explorer.dialogs.DeclarationHelpClass.VarList;
import com.verigy.itee.gst.explorer.dialogs.GoToDeclarationDialog;
import com.verigy.itee.gst.explorer.internal.FileEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.internal.SpecEntity;
import com.verigy.itee.gst.explorer.markers.IMarkerFactory;

/**
 * Utility class, store constants and common methods
 *
 * @author leenshi
 *
 */
public class Util {

    public static final ILogger LOG = CorePlugin.getLogger(Activator.PLUGIN_ID);

    public final static String PROJECT_EXPLOER_VIEW_ID = "org.eclipse.ui.navigator.ProjectExplorer";

    public final static String TEST_PROGRAM_FILE_NAME = ".program";

    public final static String TEST_PROGRAM_NODE = "TestProgram";

    public final static String SPEC_NODE = "spec";

    public final static String CONFIG_NODE = "cfg";

    public final static String MESUREMENT_RUN_NODE = "mrun";

    public final static String TEST_SUITE_NODE = "suite";

    public final static String WAVE_TABLE_NODE = "wtbl";

    /* fake type */
    public final static String PATTERN_NODE = "patt";

    public final static String TEST_FLOW_NODE = "flow";

    public final static String TEST_SUITE_LINK_NODE = "suite_link";

    public final static String FOLDER_NODE = "folder";

    public final static String TEST_DATE_LINK_NODE = "link";
    /* fake type */

    public final static String ERROR_OVERLAY = "ErrorOverlay";

    public final static String BACKGROUND_COLOR = "BackgroundColor";

    public final static String DEFAULT_TEMPLATE_PATH= "templates/default_template.xml";

    private final static Object GoToJobFamily = new Object();
    /**
     * @param url_name path
     * @return a URL to the entry at the specified path
     */
    public static URL newURL(String url_name) {
        return Activator.getDefault().getBundle().getEntry(url_name);
    }

    /**
     * @param imageRegistry Image Registry object
     */
    public static void fillImageRegistry(ImageRegistry imageRegistry) {
        if (imageRegistry == null) {
            return;
        }
        imageRegistry.put(TEST_PROGRAM_NODE,
                ImageDescriptor.createFromURL(newURL("icons/program_entity.png")));
        imageRegistry.put(SPEC_NODE,
                ImageDescriptor.createFromURL(newURL("icons/spec_sheet_entity.png")));
        imageRegistry.put(CONFIG_NODE,
                ImageDescriptor.createFromURL(newURL("icons/config_sheet_entity.png")));
        imageRegistry.put(FOLDER_NODE,
                ImageDescriptor.createFromURL(newURL("icons/fldr_obj.gif")));
        imageRegistry.put(TEST_DATE_LINK_NODE,
                ImageDescriptor.createFromURL(newURL("icons/fldr_link.gif")));
        imageRegistry.put(TEST_FLOW_NODE,
                ImageDescriptor.createFromURL(newURL("icons/flow_entity.png")));
        imageRegistry.put(TEST_SUITE_NODE,
                ImageDescriptor.createFromURL(newURL("icons/suite_entity.png")));
        imageRegistry.put(TEST_SUITE_LINK_NODE,
                ImageDescriptor.createFromURL(newURL("icons/testsuitelink.gif")));
        imageRegistry.put(PATTERN_NODE,
                ImageDescriptor.createFromURL(newURL("icons/pattern_entity.png")));
        imageRegistry.put(MESUREMENT_RUN_NODE,
                ImageDescriptor.createFromURL(newURL("icons/measurment_run_entity.png")));
        imageRegistry.put(WAVE_TABLE_NODE,
                ImageDescriptor.createFromURL(newURL("icons/wavetable_entity.png")));
        imageRegistry.put("ErrorOverlay",
                ImageDescriptor.createFromURL(newURL("icons/error_ovr.gif")));
    }

    /**
     * @param key the key
     * @return the image or null if none
     */
    public final static Image getImage(String key) {
        return Activator.getDefault().getImageRegistry().get(key);
    }

    /**
     * @param key the key
     * @return the descriptor or null if none
     */
    public final static ImageDescriptor getImageDescriptor(String key) {
        return Activator.getDefault().getImageRegistry().getDescriptor(key);
    }

    /**
     *
     * @param file
     *            the file to get the model for
     * @return the file's XMLModel
     */
    private static Document getModelForResource(URL url) {
        DocumentBuilderFactory domfac = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder dombuilder = domfac.newDocumentBuilder();
            return dombuilder.parse(url.openStream());
        } catch (ParserConfigurationException e) {
            LOG.logError("Can't create document builder object for " + url.getFile(), e);
        } catch (FileNotFoundException e) {
            LOG.logError("Can't find file " + url.getFile(), e);
        } catch (SAXException e) {
            LOG.logError("Can't parse file " + url.getFile(), e);
        } catch (IOException e) {
            LOG.logError("Access error for " + url.getFile(), e);
        }
        return null;
    }

    /**
     * @param file XML file
     * @return root node of XML file
     */
    public static Element readXmlFile(URL url) {
        Document doc = getModelForResource(url);
        if (doc == null) {
            return null;
        }

        return doc.getDocumentElement();
    }

    /**
     * @return project explorer view
     */
    public static CommonViewer getProjectExplorerView() {
        CommonNavigator navigator = getProjectExplorerNavigator();
        if (navigator != null) {
            return navigator.getCommonViewer();
        }
        return null;
    }

    private static CommonNavigator getProjectExplorerNavigator() {
        IViewPart part = null;
        try {
            part = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
                    .showView(PROJECT_EXPLOER_VIEW_ID, null, IWorkbenchPage.VIEW_VISIBLE);

            if (part != null && part instanceof CommonNavigator) {
                CommonNavigator navigator = (CommonNavigator) part;
                return navigator;
            }
        } catch (PartInitException e) {
            LOG.logError("Can't show project explorer", e);
        }
        return null;
    }

    /**
     * @param commonViewer Viewer of project explorer
     */
    public static void refreshWithActiveItems(CommonViewer commonViewer) {
        if (commonViewer == null) {
            return;
        }
        IStructuredSelection ssel = null;
        ISelection selection = commonViewer.getSelection();
        if (selection instanceof IStructuredSelection) {
            ssel = (IStructuredSelection) selection;
        }

        refreshCommonViewer(commonViewer);

        if (ssel != null) {
            focusOnItems(ssel.toArray());
        }
    }

    /**
     * @param commonViewer
     *            Viewer of project explorer
     */
    public static void refreshCommonViewer(CommonViewer commonViewer) {
        INavigatorContentService contentService;
        contentService = commonViewer.getNavigatorContentService();
        commonViewer.getControl().setRedraw(false);

        // get active ids
        String[] ids = contentService.getVisibleExtensionIds();
        List<String> checkedExtensions = new ArrayList<String>();
        for (int i = 0; i < ids.length; i++) {

            boolean enabled = contentService.getActivationService()
                    .isNavigatorExtensionActive(ids[i]);
            if (enabled) {
                checkedExtensions.add(ids[i]);
            }
        }
        if (checkedExtensions.size() != 0) {
            ids = checkedExtensions.toArray(new String[checkedExtensions.size()]);
        }
        // end

        contentService.getActivationService().activateExtensions(ids, true);
        contentService.getActivationService().persistExtensionActivations();

        Object[] expandedElements = commonViewer.getExpandedElements();

        contentService.update();

        commonViewer.getControl().setRedraw(true);
        commonViewer.refresh();

        commonViewer.setExpandedElements(expandedElements);
    }

    /**
     * @param resource
     *            Resource in file system
     * @return name of resource, if the resource is a file then the file suffix is not
     *         included.
     */
    public static String getNameFromResource(IResource resource) {
        String name = resource.getName();

        if (resource instanceof IFile) {
            String extention = ((IFile) resource).getFileExtension();
            name = name.substring(0, name.length() - extention.length() - 1);
        }

        return name;
    }

    /**
     * refresh project explorer
     */
    public static void refreshExplorer() {
        CommonViewer viewer = getProjectExplorerView();
        if (null != viewer) {
            refreshWithActiveItems(viewer);
        }
    }

    /**
     * focus on items
     *
     * @param items
     *            the objects should be focused on
     */
    public static void focusOnItems(Object[] items) {
        CommonViewer viewer = getProjectExplorerView();
        if (null != viewer && items != null) {
            IStructuredSelection newSelection = new StructuredSelection(items);
            viewer.setSelection(newSelection, true);
        }
    }

    /**
     * expand items
     *
     * @param items
     *            the objects should be expanded
     *
     */
    public static void expandItem(Object[] items) {
        CommonViewer viewer = getProjectExplorerView();
        if (null != viewer && items != null) {
            for (Object item : items) {
                viewer.setExpandedState(item, true);
            }
        }
    }

    /**
     * @param file the resource file
     * @return Returns the converted TDE node or null if there is no corresponding
     * TDE node.
     */
    public static IZTestDataNode convertToTDENode(IFile file) {
        return InMemoryController.getInstance().findEntityByResource(file);

//        Stack<IUTDEntity> stack = new Stack<IUTDEntity>();
//        IUTDEntity current = InMemoryController.getInstance().getRoot();
//        while(current != null || !stack.isEmpty()) {
//            // A trick here
//            if (current.getResource().equals(file)) {
//                break;
//            }
//
//            if (current.hasChild()) {
//                for (int i = current.getChildren().size() - 1; i >= 0 ; i--) {
//                    IZTestDataNode child = current.getChildren().get(i);
//                    if (child instanceof IUTDEntity) {
//                        stack.push((IUTDEntity)child);
//                    } else {
//                        break;
//                    }
//                }
//                current = null;
//            } else {
//                if (stack.size() > 0) {
//                    current = stack.pop();
//                } else {
//                    current = null;
//                }
//            }
//
//            if (stack.size() > 0 && current == null) {
//                current = stack.pop();
//            }
//        }
//
//        return current;
    }

    /**
     * Goes to the declaration of specified variables. If the length of variables
     * is bigger than 2 or there is only one variable but there are two declarations
     * are found, a dialog will be poped up to prompt use to select the spec.
     * @param variables the variables
     */
    public static void goToDeclarationOf(final String[] variables) {
        Job[] allGoToDecJobs = Job.getJobManager().find(GoToJobFamily);
        boolean shouldDo = true;
        if (allGoToDecJobs.length > 0) {
            if(MessageDialog.openConfirm(null, "Confirmation", "There is a \"Go To Declaration\" job runing, Would you like to cancle the old one and replace with the new one?")) {
                Job.getJobManager().cancel(GoToJobFamily);
            } else {
                shouldDo = false;
            }
        }

        if (shouldDo) {
            Job myJob = new Job("Go To Declaration") {
                @Override
                public boolean belongsTo(Object family) {
                    return GoToJobFamily.equals(family);
                }

                @Override
                protected IStatus run(IProgressMonitor monitor) {
                    doGoToDeclarationWithXPathOf(variables, monitor);
                    return org.eclipse.core.runtime.Status.OK_STATUS;
                }
            };
            myJob.schedule();
        }
    }

//    private static void doGoToDeclarationOf(String[] variables, IProgressMonitor monitor) {
//        // no variable
//        if (variables == null || variables.length == 0) {
//            return;
//        }
//
//        Util.vars = variables;
//        Util.varLists.clear();
//        for (String var : vars) {
//            Util.varLists.put(var, new VarList(var));
//        }
//
//        IUTDEntity root = InMemoryController.getInstance().getRoot();
//
//        ZUda udaService = UDAccessor.getInstance().getUDAService();
//
//        udaService.startTransaction();
//
//        traverseEntity(root, monitor);
//
//        udaService.endTransaction();
//
//        if (monitor.isCanceled()) {
//            return;
//        }
//
//        int count = 0;
//        for (VarList vl : Util.varLists.values()) {
//            count += vl.lists.size();
//        }
//
//        if (count == 1) {
//            for (VarList vl : Util.varLists.values()) {
//                if (vl.lists.size() == 1) {
//                    IUTDEntity entity = vl.lists.get(0).entity;
//                    if(entity instanceof FileEntity){
//                    IEditorPart editorPart = ((FileEntity)entity).open();
//                    if (editorPart != null && editorPart instanceof IGotoMarker) {
//                        IMarker marker = createMarker(vl.lists.get(0));
//                        if (marker != null) {
//                            ((IGotoMarker) editorPart).gotoMarker(marker);
//                        }
//                    }
//                    }
//                }
//            }
//        } else if (count > 1) {
//            Display.getDefault().asyncExec(new Runnable() {
//
//                @Override
//                public void run() {
//                    Shell shell = Display.getDefault().getActiveShell();
//                    GoToDeclarationDialog dialog = new GoToDeclarationDialog(shell,
//                            Util.varLists.values().toArray(new VarList[] {}));
//
//                    if (dialog.open() == Window.OK) {
//                        Object[] result = dialog.getResult();
//                        if (result != null && result.length > 0) {
//                            if (result[0] instanceof EntityLocation) {
//                                EntityLocation el = (EntityLocation) result[0];
//                                IUTDEntity entity = el.entity;
//                                if(entity instanceof FileEntity){
//                                IEditorPart editorPart = ((FileEntity)entity).open();
//                                if (editorPart != null && editorPart instanceof IGotoMarker) {
//                                    IMarker marker = createMarker(el);
//                                    if (marker != null) {
//                                        ((IGotoMarker) editorPart).gotoMarker(marker);
//                                    }
//                                }
//                                }
//                            }
//                        }
//                    }
//                }
//            });
//        } else {
//            final StringBuilder sb = new StringBuilder("Did not find any declaration for variable(s)!");
//            sb.append("\n");
//            sb.append("[");
//            for (int i = 0; i < Util.vars.length; i++) {
//                sb.append(Util.vars[i]);
//                if (i != Util.vars.length -1) {
//                    sb.append(", ");
//                }
//            }
//            sb.append("]");
//            Display.getDefault().syncExec(new Runnable() {
//                @Override
//                public void run() {
//                    MessageDialog.openWarning(null, "Not Found", sb.toString());
//                }
//            });
//        }
//    }

    private static void doGoToDeclarationWithXPathOf(String[] variables, IProgressMonitor monitor) {
        // no variable
        if (variables == null || variables.length == 0) {
            return;
        }

        Util.vars = variables;
        Util.varLists.clear();
        for (String var : vars) {
            Util.varLists.put(var, new VarList(var));
        }

        queryAllVarialbes(variables, monitor);

        if (monitor.isCanceled()) {
            return;
        }

        int count = 0;
        for (VarList vl : Util.varLists.values()) {
            count += vl.lists.size();
        }

        if (count == 1) {
            for (VarList vl : Util.varLists.values()) {
                if (vl.lists.size() == 1) {
                    IUTDEntity entity = vl.lists.get(0).entity;
                    if(entity instanceof FileEntity){
                    IEditorPart editorPart = ((FileEntity)entity).open();
                    if (editorPart != null && editorPart instanceof IGotoMarker) {
                        IMarker marker = createMarker(vl.lists.get(0));
                        if (marker != null) {
                            ((IGotoMarker) editorPart).gotoMarker(marker);
                        }
                    }
                    }
                }
            }
        } else if (count > 1) {
            Display.getDefault().asyncExec(new Runnable() {

                @Override
                public void run() {
                    Shell shell = Display.getDefault().getActiveShell();
                    GoToDeclarationDialog dialog = new GoToDeclarationDialog(shell,
                            Util.varLists.values().toArray(new VarList[] {}));

                    if (dialog.open() == Window.OK) {
                        Object[] result = dialog.getResult();
                        if (result != null && result.length > 0) {
                            if (result[0] instanceof EntityLocation) {
                                EntityLocation el = (EntityLocation) result[0];
                                IUTDEntity entity = el.entity;
                                if(entity instanceof FileEntity){
                                IEditorPart editorPart = ((FileEntity)entity).open();
                                if (editorPart != null && editorPart instanceof IGotoMarker) {
                                    IMarker marker = createMarker(el);
                                    if (marker != null) {
                                        ((IGotoMarker) editorPart).gotoMarker(marker);
                                    }
                                }
                                }
                            }
                        }
                    }
                }
            });
        } else {
            final StringBuilder sb = new StringBuilder("Did not find any declaration for variable(s)!");
            sb.append("\n");
            sb.append("[");
            for (int i = 0; i < Util.vars.length; i++) {
                sb.append(Util.vars[i]);
                if (i != Util.vars.length -1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
            Display.getDefault().syncExec(new Runnable() {
                @Override
                public void run() {
                    MessageDialog.openWarning(null, "Not Found", sb.toString());
                }
            });
        }
    }



    private static void queryAllVarialbes(String[] variables, IProgressMonitor monitor) {
        if (monitor.isCanceled()) {
            return;
        }

        UDAccessor udaAccessor = UDAccessor.getInstance();
        ZUda udaService = udaAccessor.getUDAService();
        udaService.startTransaction();

        ZTestDataTreeFocus zFocus = udaAccessor.getZTestDataTreeFocus();
        ZTestDataNode zTestDataNode = udaAccessor.getZTestDataNode();

        for (String var : variables) {
            if (monitor.isCanceled()) {
                return;
            }
            zFocus.setToRoot();
            String path = "//" + var + "[@subType=\'var\']";
            ZUvarString udaPath = udaService.localString(path);
            zFocus.setToPath(udaPath);

            ZUvarLongSeq matches = udaService.remoteLongSeq();
            zTestDataNode.getAddress(matches);

            udaService.sync();

            int[] addresses = udaService.getLongSeq(matches);

            for (int addr : addresses) {
                if (monitor.isCanceled()) {
                    return;
                }

                zFocus.setToAddress(udaService.localLong(addr));
                zFocus.setToParent();
                zFocus.setToChildren();

                ZUvarLongSeq allChildren = udaService.remoteLongSeq();
                zTestDataNode.getAddress(allChildren);

                udaService.sync();

                int[] children = udaService.getLongSeq(allChildren);
                String fileName = getFileName(addr, udaService, zFocus, zTestDataNode);
                IResource resource = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(fileName));

                for (int i = 0; i < children.length; i++) {
                    if (monitor.isCanceled()) {
                        return;
                    }
                    if (children[i] == addr) {
                        DeclarationHelpClass.VarList list = Util.varLists.get(var);
                        if (list != null) {
                            IUTDEntity entity = InMemoryController.getInstance().findEntityByResource(resource);
                            list.addList(new EntityLocation(entity, String.valueOf(i)));
                        }
                    }
                }
            }

        }
        udaService.endTransaction();
    }

    private static String getFileName(int addr, ZUda udaService, ZTestDataTreeFocus zFocus, ZTestDataNode zTestDataNode) {
        String type = UDAccessor.getInstance().getNodeTypeFor(addr);
        int queryAddr = addr;
        boolean found = true;
        while (!"TEST_DATA_ENTITY".equals(type)) {
            zFocus.setToAddress(udaService.localLong(queryAddr));
            zFocus.setToParent();
            ZUvarLongSeq parentAddr = udaService.remoteLongSeq();
            zTestDataNode.getAddress(parentAddr);

            udaService.sync();
            int[] newAddr = udaService.getLongSeq(parentAddr);

            if (newAddr.length == 0) {
                found = false;
                break;
            }

            queryAddr = newAddr[0];
            type = UDAccessor.getInstance().getNodeTypeFor(queryAddr);
        }

        String result = "";
        if (found) {
            zFocus.setToAddress(udaService.localLong(queryAddr));
            ZUvarString udaString = udaService.remoteString();
            zTestDataNode.getFileName(udaString);

            udaService.sync();

            result = udaService.getString(udaString);
        }
        return result;
    }

    private static int idSpec;
    private static int idVarType;
    private static int idId;
    private static String[] vars;
    private static Map<String, DeclarationHelpClass.VarList> varLists;

    static {
        Util.idSpec = IDService.getInstance().getId("SPEC");
        Util.idVarType = IDService.getInstance().getId("var");
        Util.idId = IDService.getInstance().getId("id");
        Util.varLists = new HashMap<String, DeclarationHelpClass.VarList>();
    }

    private static void traverseEntity(IUTDEntity entity, IProgressMonitor monitor) {
        if (monitor.isCanceled()) {
            return;
        }
        if (entity == null) {
            return;
        }
        if ("SPEC".equals(entity.getType())) {
            visitEntity(entity);
        }

        for (Object child : entity.getChildren()) {
            if (child instanceof IUTDEntity) {
                traverseEntity((IUTDEntity) child, monitor);
            }
        }
    }


    private static void visitEntity(IUTDEntity entity) {
        if (entity instanceof SpecEntity) {
            UDAccessor udaAccessor = UDAccessor.getInstance();
            ZUda zUda = udaAccessor.getUDAService();
            ZTestDataTreeFocus zFocus = udaAccessor.getZTestDataTreeFocus();
            ZTestDataNode zTestDataNode = udaAccessor.getZTestDataNode();

            ZUvarLong nodeAddress = zUda.localLong((int)entity.getAddress());
            ZUvarLongSeq childrenAddress = zUda.remoteLongSeq();
            zFocus.setToAddress(nodeAddress);
            zFocus.setToChildren();
            zTestDataNode.getAddress(childrenAddress);
            zUda.sync();

            int[] addresses = zUda.getLongSeq(childrenAddress);
            int index = 0;
            for (index = 0; index < addresses.length; index++) {
                String type = udaAccessor.getNodeSubTypeFor(addresses[index]);
                if ("var".equalsIgnoreCase(type)) {
                    String compareName = udaAccessor.getNodeNameFor(addresses[index]);
                    if (compareName != null) {
                        DeclarationHelpClass.VarList list = Util.varLists.get(compareName);
                        if (list != null) {
                            list.addList(new EntityLocation(entity, String.valueOf(index)));
                        }
                    }
                }
            }
        }
    }

    /**
     * @param problem non null
     * @return marker instance, may be null
     */
    public static IMarker createMarker(EntityLocation el) {
        if(el == null){
            return null;
        }
        Map<String, Object> attributes = new HashMap<String, Object>();
        try {
            IResource resource = el.entity.getResource();
            if(resource == null || !resource.isAccessible()){
                resource = CorePlugin.getDeviceProject();
            }

            // TODO add the editor id into UIConstants
            attributes.put(IDE.EDITOR_ID_ATTR, "com.verigy.itee.gst.editor.editors.ATEKTable");

            // TODO this is an user visible value - should we provide something meaningful?
            attributes.put(IMarker.LOCATION, el.location);
            // TODO we can use it
            //attributes.put(IDE.EDITOR_ID_ATTR, "bind location");

            IMarker marker = resource.createMarker(IMarkerFactory.MARKER_TYPE);
            marker.setAttributes(attributes);
            return marker;
        } catch (Exception e) {
            LOG.logError("Failed to create marker!" ,e);
        }
        return null;
    }

    /**
     * @return root element of default template xml
     */
    public static Element getDefaultTemplate(){
        try {
            Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(newURL(DEFAULT_TEMPLATE_PATH).openStream());
            return document.getDocumentElement();
        } catch (SAXException e) {
            LOG.logError("Can't parse file ", e);
        } catch (IOException e) {
            LOG.logError("Access error for ", e);
        } catch (ParserConfigurationException e) {
            LOG.logError("Can't create document builder object", e);
        }
        return null;
    }
}
