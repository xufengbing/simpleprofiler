/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import org.eclipse.core.resources.IResource;


/**
 * Test Program Entity
 * @author leenshi
 *
 */
public class TestProgramEntity extends FolderEntity {

	/**
	 * Root entity, no parent
     * @param address node address
	 * @param name entity name
     * @param resource resource in file system
     */
    public TestProgramEntity(int address, String name, IResource resource) {
        super(null, address, name, resource);
    }

//    /**
//     * Root entity, no parent
//     * @param address node address
//     *
//     */
//    public TestProgramEntity(int address) {
//        super(null, address);
//    }
//
//	/**
//	 * Root entity, no parent
//	 * @param resource relevant resource in file system
//	 */
//	public TestProgramEntity(IResource resource) {
//		super(null, resource);
//	}


//    @Override
//	public String getPackageName() {
//	    return "";
//	}
}
