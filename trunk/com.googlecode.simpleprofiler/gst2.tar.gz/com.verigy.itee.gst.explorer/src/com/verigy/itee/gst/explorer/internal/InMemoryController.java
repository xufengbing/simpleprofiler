/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.core.CorePlugin;
import com.verigy.itee.core.IEvent;
import com.verigy.itee.core.IEventListener;
import com.verigy.itee.core.events.IExecutionEvent;
import com.verigy.itee.core.events.IExecutionEvent.EXECUTION_STATE;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.UDAccessor;
import com.verigy.itee.gst.explorer.markers.ProblemManager;
import com.verigy.itee.gst.explorer.utils.OpenEditorUtil;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * Controller for in memory part of the project explorer
 *
 * @author leenshi
 *
 */
public class InMemoryController {

    private TestProgramEntity root;

    private IEventListener mChangeDeviceListener;

    private static InMemoryController instance;

    private InMemoryController() {
        init();
    }

    public static InMemoryController getInstance() {
        if (instance == null) {
            instance = new InMemoryController();
        }
        return instance;
    }

    private void clear() {
        // close opened editors
        OpenEditorUtil.closeTDEEditors();

        // clear bind error
        ProblemManager.getInstance().clearWorkspaceProblems(null);

        // clear root
        setRoot(null);
    }

//    /**
//     * @param item Test Program folder resource
//     * @return true if load is succeed.
//     */
//    public boolean load(IResource item) {
//        return ATEController.load(item);
//    }

    /**
     * @param path Test Program folder path
     * @return true if load is succeed.
     */
    public boolean load(String path) {
        if(getRoot() != null){
            clear();
        }

        setRoot(UDAccessor.getInstance().loadTestProgram(path));
//        ResourceAttributes attrs = getRoot().getResource().getResourceAttributes();
//        attrs.setReadOnly(true);
//        attrs.setHidden(true);
//        try {
//            getRoot().getResource().setResourceAttributes(attrs);
//        } catch (CoreException e) {
//            // LOG.logError("TODO", e);
//        }
        return true;
    }

    public TestProgramEntity getRoot() {
        return root;
    }

    public void setRoot(TestProgramEntity newRoot) {
        root = newRoot;
    }

    public IProject getCurrentProject() {
        return CorePlugin.getDeviceProject();
    }

    private void init() {
        setRoot(null);

        mChangeDeviceListener = new IEventListener() {

            @Override
            public void handle(IEvent event) {
                IExecutionEvent executionEvent = (IExecutionEvent) event;
                EXECUTION_STATE state = executionEvent.getExecutionState();
                if (EXECUTION_STATE.DEVICE_CHANGE_COMPLETED == state) {
                    unload();
                }
            }
        };

        try {
            CorePlugin.addListener(mChangeDeviceListener,
                    IExecutionEvent.class,
                    IExecutionEvent.EXECUTION_STATE.DEVICE_CHANGE_COMPLETED);
        } catch (CoreException93k e) {
            Util.LOG.logError("Add change device listener failed.", e);
        }

    }

    public void bind(IUTDEntity entity) {
        // Call AteServerStub to fake a bind. Hand over the logical name of
        // the TED to bind and the resource name. In the Haussmann target
        // architecture, the TestDataContoller will probably maintain the
        // mapping between logical TDE name and the corresponding resource,
        // and bind (or build) will probably a method to of the
        // Measurement Entity TDE.
        String packageName = "";
        if (entity instanceof IUTDContainerEntity) {
            packageName = ((IUTDContainerEntity) entity).getPackageName();
        } else {
            packageName = ((IUTDContainerEntity) entity.getParent()).getPackageName();
        }

        if (entity instanceof SpecEntity) {
            String resource = entity.getResource().getLocation().toString();
            UDAccessor.getInstance().getAteServerStub()
                    .bind(entity.getName(), resource, packageName);
        }

        List<IZTestDataNode> objs = entity.getChildren();
        if (objs == null) {
            return;
        }
        Iterator<IZTestDataNode> iter = objs.iterator();
        while (iter.hasNext()) {
            IZTestDataNode child = iter.next();
            if (child instanceof IUTDEntity) {
                bind((IUTDEntity) child);
            }
        }
    }

    public void execute(IUTDEntity entity) {
//        ATEController.execute(entity);
    }

    /**
     * find entity by resource from the start entity node
     * @param start the entity node where finding action starts from
     * @param resource resource in file system
     * @return the first entity which has the relevant resource
     */
    public IUTDEntity findEntityByResource(IUTDEntity start, IResource resource) {
        if (resource == null) {
            return null;
        }
        if (start != null) {
            if (start.getResource() != null && start.getResource().equals(resource)) {
                return start;
            }
            if (start.hasChild()) {
                List<IZTestDataNode> children = start.getChildren();
                Iterator<IZTestDataNode> iter = children.iterator();
                while(iter.hasNext()){
                    IZTestDataNode child = iter.next();
                    if(!(child instanceof IUTDEntity)){
                        return null;
                    }
                    IUTDEntity findedEntity = findEntityByResource((IUTDEntity)child, resource);
                    if (findedEntity != null) {
                        return findedEntity;
                    }
                }
            }
        }
        return null;
    }

    /**
     * find entity by resource from the root entity node
     * @param resource resource in file system
     * @return the first entity which has the relevant resource
     */
    public IUTDEntity findEntityByResource(IResource resource) {
        return findEntityByResource(root, resource);
    }

    /**
     * find entities by resource from the start entity node.The entities may more than one
     * since test data link
     *
     * @param start the entity node where finding action starts from
     * @param resource resource in file system
     * @return entities which has the relevant resource
     */
    public List<IUTDEntity> findEntitiesByResource(IUTDEntity start, IResource resource) {
        List<IUTDEntity> entities = new ArrayList<IUTDEntity>();

        if (resource == null) {
            return entities;
        }

        if (start != null) {
            if (start.getResource() != null && start.getResource().equals(resource)) {
                entities.add(start);
            }
            if (start.hasChild()) {
                List<IZTestDataNode> children = start.getChildren();
                Iterator<IZTestDataNode> iter = children.iterator();
                while (iter.hasNext()) {
                    IZTestDataNode child = iter.next();
                    // return when meet TDO node
                    if (!(child instanceof IUTDEntity)) {
                        return entities;
                    }
                    List<IUTDEntity> findedEntities = findEntitiesByResource(
                            (IUTDEntity) child, resource);
                    entities.addAll(findedEntities);
                }
            }
        }
        return entities;
    }

    /**
     * find entities by resource from the root entity node.The entities may more than one
     * since test data link
     *
     * @param resource resource in file system
     * @return entities which has the relevant resource
     */
    public List<IUTDEntity> findEntitiesByResource(IResource resource) {
        return findEntitiesByResource(root, resource);
    }

    /**
     * @return true if unload is succeed.
     */
    public boolean unload() {
        clear();

        // remove entities from UDA
        UDAccessor.getInstance().unloadTestProgram();


        return true;
    }

    public void save(IUTDEntity item) {
//        ATEController.save(item);
    }

    /**
     * @param fromEntity
     *            the selected test data entity
     * @param entityName
     *            new test data entity name
     * @param template
     *            template with format information
     * @return true if create entity is succeed
     */
    public IUTDEntity createEntity(IUTDEntity fromEntity, String entityName,
            TestDataEntityTemplate template) {
        // get parent
        IUTDContainerEntity parent;
        if (fromEntity instanceof IUTDContainerEntity) {
            parent = (IUTDContainerEntity) fromEntity;
        } else {
            parent = (IUTDContainerEntity) fromEntity.getParent();
            if (parent == null) {
                Util.LOG.logError("Create Entity Failed: cannot find parent folder.", null);
                return null;
            }
        }

        // get file content
        String meta = template.getColumnString();
//        if (meta == null) {
//            return null;
//        }

        // get file path
        IPath path = parent.getResource().getFullPath();
        String type = null;
        if (template.isConfig()) {
            path = path.append("/" + entityName + "." + Util.CONFIG_NODE);
            type = "CFG";
        } else if(template.isSpec()){
            path = path.append("/" + entityName + "." + Util.SPEC_NODE);
            type = "SPEC";
        } else {
            return null;
        }

        //create file
//        IFile resource = createFile(entityName, path, content);
//        if (resource == null) {
//            return false;
//        }
//
//        //load file
//        if (!ATEController.loadFileTypeEntity(parent, resource)) {
//            return false;
//        }
//
//        IUTDEntity entity = parent.getChildByName(entityName);
        IUTDEntity entity = UDAccessor.getInstance().createUDANode(parent, entityName, type, meta);
        if (entity == null) {
            return null;
        }
        parent.addChild(entity);
        // focus on the new entity
//        Util.refreshExplorer();
//        Util.focusOnItems(new Object[] { entity });
        // open the new entity in editor
//        if(entity instanceof FileEntity){
//            ((FileEntity) entity).open();
//        }

        return entity;
    }

    private IFile createFile(String entityName, IPath path, String content) {
        // create resource in file system
        IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile(path);
        if (file.exists()) {
            Util.LOG.logError("Create Entity Failed: " + entityName + " already exists.", null);
            return null;
        }

        byte[] bytes = content.getBytes();
        InputStream source = new ByteArrayInputStream(bytes);
        try {
            file.create(source, IResource.NONE, null);
            return file;
        } catch (CoreException e) {
            Util.LOG.logError("Create file " + path + " failed.", e);
            return null;
        }
    }

    /**
     * @param parentNode
     *            target parent node
     * @param address
     *            the address paste from
     */
    public void pasteEntity(IZTestDataNode parentNode, long address) {
        System.out.println("Paste address [" + address + "] under node ["
                + parentNode.getName() + "]. Unimplemented.");
    }

    /**
     * @param entity
     *            the test data entity to be deleted.
     */
    public void deleteEntity(IUTDEntity entity) {
        System.out.println("Delete entity [" + entity.getName() + "]. Unimplemented.");
    }

    /**
     * @param parentNode
     *            target parent node
     * @param entity
     *            entity to be moved
     */
    public void moveEntity(IUTDContainerEntity parentNode, IUTDEntity entity) {
        System.out.println("Move entity [" + entity.getName() + "] to node ["
                + parentNode.getName() + "]. Fake implementation in UI.");
        ((IUTDContainerEntity) (entity.getParent())).removeChild(entity);
        parentNode.addChild(entity);
        entity.setParent(parentNode);
    }
}
