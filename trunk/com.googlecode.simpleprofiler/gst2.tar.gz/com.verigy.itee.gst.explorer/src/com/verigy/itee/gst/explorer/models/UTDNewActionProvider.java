/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.navigator.CommonActionProvider;
import org.eclipse.ui.navigator.ICommonActionExtensionSite;
import org.eclipse.ui.navigator.ICommonMenuConstants;
import org.eclipse.ui.navigator.ICommonViewerSite;
import org.eclipse.ui.navigator.ICommonViewerWorkbenchSite;
import org.eclipse.ui.navigator.WizardActionGroup;

/**
 * @author leenshi
 *
 */
public class UTDNewActionProvider extends CommonActionProvider {

    private static final String NEW_MENU_NAME = "common.new.menu";

    private WizardActionGroup newWizardActionGroup;

    /**
     * constructor
     */
    public UTDNewActionProvider() {
        super();
    }

    @Override
    public void init(ICommonActionExtensionSite aSite) {
        ICommonViewerSite site = aSite.getViewSite();
        if (site instanceof ICommonViewerWorkbenchSite) {
            ICommonViewerWorkbenchSite workbenchSite = (ICommonViewerWorkbenchSite) site;
            newWizardActionGroup = new WizardActionGroup(
                    workbenchSite.getWorkbenchWindow(), PlatformUI.getWorkbench()
                            .getNewWizardRegistry(), WizardActionGroup.TYPE_NEW,
                    aSite.getContentService());
        }
    }

    @Override
    public void fillContextMenu(IMenuManager menu) {
      IMenuManager submenu = menu.findMenuUsingPath(NEW_MENU_NAME);
      if (submenu == null) {
          submenu = new MenuManager("New", NEW_MENU_NAME);
          // fill the menu from the commonWizard contributions
          newWizardActionGroup.setContext(getContext());
          newWizardActionGroup.fillContextMenu(submenu);

          // append the submenu after the GROUP_NEW group.
          // menu.insertBefore(ICommonMenuConstants.GROUP_OPEN, submenu);
          menu.appendToGroup(ICommonMenuConstants.GROUP_NEW, submenu);
      }
    }

    @Override
    public void fillActionBars(IActionBars actionBars) {
        // TODO Auto-generated method stub
        super.fillActionBars(actionBars);
    }

}
