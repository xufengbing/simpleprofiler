/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import org.eclipse.core.resources.IResource;

/**
 * link to Test Suite, sub entity of Test Flow
 * @author leenshi
 *
 */
public class TestSuiteLinkEntity {

	private final TestSuiteEntity realTestSuite;
	private final TestFlowEntity parentEntity;
	private boolean bindStatus = true;

	/**
     * @param parent Parent entity
     * @param testSuite Relevant test suite entity
     */
	public TestSuiteLinkEntity(TestFlowEntity parent, TestSuiteEntity testSuite) {
		parentEntity = parent;
		realTestSuite = testSuite;
	}

	public IResource getResource() {
		return realTestSuite.getResource();
	}

	public void setResource(IResource resource) {
		//empty
	}

	public String getName() {
		return realTestSuite.getName();
	}

	public boolean getBindStatus() {
		return bindStatus;
	}

	public void setBindStatus(boolean status) {
		bindStatus = status;
	}

    public String getType() {
        return "SLINK";
    }


}
