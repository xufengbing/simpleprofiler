/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;


/**
 * Pattern Entity
 * @author leenshi
 *
 */
public class PatternEntity extends FileEntity {

	/**
	 * @param parent parent entity
	 * @param address node address
     */
    public PatternEntity(final IUTDContainerEntity parent, int address) {
        super(parent, address);
    }

    @Override
    public String getType() {
        return "PATT";
    }

}
