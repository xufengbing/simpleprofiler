/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.ui.actions.BaseSelectionListenerAction;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;
import com.verigy.itee.gst.explorer.models.UTDEntityTransfer;

/**
 * Copy test data entity
 *
 * @author leenshi
 *
 */
public class CopyAction extends BaseSelectionListenerAction {

    private final Clipboard clipboard;

    private final PasteAction pasteAction;

    private final List<IUTDEntity> data = new ArrayList<IUTDEntity>();

    /**
     * @param board clip board
     * @param action relevant paste action
     */
    public CopyAction(Clipboard board,
            PasteAction action) {
        super("Copy");
        clipboard = board;
        pasteAction = action;
    }

    // @Override
    // public boolean isEnabled() {
    // System.out.println("copy.isenabled()");
    // StackTraceElement[] elems = Thread.currentThread().getStackTrace();
    // for(StackTraceElement elem : elems){
    // System.out.println(elem);
    // }
    // ISelection selection = provider.getSelection();
    // if (selection.isEmpty()) {
    // return false;
    // }
    //
    // data.clear();
    //
    // IStructuredSelection strSelection = (IStructuredSelection) selection;
    // Iterator iter = strSelection.iterator();
    // IZTestDataNode parent = null;
    // while (iter.hasNext()) {
    // Object selected = iter.next();
    // if (!(selected instanceof IUTDEntity)
    // || (selected instanceof TestProgramEntity)) {
    // return false;
    // }
    // IUTDEntity entity = (IUTDEntity) selected;
    // if (parent != null && parent != entity.getParent()) {
    // return false;
    // }
    // parent = entity.getParent();
    // data.add(entity);
    // }
    // return true;
    // }

    @Override
    public void run() {
//        System.out.println("copy");
        if (data.size() > 0) {
            clipboard.setContents(
                    new Object[] { data.toArray(new IUTDEntity[data.size()]) },
                    new Transfer[] { UTDEntityTransfer.getInstance() });

            // update the enablement of the paste action
            // workaround since the clipboard does not suppot callbacks
            if (pasteAction != null && pasteAction.getStructuredSelection() != null) {
                pasteAction.selectionChanged(pasteAction.getStructuredSelection());
            }
        }
    }

    @Override
    protected boolean updateSelection(IStructuredSelection selection) {
//        System.out.println("copy.updateSelection()");
        data.clear();

        if (selection.isEmpty()) {
            return false;
        }

        Iterator iter = selection.iterator();
        IZTestDataNode parent = null;
        while (iter.hasNext()) {
            Object selected = iter.next();
            if (!(selected instanceof IUTDEntity)
                    || (selected instanceof TestProgramEntity)) {
                return false;
            }
            IUTDEntity entity = (IUTDEntity) selected;
            if (parent != null && parent != entity.getParent()) {
                return false;
            }
            parent = entity.getParent();
            data.add(entity);
        }
        return true;
    }
}
