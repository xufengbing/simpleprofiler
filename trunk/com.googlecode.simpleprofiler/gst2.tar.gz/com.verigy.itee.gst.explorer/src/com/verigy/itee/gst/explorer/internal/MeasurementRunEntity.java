/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;


/**
 * Measurement Run Entity
 * @author leenshi
 *
 */
public class MeasurementRunEntity extends FileEntity {

	/**
	 * @param parent parent entity
	 * @param address node address
	 */
	public MeasurementRunEntity(final IUTDContainerEntity parent, int address){
	    super(parent,address);
	}

    @Override
    public String getType() {
        return "MRUN";
    }
}
