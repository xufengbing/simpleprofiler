/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.utils;

import java.util.ArrayList;
import java.util.List;


/**
 * @author alanlin
 *
 */
public class FuncUtil {
    public final static char[] delimited = new char[] {
        '+', '/','-', '*', '%', ',', '.', '(', ')', '@', '#', ' '
    };

    /**
     * The method retrieves all variables from an expression. For example, given
     * an expression "a + b - c", the return value will be an array of string contains
     * three members receptively "a", "b" and "c". There is no <code>null<code> is
     * returned.
     * @param expression the expression.
     * @return Returns the all variables.
     */
    public static String[] retrieveVarInExpression(String expression) {
        String[] result = new String[0];

        if (expression != null && !expression.isEmpty()) {
            String[] vars = expression.split("[+|-|*|/|%|&|,|.|#|$|@|!|(|)| ]");

            char x = expression.charAt(expression.length() - 1);
            boolean endWithDelimited = false;
            for (char d : delimited) {
                if (d == x) {
                    endWithDelimited = true;
                    break;
                }
            }

            int newLength = endWithDelimited ? vars.length + 1 : vars.length;
            result = new String[newLength];
            for (int i = 0; i < vars.length; i++) {
                result[i] = vars[i].trim();
            }

            if (endWithDelimited) {
                result[result.length - 1] = "";
            }
        }

        return result;
    }

    /**
     * Filters all number variables (constants).
     * @param elements all elements
     * @return Returns the filtered elements
     */
    public static String[] filterDigitalElements(String[] elements) {
        List<String> result = new ArrayList<String>();

        for (String e : elements) {
            try {
                Integer.valueOf(e);
            } catch (NumberFormatException ex) {
                if (!e.isEmpty()) {
                    result.add(e);
                }
            }
        }

        return result.toArray(new String[result.size()]);
    }
}
