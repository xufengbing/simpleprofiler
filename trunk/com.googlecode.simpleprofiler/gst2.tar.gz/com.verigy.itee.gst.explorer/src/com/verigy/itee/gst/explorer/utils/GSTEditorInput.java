/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.utils;

import org.eclipse.core.resources.IFile;
import org.eclipse.ui.part.FileEditorInput;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

/**
 * Since all structural changes are reflected to the file system directly, all
 * TDEs in Project Explorer should have corresponding physical files. There is
 * one-to-one mapping.
 * @author alanlin
 */
public class GSTEditorInput extends FileEditorInput {

    //TODO by benny
    private String type = "";

    private String packageName = "";

    private final IZTestDataNode node;
    /**
     * @param file the corresponding physical file for the selected TDE.
     * @param type the TDE type
     * @param packageName the package name which the test data entity belongs to
     *
     */
    public GSTEditorInput(IFile file, String type, String packageName, IZTestDataNode node) {
        super(file);
        this.type = type;
        this.packageName = packageName;
        this.node = node;
    }

    @Override
    public String getName() {
        IFile file = getFile();
        if (file != null) {
            file.getName();
        }
        return super.getName();
    }

    /**
     * @return the TDE type
     */
    public String getType() {
        return this.type;
    }

    /**
     * @return Returns the packageName.
     */
    public String getPackageName() {
        return packageName;
    }

    public IZTestDataNode getNode() {
        return node;
    }
}
