/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.util.LocalSelectionTransfer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.TransferData;
import org.eclipse.ui.navigator.CommonDropAdapter;
import org.eclipse.ui.navigator.CommonDropAdapterAssistant;

import com.verigy.itee.gst.explorer.Activator;
import com.verigy.itee.gst.explorer.internal.IUTDContainerEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * Drop adapter assistant
 * @author leenshi
 *
 */
public class DropAdapterAssistant extends CommonDropAdapterAssistant {

    private static IUTDEntity[] NO_ENTITY = new IUTDEntity[0];

    /**
     * constructor
     */
    public DropAdapterAssistant() {
        super();
    }

    @Override
    public IStatus validateDrop(Object target, int operation, TransferData transferType) {
        if (!(target instanceof IUTDEntity)) {
            return new Status(IStatus.INFO, Activator.PLUGIN_ID,
                    "Target must be in memory.");
        }
        return Status.OK_STATUS;
    }

    @Override
    public IStatus handleDrop(CommonDropAdapter dropAdapter,
            DropTargetEvent dropTargetEvent, Object target) {
        if (dropAdapter.getCurrentTarget() == null || dropTargetEvent.data == null) {
            return Status.CANCEL_STATUS;
        }

        IStatus status = null;
        IUTDEntity[] entities = null;
        TransferData currentTransfer = dropAdapter.getCurrentTransfer();
        if (LocalSelectionTransfer.getTransfer().isSupportedType(currentTransfer)) {
            entities = getSelectedNodes();
            dropTargetEvent.detail = DND.DROP_NONE;
        }

        if (entities != null && entities.length > 0) {
            status = performEntityMove(dropAdapter, entities);
        }

        return status;
    }

    /**
     * @param dropAdapter
     * @param entities
     * @return
     */
    private IStatus performEntityMove(CommonDropAdapter dropAdapter, IUTDEntity[] entities) {
        Object currentTarget = dropAdapter.getCurrentTarget();
        if (!(currentTarget instanceof IUTDEntity)) {
            return new Status(IStatus.INFO, Activator.PLUGIN_ID,
                    "Target must be a test data entity.");
        }

        IUTDContainerEntity target;
        if (currentTarget instanceof IUTDContainerEntity) {
            target = (IUTDContainerEntity) currentTarget;
        } else {
            target = (IUTDContainerEntity) ((IUTDEntity) currentTarget).getParent();
        }
        for (int i = 0; i < entities.length; i++) {
            InMemoryController.getInstance().moveEntity(target, entities[i]);
        }

        // refresh project explorer
        Util.refreshExplorer();

        return Status.OK_STATUS;
    }

    private IUTDEntity[] getSelectedNodes() {
        ISelection selection = LocalSelectionTransfer.getTransfer().getSelection();
        if (selection instanceof IStructuredSelection) {
            return getSelectedNodes((IStructuredSelection) selection);
        }
        return NO_ENTITY;
    }

    private IUTDEntity[] getSelectedNodes(IStructuredSelection selection) {
        List<IUTDEntity> selected = new ArrayList<IUTDEntity>();

        for (Iterator i = selection.iterator(); i.hasNext();) {
            Object o = i.next();
            if (o instanceof IUTDEntity) {
                selected.add((IUTDEntity) o);
            }
        }
        return selected.toArray(new IUTDEntity[selected.size()]);
    }
}
