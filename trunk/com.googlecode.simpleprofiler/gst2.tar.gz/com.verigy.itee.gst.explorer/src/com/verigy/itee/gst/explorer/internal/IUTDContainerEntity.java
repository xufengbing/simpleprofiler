/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

/**
 * Interface for container entity like test program, folder, test data link
 * @author leenshi
 *
 */
public interface IUTDContainerEntity extends IUTDEntity {

	/**
	 * add child to the container
	 * @param entity child entity
	 */
	public void addChild(IUTDEntity entity);

	/**
	 * remove the child entity
	 * @param entity child entity
	 */
	public void removeChild(IUTDEntity entity);

	/**
	 * @return the relevant package name in UDA layer
	 */
	public String getPackageName();

//	/**
//	 * @param name child entity's name
//	 * @return child entity
//	 */
//	public IUTDEntity getChildByName(String name);

}
