/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.ate;

import java.util.HashMap;
import java.util.Map;

import xoc.exc.ZParameterException;
import xoc.svc.ZIDService;

import com.sun.star.uno.Exception;
import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.svc.unoaccess.UnoAccessor;

/**
 * @author alanlin
 *
 */
public class IDService {
	private static IDService idService;
	private ZIDService zid;
	private Map<String, Integer> idMap;
	private Map<Integer, String> strMap;
	private IDService(ZIDService zid) {
		this.zid = zid;
		idMap = new HashMap<String, Integer>(10);
		strMap = new HashMap<Integer, String>(10);
	}

	
	public static IDService getInstance() {
		if (idService == null) {
			try {
				ZIDService realId = UnoAccessor.getUnoServiceManager().getInstance("xoc.svc.ZSIDService", null, ZIDService.class);
				idService = new IDService(realId);
			} catch (CoreException93k e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return idService;
	}
	
	public int getId(String type) {
		Integer id = idMap.get(type);
		if (id == null) {
			int intId = zid.getId(type);
			
			id = Integer.valueOf(intId);
			idMap.put(type, id);
		}
		
		return id.intValue();
	}
	
	public String getString(int id) {
		Integer idInt = Integer.valueOf(id);
		String strVal = strMap.get(idInt);
		if (strVal == null || strVal.isEmpty()) {
			try {
				strVal = zid.getString(id);
				strMap.put(idInt, strVal);
			} catch (ZParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "";
			}
		}
		
		return strVal;
	}
}
