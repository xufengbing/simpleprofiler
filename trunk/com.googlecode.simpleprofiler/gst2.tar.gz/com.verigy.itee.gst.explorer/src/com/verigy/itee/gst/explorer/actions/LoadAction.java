/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.actions.ActionDelegate;

import com.verigy.itee.gst.explorer.Activator;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;
import com.verigy.itee.gst.explorer.markers.ProblemManager;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * Load Test Data Entity action. Currently, only Test Program can be loaded.
 * @author leenshi
 *
 */
public class LoadAction extends ActionDelegate {

	private IResource data;

	private IStructuredSelection selection = StructuredSelection.EMPTY;

	@Override
	public void selectionChanged(IAction action, ISelection sel) {
		if (sel instanceof IStructuredSelection) {
			selection = (IStructuredSelection) sel;
			if (!selection.isEmpty() && selection.size() == 1
					&& selection.getFirstElement() instanceof IFolder) {
				data = ((IResource) selection.getFirstElement());
			}
		} else {
			selection = StructuredSelection.EMPTY;
			data = null;
		}
	}

	@Override
	public void run(IAction action) {
		if (data != null) {
			if(!InMemoryController.getInstance().load(data.getLocation().toOSString())){
                MessageDialog.openError(Activator.getDefault().getWorkbench()
                        .getDisplay().getActiveShell(), "Load Error", "Failed");
			    return;
			}

			// manually trigger this as we have no events yet
	        ProblemManager problemManager = ProblemManager.getInstance();
	        problemManager.clearWorkspaceProblems(null);

	        // refresh project explorer
			Util.refreshExplorer();

			// focus on In Memory Test Program Entity and expand the first layer
			TestProgramEntity root = InMemoryController.getInstance().getRoot();
			if(root != null){
			    Object[] objects = new Object[1];
			    objects[0] = root;
			    Util.focusOnItems(objects);
			    Util.expandItem(objects);
			}
		}
	}
}
