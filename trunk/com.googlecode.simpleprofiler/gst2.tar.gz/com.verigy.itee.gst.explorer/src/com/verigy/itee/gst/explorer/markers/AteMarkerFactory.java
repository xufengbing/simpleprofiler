/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.markers;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Path;
import org.eclipse.ui.ide.IDE;

import xoc.svc.ZIDService;
import xoc.svc.ZPropertyValueList;
import xoc.svc.pcoll.ZProblem;
import xoc.svc.pcoll.ZProblemCollection;
import xoc.svc.pcoll.ZProblemType;

import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.core.CorePlugin;
import com.verigy.itee.core.ILogger;
import com.verigy.itee.core.util.FileUtils;
import com.verigy.itee.gst.explorer.Activator;
import com.verigy.itee.svc.unoaccess.UnoAccessor;

/**
 * @author aloskuto
 */
public class AteMarkerFactory extends DefaultMarkerFactory {
    private static final ILogger LOG = CorePlugin.getLogger(Activator.PLUGIN_ID);

    private final ZIDService idService;

    /**
     * @throws CoreException93k in case ID service couldn't be resolved
     */
    public AteMarkerFactory()  throws CoreException93k {
        super();
        try {
            idService = UnoAccessor.getUnoServiceManager().getInstance("xoc.svc.ZSIDService", null, ZIDService.class);
        } catch (com.sun.star.uno.Exception e) {
            throw new CoreException93k(Activator.PLUGIN_ID, "Failed to create id service", e);
        }
    }

    /**
     * @param problem non null
     * @return marker instance, may be null
     */
    public IMarker createMarker(ZProblem problem) {
        if(problem == null){
            return null;
        }
        Map<String, Object> attributes = new HashMap<String, Object>();
        try {
            ZPropertyValueList pvlist = problem.getPropertiesRef();
            String path = pvlist.getValueAsString(idService.getId(PROP_PATH));
            if(path != null){
                attributes.put(PROP_PATH, path);
            }

            IResource resource = FileUtils.getResource(new Path(path), true);
            if(resource == null || !resource.isAccessible()){
                return null;
            }

            attributes.put(PROP_CONTEXT, pvlist.getValueAsString(idService.getId(PROP_CONTEXT)));
            attributes.put(PROP_NAME, pvlist.getValueAsString(idService.getId(PROP_NAME)));
            attributes.put(PROP_SOURCE_ID,
                    Integer.valueOf(pvlist.getValueAsInt(idService.getId(PROP_SOURCE_ID))));
            attributes.put(PROP_TDO, pvlist.getValueAsString(idService.getId(PROP_TDO)));

            // TODO we should get this from ATE?
            attributes.put(IMarker.PRIORITY, Integer.valueOf(IMarker.PRIORITY_HIGH));

            ZProblemType problemType = problem.getType();
            int severity = IMarker.SEVERITY_INFO;
            if (problemType == ZProblemType.ERROR) {
                severity = IMarker.SEVERITY_ERROR;
            }
            else if (problemType == ZProblemType.WARNING) {
                severity = IMarker.SEVERITY_WARNING;
            }
            attributes.put(IMarker.SEVERITY, Integer.valueOf(severity));

            attributes.put(IMarker.MESSAGE, problem.getMessage());

            // TODO add the editor id into UIConstants
            attributes.put(IDE.EDITOR_ID_ATTR, "com.verigy.itee.gst.editor.editors.ATEKTable");

            // TODO this is an user visible value - should we provide something meaningful?
            attributes.put(IMarker.LOCATION, attributes.get(PROP_TDO));
            // TODO we can use it
            //attributes.put(IDE.EDITOR_ID_ATTR, "bind location");

            return createMarker(resource, attributes);
        } catch (Exception e) {
            LOG.logError("Failed to create marker from " + problem, e);
        }
        return null;
    }




    /**
     * @param coll may be null
     * @return non null
     */
    @Override
    public Set<IMarker> createMarkers(ZProblemCollection coll){
        Set<IMarker> markers = new HashSet<IMarker>();
        if(coll == null){
            return markers;
        }
        int count = coll.getCount(ZProblemType.ALL);
        if(count <= 0){
            return markers;
        }
        for (int i = 0; i < count; i++) {
            try {
                ZProblem problem = coll.getProblem(i);
                if(problem == null){
                    break;
                }
                IMarker marker = createMarker(problem);
                if(marker != null){
                    markers.add(marker);
                }
            } catch (Exception e) {
                LOG.logError("No problems for " + i, e);
                break;
            }
        }
        return markers;
    }
}
