package com.verigy.itee.gst.explorer.wizards;

import org.eclipse.core.resources.IFolder;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.dialogs.WizardNewFolderMainPage;
import org.eclipse.ui.wizards.newresource.BasicNewFolderResourceWizard;

public class TestProgramWizard extends BasicNewFolderResourceWizard {
	private WizardNewFolderMainPage mainPage;
	@Override
	public void addPages() {
        mainPage = new WizardNewFolderMainPage("Test Program", getSelection()); 
        addPage(mainPage);
	}
	
	@Override
	public boolean performFinish() {
		IFolder folder = mainPage.createNewFolder();
        if (folder == null) {
			return false;
		}
//        final IPath folderPath = folder.getFullPath();
//    	IPath newPath = folderPath.append("/"+Util.TEST_PROGRAM_FILE_NAME);
//    	IFile file = new File
    	
        selectAndReveal(folder);

        return true;
	}

	@Override
	public void init(IWorkbench workbench, IStructuredSelection sel) {
		super.init(workbench, sel);
        setWindowTitle("New Test Program");
	}

}
