/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.wizards;

import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.verigy.itee.gst.explorer.internal.FileEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.internal.TestDataEntityTemplate;
import com.verigy.itee.gst.explorer.internal.TestDataEntityTemplateCollection;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author leenshi
 *
 */
public class UTDSelectTemplatePage extends WizardPage {

    private final IStructuredSelection selection;

    private Tree templateTree;

    private Text entityName;

    private Table columnTable;

    private Label columnCountLabel;

    private Text columnCount;

    private final TestDataEntityTemplateCollection templateCollection;

    /**
     * @param name page name
     * @param sel selected item
     */
    public UTDSelectTemplatePage(String name, IStructuredSelection sel) {
        super(name);
        setTitle(name);
        selection = sel;
        setPageComplete(false);
        templateCollection = new TestDataEntityTemplateCollection();
    }

    @Override
    public void createControl(Composite parent) {
        initializeDialogUnits(parent);
        // top level group
        Composite composite = new Composite(parent, SWT.NONE);
        composite.setFont(parent.getFont());
        composite.setLayout(new GridLayout(2, false));
        composite.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_FILL
                | GridData.HORIZONTAL_ALIGN_FILL));
        //entity name area
        Composite entityComp = new Composite(composite, SWT.NONE);
        GridData gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        gd.horizontalSpan = 2;
        entityComp.setLayoutData(gd);
        entityComp.setFont(composite.getFont());
        createEntityArea(entityComp);

        //template list area
        Composite listComp = new Composite(composite, SWT.NONE);
        gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        listComp.setLayoutData(gd);
        listComp.setFont(composite.getFont());
        createTemplateListArea(listComp);

        //column table area
        Composite tableComp = new Composite(composite, SWT.NONE);
        gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        tableComp.setLayoutData(gd);
        tableComp.setFont(composite.getFont());
        createColumnTableArea(tableComp);

        setPageComplete(validatePage());

        createListeners();

        // Show description on opening
        setErrorMessage(null);
        setMessage(null);
        setControl(composite);
    }

    private void createEntityArea(Composite composite) {
        composite.setLayout(new GridLayout(2, false));

        // Entity name label
        Label nameLabel = new Label(composite, SWT.NONE);
        nameLabel.setText("Entity name:");

        // Entity name text
        entityName = new Text(composite, SWT.BORDER);
        GridData gd = new GridData(SWT.FILL, SWT.CENTER, true, true);
//        gd.horizontalSpan = 1;
        entityName.setLayoutData(gd);
    }

    /**
     * @param composite
     */
    private void createTemplateListArea(Composite composite) {
        composite.setLayout(new GridLayout(1, false));

        // Select template label
        Label listLabel = new Label(composite, SWT.NONE);
        listLabel.setText("Select template:");
        GridData gd = new GridData(SWT.FILL, SWT.CENTER, true, false);
//        gd.horizontalSpan = 1;
        listLabel.setLayoutData(gd);

        // Template tree
        templateTree = new Tree(composite, SWT.BORDER);
        fillTemplateTree();

        gd = new GridData(SWT.FILL, SWT.FILL, true, true);
//        gd.horizontalSpan = 1;
//        gd.minimumHeight = 250;
        templateTree.setLayoutData(gd);
    }

    /**
     * @param composite
     * @param gd
     */
    private void createColumnTableArea(Composite composite) {
        composite.setLayout(new GridLayout(2, false));

        // Select columns label
        Label columnLabel = new Label(composite, SWT.NONE);
        columnLabel.setText("Select columns:");
        GridData gd = new GridData(SWT.FILL, SWT.CENTER, true, false);
        gd.horizontalSpan = 2;
        columnLabel.setLayoutData(gd);

        Composite tableComp = new Composite(composite, SWT.NONE);
        gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        tableComp.setLayoutData(gd);
        tableComp.setLayout(new GridLayout(2, false));

        // Column table
        columnTable = new Table(tableComp, SWT.CHECK | SWT.BORDER | SWT.V_SCROLL
                | SWT.H_SCROLL);
        TableColumn column1 = new TableColumn(columnTable, SWT.LEFT);
        column1.setText("Visible Column");
        column1.pack();
        columnTable.setHeaderVisible(false);
        gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        gd.horizontalSpan = 2;
        gd.minimumHeight = 250;
        columnTable.setLayoutData(gd);

        // Column count label
        columnCountLabel = new Label(tableComp, SWT.NONE);
        columnCountLabel.setText("Multi column count:");
        columnCountLabel.setEnabled(false);
        gd = new GridData(SWT.FILL, SWT.CENTER, false, false);
//        gd.horizontalSpan = 1;
        columnCountLabel.setLayoutData(gd);

        // Column count text
        columnCount = new Text(tableComp, SWT.BORDER);
        columnCount.setText("");
        columnCount.setEnabled(false);
        gd = new GridData(SWT.FILL, SWT.CENTER, true, false);
        columnCount.setLayoutData(gd);


        Composite buttonComp = new Composite(composite, SWT.NONE);
        buttonComp.setLayout(new GridLayout(1, false));
        gd = new GridData(SWT.FILL, SWT.FILL, true, true);
        buttonComp.setLayoutData(gd);

        // up button
        Button up = new Button(buttonComp, SWT.BORDER);
        up.setText("Up");
        gd = new GridData(SWT.FILL, SWT.CENTER, true, false);
        up.setLayoutData(gd);

        // down button
        Button down = new Button(buttonComp, SWT.BORDER);
        down.setText("Down");
        down.setLayoutData(gd);

        // restore to default value button
        Button restore = new Button(buttonComp, SWT.BORDER);
        restore.setText("Restore Default");
        gd.minimumWidth = 110;
        restore.setLayoutData(gd);

        // save template to new file button
        Button saveAs = new Button(buttonComp, SWT.BORDER);
        saveAs.setText("Save As");
        saveAs.setLayoutData(gd);
    }

    private void fillTemplateTree() {
        TestDataEntityTemplate root = templateCollection.getRoot();
        if (root != null) {
            Iterator<TestDataEntityTemplate> iter = root.getChildren().iterator();
            while (iter.hasNext()) {
                TestDataEntityTemplate category = iter.next();
                TreeItem child = new TreeItem(templateTree, SWT.NONE);
                child.setText(category.getName());
                child.setData(category);
                fillChild(child, category);
            }
        }
    }

    private void fillChild(TreeItem item, TestDataEntityTemplate category) {
        if (!category.hasChildren()) {
            return;
        }
        Iterator<TestDataEntityTemplate> iter = category.getChildren().iterator();
        while (iter.hasNext()) {
            TestDataEntityTemplate template = iter.next();
            TreeItem child = new TreeItem(item, SWT.NONE);
            child.setText(template.getName());
            child.setData(template);
            fillChild(child, template);
        }
    }

    private void updateColumnTable() {
        columnTable.removeAll();

        TreeItem[] selected = templateTree.getSelection();
        if (selected.length != 1
                || !(selected[0].getData() instanceof TestDataEntityTemplate)) {
            return;
        }
        TestDataEntityTemplate template = (TestDataEntityTemplate) selected[0].getData();
        if (template == null || template.hasChildren()) {
            return;
        }

        List<TestDataEntityTemplate.Column> attrs = template.getColumns();
        Iterator<TestDataEntityTemplate.Column> iter = attrs.iterator();
        while (iter.hasNext()) {
            TestDataEntityTemplate.Column column = iter.next();
            TableItem item = new TableItem(columnTable, SWT.NONE);
            String attr = column.getColumnName();
            boolean checked = column.isColumnSelected();
            item.setText(new String[] { attr });
            item.setChecked(checked);
//            if (column.isMultiple()) {
//                if (checked) {
//                    siteNumberLabel.setEnabled(true);
//                    siteNumber.setEnabled(true);
//                    siteNumber.setText(String.valueOf(column.getCount()));
//                } else {
                    columnCountLabel.setEnabled(false);
                    columnCount.setEnabled(false);
                    columnCount.setText("");
//                }
//            }
        }

        columnTable.setLinesVisible(true);
    }

    private void createListeners() {
        entityName.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                setPageComplete(validatePage());
            }
        });

        templateTree.addSelectionListener(new SelectionListener() {

            @Override
            public void widgetSelected(SelectionEvent e) {
                updateColumnTable();
                setPageComplete(validatePage());
            }

            @Override
            public void widgetDefaultSelected(SelectionEvent e) {
                updateColumnTable();
                setPageComplete(validatePage());
            }
        });

        columnTable.addListener(SWT.Selection, new Listener() {

            @Override
            public void handleEvent(Event event) {
                TreeItem[] selected = templateTree.getSelection();
                if (selected.length == 0 || selected[0].getData() == null) {
                    Util.LOG.logError("No template is selected.", null);
                    return;
                }
                TestDataEntityTemplate temp = (TestDataEntityTemplate) selected[0]
                        .getData();

                if (event.item instanceof TableItem) {
                    TableItem item = (TableItem) event.item;
                    TestDataEntityTemplate.Column column = temp.getColumnByName(item
                            .getText());
                    if (column == null) {
                        Util.LOG.logError(
                                "Column " + item.getText() + " does not exist.", null);
                        return;
                    }

                    // update template
                    if (event.detail == SWT.CHECK) {
                        if (column.isColumnSelected()) {
                            column.setColumnSelected(false);
                            column.setCount(1);
                        } else {
                            column.setColumnSelected(true);
                        }
                    }

                    // update column count text
                    if (column.isColumnSelected() && column.isMultiple()) {
                        columnCountLabel.setEnabled(true);
                        columnCount.setEnabled(true);
                        columnCount.setText(String.valueOf(column.getCount()));
                    } else {
                        columnCountLabel.setEnabled(false);
                        columnCount.setEnabled(false);
                        columnCount.setText("");
                    }
                }
            }
        });

        columnCount.addModifyListener(new ModifyListener() {

            @Override
            public void modifyText(ModifyEvent e) {
                if (!columnCount.getEnabled()) {
                    return;
                }
                TreeItem[] selectedInTree = templateTree.getSelection();
                if (selectedInTree.length == 0 || selectedInTree[0].getData() == null) {
                    Util.LOG.logError("No template is selected.", null);
                    return;
                }
                TestDataEntityTemplate temp = (TestDataEntityTemplate) selectedInTree[0]
                        .getData();

                TableItem[] selectedInTable = columnTable.getSelection();
                if (selectedInTable.length == 0) {
//                    Util.LOG.logError("No column is selected.", null);
                    return;
                }
                String columnName = selectedInTable[0].getText();

                TestDataEntityTemplate.Column column = temp
                        .getColumnByName(columnName);
                if (column == null) {
                    return;
                }
                try {
                    int number = Integer.parseInt(columnCount.getText());
                    column.setCount(number);
                } catch (NumberFormatException ex) {
                    Util.LOG.logError("count is not numeric.", ex);
                    column.setCount(1);
                }
            }
        });

    }

    /**
     * @return true if all values are correct
     */
    private boolean validatePage() {
        TreeItem[] selected = templateTree.getSelection();
        if (selected.length != 1
                || !(selected[0].getData() instanceof TestDataEntityTemplate)) {
            return false;
        }
        TestDataEntityTemplate template = (TestDataEntityTemplate) selected[0].getData();
        if (template == null || template.hasChildren()) {
            return false;
        }
        if (entityName.getText() == null || entityName.getText().length() == 0) {
            return false;
        }
        return true;
    }

    /**
     * @return true if create entity is succeed.
     */
    public boolean createEntity() {
        // get selected entity
        Iterator iter = selection.iterator();
        if (!iter.hasNext()) {
            Util.LOG.logError("No insert place is selected.", null);
            return false;
        }

        Object next = iter.next();
        if (!(next instanceof IUTDEntity)) {
            Util.LOG.logError("Selected item is not test data entity.", null);
            return false;
        }

        // get selected template
        TreeItem[] selected = templateTree.getSelection();
        if (selected.length == 0 || selected[0].getData() == null) {
            Util.LOG.logError("No template is selected.", null);
            return false;
        }

        TestDataEntityTemplate temp = (TestDataEntityTemplate) selected[0].getData();

        // created new entity next to the entity with the template
        IUTDEntity entity = InMemoryController.getInstance().createEntity(
                (IUTDEntity) next, entityName.getText(), temp);
        if (entity == null) {
            return false;
        }

        // a resource is created by UDA, sync it by refresh in eclipse workspace
        try {
            entity.getResource().refreshLocal(1, null);
        } catch (CoreException e) {
            // LOG.logError("TODO", e);
            return false;
        }

        // focus on the new entity
        Util.refreshExplorer();
        Util.focusOnItems(new Object[] { entity });

        // open the new entity in editor
        if (entity instanceof FileEntity) {
            ((FileEntity) entity).open();
        }
        return true;
    }
}
