/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.navigator.ILinkHelper;
import org.eclipse.ui.part.FileEditorInput;

import com.verigy.itee.gst.explorer.internal.FileEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.utils.GSTEditorInput;

/**
 * Link GSTEditorInput to FileEntity, and vice versa.
 *
 * @author leenshi
 *
 */
public class UTDLinkHelper implements ILinkHelper {

    @Override
    public IStructuredSelection findSelection(IEditorInput input) {
        if (input instanceof FileEditorInput) {
            IResource resource = ((FileEditorInput) input).getFile();
            List<IUTDEntity> nodes = InMemoryController.getInstance()
                    .findEntitiesByResource(resource);
            return new StructuredSelection(nodes);
        }
        return StructuredSelection.EMPTY;
    }

    @Override
    public void activateEditor(IWorkbenchPage page, IStructuredSelection selection) {
        if (selection == null || selection.isEmpty()) {
            return;
        }
        if (selection.getFirstElement() instanceof FileEntity) {
            FileEntity entity = (FileEntity) selection.getFirstElement();
            IEditorInput gstEditorInput = new GSTEditorInput(
                    (IFile) entity.getResource(), "", "", entity);
            IEditorPart editor = null;
            if ((editor = page.findEditor(gstEditorInput)) != null) {
                page.bringToTop(editor);
            }
        }
    }

}
