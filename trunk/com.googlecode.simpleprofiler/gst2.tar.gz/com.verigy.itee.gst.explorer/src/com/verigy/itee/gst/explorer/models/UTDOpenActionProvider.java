/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.navigator.CommonActionProvider;
import org.eclipse.ui.navigator.ICommonActionConstants;
import org.eclipse.ui.navigator.ICommonActionExtensionSite;
import org.eclipse.ui.navigator.ICommonMenuConstants;
import org.eclipse.ui.navigator.ICommonViewerSite;
import org.eclipse.ui.navigator.ICommonViewerWorkbenchSite;

import com.verigy.itee.gst.explorer.actions.OpenAction;

/**
 * Action Provider for test data entity's open action (double click on the entity)
 *
 * @author leenshi
 *
 */
public class UTDOpenActionProvider extends CommonActionProvider {
//    private static final String NEW_MENU_NAME = "common.new.menu";

    private Action openAction;

    private Action openMultiAction;

    // private Action bindAction;
    // private Action executeAction;
//    private WizardActionGroup newWizardActionGroup;
//
//    private boolean contribute = false;

    /**
     * Constructor
     */
    public UTDOpenActionProvider() {
        super();
    }

    @Override
    public void init(ICommonActionExtensionSite aSite) {
        ICommonViewerSite site = aSite.getViewSite();
        if (site instanceof ICommonViewerWorkbenchSite) {
            ICommonViewerWorkbenchSite workbenchSite = (ICommonViewerWorkbenchSite) site;
            openAction = new OpenAction(workbenchSite.getPage(),
                    workbenchSite.getSelectionProvider());
            openMultiAction = new OpenAction(workbenchSite.getPage(),
                    workbenchSite.getSelectionProvider(), true);
//            newWizardActionGroup = new WizardActionGroup(
//                    workbenchSite.getWorkbenchWindow(), PlatformUI.getWorkbench()
//                            .getNewWizardRegistry(), WizardActionGroup.TYPE_NEW,
//                    aSite.getContentService());
        }
//        contribute = true;
    }

    @Override
    public void fillActionBars(IActionBars actionBars) {
        if (openAction.isEnabled()) {
            actionBars.setGlobalActionHandler(ICommonActionConstants.OPEN, openAction);
        }
    }

    @Override
    public void fillContextMenu(IMenuManager menu) {
        if (openAction.isEnabled()) {
            menu.appendToGroup(ICommonMenuConstants.GROUP_OPEN, openAction);
            menu.appendToGroup(ICommonMenuConstants.GROUP_OPEN, openMultiAction);
        }
//        if (!contribute) {
//            return;
//        }
//
//        IMenuManager submenu = menu.findMenuUsingPath(NEW_MENU_NAME);
//        if (submenu == null) {
//            submenu = new MenuManager("New", NEW_MENU_NAME);
//            // fill the menu from the commonWizard contributions
//            newWizardActionGroup.setContext(getContext());
//            newWizardActionGroup.fillContextMenu(submenu);
//
//            // append the submenu after the GROUP_NEW group.
//            // menu.insertBefore(ICommonMenuConstants.GROUP_OPEN, submenu);
//            menu.appendToGroup(ICommonMenuConstants.GROUP_NEW, submenu);
//        }

    }

    @Override
    public void dispose() {
        super.dispose();
    }
}
