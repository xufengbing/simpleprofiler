/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import java.text.Collator;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;

import com.verigy.itee.gst.explorer.internal.FileEntity;
import com.verigy.itee.gst.explorer.internal.IUTDContainerEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;

/**
 * Define the sort of object in project explorer
 * @author leenshi
 *
 */
public class UTDViewerSorter extends ViewerSorter {

	/**
	 * Constructor
	 */
	public UTDViewerSorter() {
		// TODO Auto-generated constructor stub
	}

    /**
     * Constructor
     * @param collator the collator to use to sort strings
     */
	public UTDViewerSorter(Collator collator) {
		super(collator);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(Viewer viewer, Object e1, Object e2) {
	    // test data entity before resource
		if (e1 instanceof IResource && e2 instanceof IUTDEntity) {
			return 1;
		}

		if (e1 instanceof IUTDEntity && e2 instanceof IResource) {
			return -1;
		}

		// folder entity before file entity
		if (e1 instanceof FileEntity && e2 instanceof IUTDContainerEntity) {
            return 1;
        }

		if (e1 instanceof IUTDContainerEntity && e2 instanceof FileEntity) {
		    return -1;
		}

		return super.compare(viewer, e1, e2);
	}
}
