/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.markers;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.ListenerList;
import org.eclipse.swt.widgets.Display;

import xoc.svc.pcoll.ZProblemCollection;

import com.verigy.itee.core.CorePlugin;
import com.verigy.itee.gst.explorer.Activator;
import com.verigy.itee.gst.explorer.ate.UDAccessor;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author aloskuto
 */
public class ProblemManager implements IResourceChangeListener {

    /**
     * Visitors used to filter the element delta changes
     */
    private static class ProjectErrorVisitor implements IResourceDeltaVisitor {

        private final HashSet<IUTDEntity> fChangedElements;

        public ProjectErrorVisitor(HashSet<IUTDEntity> changedElements) {
            fChangedElements = changedElements;
        }

        @Override
        public boolean visit(IResourceDelta delta) {
            IResource res = delta.getResource();
            if (res instanceof IProject && delta.getKind() == IResourceDelta.CHANGED) {
                IProject project = (IProject)res;
                if (!project.isAccessible()) {
                    // only track open projects
                    return false;
                }
            }
            checkInvalidate(delta, res);
            return true;
        }

        private void checkInvalidate(IResourceDelta delta, IResource resource) {
            int kind = delta.getKind();
            if (kind == IResourceDelta.REMOVED || kind == IResourceDelta.ADDED
                    || (kind == IResourceDelta.CHANGED && isErrorDelta(delta))) {
                IUTDEntity entity = InMemoryController.getInstance().findEntityByResource(resource);
                if(entity == null){
                    return;
                }
                // invalidate the path and all parent paths
                fChangedElements.add(entity);
                while (entity != InMemoryController.getInstance().getRoot()) {
                    entity = (IUTDEntity)entity.getParent();
                    fChangedElements.add(entity);
                }
            }
        }

        private boolean isErrorDelta(IResourceDelta delta) {
            if ( (delta.getFlags() & IResourceDelta.MARKERS) != 0) {
                IMarkerDelta[] markerDeltas = delta.getMarkerDeltas();
                for (IMarkerDelta markerDelta : markerDeltas) {
                    if (markerDelta.isSubtypeOf(IMarker.PROBLEM)) {
                        int kind = markerDelta.getKind();
                        if (kind == IResourceDelta.ADDED || kind == IResourceDelta.REMOVED) {
                            return true;
                        }
                        int severity = markerDelta.getAttribute(IMarker.SEVERITY, -1);
                        int newSeverity = markerDelta.getMarker().getAttribute(IMarker.SEVERITY, -1);
                        if (newSeverity != severity) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }

    private static final String ATTR_NAME = "gst.name";


    private static ProblemManager singleton;


    private IMarkerFactory markerFactory;

    private final ListenerList fListeners;

    /**
     * @return the singleton
     */
    public static synchronized ProblemManager getInstance(){
        if(singleton == null){
            singleton = new ProblemManager();
        }
        return singleton;
    }

    /**
     */
    private ProblemManager() {
        super();
        markerFactory = new DefaultMarkerFactory();
        fListeners = new ListenerList();
    }

    /**
     * @param entity
     *            non null entity
     * @return non null set of GST markers known by Eclipse (might be out of sync with
     *         ATE)
     */
    public Set<IMarker> getWorkspaceProblems(IUTDEntity entity){
        Set<IMarker> markers = new HashSet<IMarker>();
        if(entity == null){
            return markers;
        }
        IMarker[] iMarkers;
        IResource resource = entity.getResource();
        if(resource == null){
            resource = CorePlugin.getDeviceProject();
        }
        try {
            iMarkers = resource.findMarkers(IMarkerFactory.MARKER_TYPE, true, IResource.DEPTH_ZERO);
        } catch (CoreException e) {
             Util.LOG.logError("Failed to get markers for " + resource, e);
             return markers;
        }
        for (IMarker iMarker : iMarkers) {
            if(belongsTo(iMarker, entity)){
                markers.add(iMarker);
            }
        }
        return markers;
    }

    /**
     * @param entity may be null. In this case simply updates ALL device problems
     */
    public void updateProblems(IUTDEntity entity) {
        clearWorkspaceProblems(entity);
        ZProblemCollection coll =
            UDAccessor.getInstance().getAteServerStub().getCurrentPublishedProblems();
        getMarkerFactory().createMarkers(coll);
    }

    /**
     * @param entity may be null. In this case simply removes ALL device problems
     */
    public void clearWorkspaceProblems(IUTDEntity entity) {
        IResource resource = entity == null? CorePlugin.getDeviceProject() : entity.getResource();
        if(resource == null){
            resource = CorePlugin.getDeviceProject();
        }
        int deep = resource instanceof IContainer ? IResource.DEPTH_INFINITE : IResource.DEPTH_ZERO;
        try {
            resource.deleteMarkers(IMarkerFactory.MARKER_TYPE, true, deep);
        } catch (CoreException e) {
             Util.LOG.logError("Failed to clear markers for " + entity, e);
        }
    }

    /**
     * @param iMarker non null
     * @param entity non null
     * @return true if the given marker belongs to the given entity
     */
    private boolean belongsTo(IMarker iMarker, IUTDEntity entity) {
        IResource resource = entity.getResource();
        if(resource != null) {
            return iMarker.getResource().equals(resource);
        }
        String name = entity.getName();
        String source = iMarker.getAttribute(ATTR_NAME, null);
        if(name.equals(source)){
            return true;
        }
        return false;
    }

    private IMarkerFactory getMarkerFactory(){
        return markerFactory;
    }

    /**
     * @param markerFactory non null
     */
    public void setMarkerFactory(IMarkerFactory markerFactory) {
        this.markerFactory = markerFactory;
    }

    /**
     * @param entity test data entity
     * @return markers on the entity
     */
    public IMarker[] findMarkers(IUTDEntity entity){
        if(entity == null){
            return new IMarker[0];
        }

        IResource resource = entity.getResource();
        if(resource == null || !resource.exists()){
            return new IMarker[0];
        }

        int deep = resource instanceof IContainer ? IResource.DEPTH_INFINITE : IResource.DEPTH_ZERO;

        try {
            return resource.findMarkers(IMarkerFactory.MARKER_TYPE, true, deep);
        } catch (CoreException e) {
            Util.LOG.logError("Failed to find markers for " + entity, e);
        }
        return new IMarker[0];
    }

    /**
     * @param listener problem marker changed listener
     */
    public void addListener(IProblemChangedListener listener){
        if(fListeners.isEmpty()){
            ResourcesPlugin.getWorkspace().addResourceChangeListener(this);
        }
        fListeners.add(listener);
    }

    /**
     * @param listener problem marker changed listener to be removed
     */
    public void removeListener(IProblemChangedListener listener){
        fListeners.remove(listener);
        if(fListeners.isEmpty()){
            ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
        }
    }

    @Override
    public void resourceChanged(IResourceChangeEvent event) {
        HashSet<IUTDEntity> changedElements = new HashSet<IUTDEntity>();

        try {
            IResourceDelta delta = event.getDelta();
            if (delta != null) {
                delta.accept(new ProjectErrorVisitor(changedElements));
            }
        } catch (CoreException e) {
            Util.LOG.logError(e.getMessage(), e);
        }

        if (!changedElements.isEmpty()) {
            IUTDEntity[] changes = changedElements.toArray(new IUTDEntity[changedElements.size()]);
            fireChanges(changes, true);
        }
    }

    private void fireChanges(final IUTDEntity[] changes, final boolean markerChanged) {
        Display display = Activator.getDefault().getWorkbench().getDisplay();
        if (display != null && !display.isDisposed()) {
            display.asyncExec(new Runnable() {

                @Override
                public void run() {
                    Object[] listeners = fListeners.getListeners();
                    for (Object listener : listeners) {
                        IProblemChangedListener curr = (IProblemChangedListener)listener;
                        curr.problemsChanged(changes, markerChanged);
                    }
                }
            });
        }
    }
}
