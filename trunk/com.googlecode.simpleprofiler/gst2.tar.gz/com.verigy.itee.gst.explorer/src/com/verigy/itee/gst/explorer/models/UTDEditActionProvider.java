/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbenchCommandConstants;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.navigator.CommonActionProvider;
import org.eclipse.ui.navigator.ICommonMenuConstants;
import org.eclipse.ui.navigator.ICommonViewerSite;
import org.eclipse.ui.navigator.ICommonViewerWorkbenchSite;

import com.verigy.itee.gst.explorer.actions.CopyAction;
import com.verigy.itee.gst.explorer.actions.DeleteAction;
import com.verigy.itee.gst.explorer.actions.PasteAction;

/**
 * Provide edit actions like copy, paste and delete.
 *
 * @author leenshi
 *
 */
public class UTDEditActionProvider extends CommonActionProvider {

    private Clipboard clipboard;

    private CopyAction copyAction;

    private PasteAction pasteAction;

    private DeleteAction deleteAction;

    /**
     * constructor
     */
    public UTDEditActionProvider() {
        super();
    }

    @Override
    public void init(org.eclipse.ui.navigator.ICommonActionExtensionSite aSite) {
        ICommonViewerSite site = aSite.getViewSite();
        if (site instanceof ICommonViewerWorkbenchSite) {
            ICommonViewerWorkbenchSite workbenchSite = (ICommonViewerWorkbenchSite) site;
            ISharedImages images = PlatformUI.getWorkbench().getSharedImages();
            clipboard = new Clipboard(workbenchSite.getShell().getDisplay());

            pasteAction = new PasteAction(clipboard);
            pasteAction.setDisabledImageDescriptor(images
                    .getImageDescriptor(ISharedImages.IMG_TOOL_PASTE_DISABLED));
            pasteAction.setImageDescriptor(images
                    .getImageDescriptor(ISharedImages.IMG_TOOL_PASTE));
            pasteAction.setActionDefinitionId(IWorkbenchCommandConstants.EDIT_PASTE);

            copyAction = new CopyAction(clipboard, pasteAction);
            copyAction.setDisabledImageDescriptor(images
                    .getImageDescriptor(ISharedImages.IMG_TOOL_COPY_DISABLED));
            copyAction.setImageDescriptor(images
                    .getImageDescriptor(ISharedImages.IMG_TOOL_COPY));
            copyAction.setActionDefinitionId(IWorkbenchCommandConstants.EDIT_COPY);

            deleteAction = new DeleteAction();
            deleteAction.setDisabledImageDescriptor(images
                    .getImageDescriptor(ISharedImages.IMG_TOOL_DELETE_DISABLED));
            deleteAction.setImageDescriptor(images
                    .getImageDescriptor(ISharedImages.IMG_TOOL_DELETE));
            deleteAction.setActionDefinitionId(IWorkbenchCommandConstants.EDIT_DELETE);
        }
    }

    @Override
    public void fillActionBars(IActionBars actionBars) {
        IStructuredSelection selection = (IStructuredSelection) getContext()
                .getSelection();

        copyAction.selectionChanged(selection);
        actionBars.setGlobalActionHandler(ActionFactory.COPY.getId(), copyAction);

        pasteAction.selectionChanged(selection);
        actionBars.setGlobalActionHandler(ActionFactory.PASTE.getId(), pasteAction);

        deleteAction.selectionChanged(selection);
        actionBars.setGlobalActionHandler(ActionFactory.DELETE.getId(), deleteAction);
    }

    @Override
    public void fillContextMenu(IMenuManager menu) {
        IStructuredSelection selection = (IStructuredSelection) getContext()
                .getSelection();

        copyAction.selectionChanged(selection);
        menu.appendToGroup(ICommonMenuConstants.GROUP_EDIT, copyAction);

        pasteAction.selectionChanged(selection);
        menu.appendToGroup(ICommonMenuConstants.GROUP_EDIT, pasteAction);

        deleteAction.selectionChanged(selection);
        menu.appendToGroup(ICommonMenuConstants.GROUP_EDIT, deleteAction);
    }

    @Override
    public void dispose() {
        // TODO Auto-generated method stub
        super.dispose();
    }

}
