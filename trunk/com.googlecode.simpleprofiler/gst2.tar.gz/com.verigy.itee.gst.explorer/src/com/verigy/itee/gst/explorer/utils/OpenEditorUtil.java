/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.utils;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IPersistableElement;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;

import com.verigy.itee.gst.explorer.ate.GenericNodeType;
import com.verigy.itee.gst.explorer.ate.IZTestDataNode;

/**
 * @author alanlin
 */
public class OpenEditorUtil {
    /**
     * Opens the GST editor which operates on in-memory TDE which has corresponding
     * physical file.
     * @param file the file
     * @param node UDA node
     * @return Returns the opened editor or null if error occurs.
     */
    public static IEditorPart openLoadedTDE(final IFile file, final IZTestDataNode node) {
        return openLoadedTDE(file, "", "", node, false);
    }

    /**
     * Opens the GST editor which operates on in-memory TDE which has corresponding
     * physical file.
     * @param file the file
     * @param type the TDE type
     * @param packageName test package name
     * @param node UDA node
     * @return Returns the opened editor or null if error occurs.
     */
    public static IEditorPart openLoadedTDE(final IFile file, final String type, final String packageName, final IZTestDataNode node, final boolean multi) {
        if (!checkFileAvailability(file)) {
            return null;
        }

        final Display display = PlatformUI.getWorkbench().getDisplay();
        final IEditorPart[] editPart = new IEditorPart[1];
        display.syncExec(new Runnable() {
            @Override
            public void run() {
                BusyIndicator.showWhile(display, new Runnable() {
                    @Override
                    public void run() {
                        IWorkbenchWindow workbenchWindow = PlatformUI
                                .getWorkbench().getActiveWorkbenchWindow();
                        if (null != workbenchWindow) {
                            IWorkbenchPage workbenchPage = workbenchWindow
                                    .getActivePage();
                            if (null != workbenchPage) {
                                try {
                                    IEditorInput input = new GSTEditorInput(file, type, packageName, node);

                                    if(multi){
                                        editPart[0] = workbenchPage
                                        .openEditor(input, ATE_EDITOR_MULTI_ID, true,
                                                MATCH_FLAGS);
                                    } else {
                                    editPart[0] = workbenchPage
                                            .openEditor(input, ATE_EDITOR_ID, true,
                                                    MATCH_FLAGS);
                                    }
                                    workbenchPage.activate(editPart[0]);
                                } catch (PartInitException e) {
                                    MessageDialog.openError(null, "Error", e
                                            .getLocalizedMessage());
                                }
                            }
                        }
                    }
                });
            }
        });

        return editPart[0];
    }

    public static void closeTDEEditors() {
        final Display display = PlatformUI.getWorkbench().getDisplay();
        display.asyncExec(new Runnable() {
            @Override
            public void run() {
                BusyIndicator.showWhile(display, new Runnable() {
                    @Override
                    public void run() {
                        IWorkbenchWindow workbenchWindow = PlatformUI.getWorkbench()
                                .getActiveWorkbenchWindow();
                        if (null != workbenchWindow) {
                            IWorkbenchPage workbenchPage = workbenchWindow
                                    .getActivePage();
                            if (null != workbenchPage) {
                                IEditorReference[] refs = workbenchPage
                                        .getEditorReferences();
                                List<IEditorReference> tdeEditorRefs = new ArrayList<IEditorReference>();
                                for (IEditorReference ref : refs) {
                                    if (ATE_EDITOR_ID.equals(ref.getId())|| ATE_EDITOR_MULTI_ID.equals(ref.getId())) {
                                        tdeEditorRefs.add(ref);
                                    }
                                }
                                workbenchPage.closeEditors(tdeEditorRefs
                                        .toArray(new IEditorReference[tdeEditorRefs
                                                .size()]), false);
                            }
                        }
                    }
                });
            }
        });
    }

    @Deprecated
	public static void openLoadedTDE(final String name) {
		final Display display = PlatformUI.getWorkbench().getDisplay();
		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				BusyIndicator.showWhile(display, new Runnable() {
					@Override
					public void run() {
						IWorkbenchWindow workbenchWindow = PlatformUI
								.getWorkbench().getActiveWorkbenchWindow();
						if (null != workbenchWindow) {
							IWorkbenchPage workbenchPage = workbenchWindow
									.getActivePage();
							if (null != workbenchPage) {
								try {
									IEditorInput input = new IEditorInput() {

										@Override
										public Object getAdapter(Class adapter) {
											return null;
										}

										@Override
										public String getToolTipText() {
											return "This is a fake editor input";
										}

										@Override
										public IPersistableElement getPersistable() {
											return null;
										}

										@Override
										public String getName() {
											return name;
										}

										@Override
										public ImageDescriptor getImageDescriptor() {
											return null;
										}

										@Override
										public boolean exists() {
											return true;
										}
									};

									IEditorPart graphicalEditor = workbenchPage
											.openEditor(input, ATE_EDITOR_ID, true,
													MATCH_FLAGS);
									workbenchPage.activate(graphicalEditor);
								} catch (PartInitException e) {
									MessageDialog.openError(null, "Error", e
											.getLocalizedMessage());
								}
							}
						}
					}
				});
			}
		});
	}

	/**
	 * Opens the file of the selected node according the new syntax(for detial
	 * information, please refer to tron demo device ex11). If the selected node
	 * is <code>null</code> or its type is not
	 * {@linkplain GenericNodeType#IMPORT}, a dialog will be popped up and no
	 * editor will be opened.
	 * <p>
	 * The import element has syntax as <import>../abc/def</import>. It always
	 * uses the relative path against to currently editing file. The example
	 * implies opening a specsheet file locates in <font color=red>abc</font>
	 * folder of the parent folder of currently editing file and named <font
	 * color=red>def.xml</font>.
	 *
	 * @param selectedNode
	 *            the selected node with type IMPORT.
	 */
	/*
	public static void openFileOfSelectedNode(final IGenericNode selectedNode) {
		final Display display = PlatformUI.getWorkbench().getDisplay();
		display.asyncExec(new Runnable() {
			@Override
			public void run() {
				BusyIndicator.showWhile(display, new Runnable() {
					@Override
					public void run() {
						if ((selectedNode != null)
								&& (GenericNodeType.IMPORT.equals(selectedNode
										.getNodeType()))) {
							String relativePath = selectedNode.getValue();

							if (!relativePath.endsWith(".xml")) {
								relativePath += ".xml";
							}

							IEditorPart editor = PlatformUI.getWorkbench()
									.getActiveWorkbenchWindow().getActivePage()
									.getActiveEditor();

							if (editor != null) {
								IEditorInput editorInput = editor
										.getEditorInput();
								if (editorInput instanceof IFileEditorInput) {
									IPath startFrom = ((IFileEditorInput) editorInput)
											.getFile().getLocation();

									IPath newPath = startFrom
											.removeLastSegments(1).append(
													relativePath);

									openEditorByPath(newPath);
								}
							}
						}
					}
				});
			}
		});
	}
*/

	/**
	 * Opens the file of the selected node according the original syntax(for
	 * detail information, please refer to tron demo device ex3). If the
	 * selected node is <code>null</code> or its type is not
	 * {@linkplain GenericNodeType#IMPORT}, a dialog will be popped up and no
	 * editor will be opened.
	 * <p>
	 * The import element has syntax as <import>level.abc</import>. The first
	 * segment indicates the setup type of the import test data entity and it
	 * also specifies the directory against to currently device directory. The
	 * example implies opening a specsheet file locates in <font
	 * color=red>/current device directory/level/abc.xml</font> file.
	 *
	 * @param selectedNode
	 *            the selected node with type IMPORT.
	 */
/*
	public static void openFileOfSelectedNode1(IGenericNode selectedNode) {
		if ((selectedNode != null)
				&& (GenericNodeType.IMPORT.equals(selectedNode.getNodeType()))) {
			String filePath = selectedNode.getValue();
			if (filePath != null && !filePath.isEmpty()) {
				IPath devicePath = CorePlugin.getCurrentDevicePath();
				StringBuilder sbfp = new StringBuilder(devicePath.toOSString());

				String[] segments = filePath.split("[.]");

				if (segments.length == 0) {
					MessageDialog.openError(null, "Error",
							"Could not find the test date element!");
				} else if (segments.length == 1) {
					sbfp.append("/timing/");
					sbfp.append(filePath);
				} else {
					sbfp.append("/");
					sbfp.append(segments[0]);
					sbfp.append("/");
					for (int i = 1; i < segments.length; i++) {
						sbfp.append(segments[i]);

						if (i != segments.length - 1) {
							sbfp.append('.');
						}
					}
				}

				openEditorByPath(new Path(sbfp.toString()));
			}
		}
	}
*/
    @Deprecated
	public static IEditorPart openEditorByPath(IResource resource) {
		if (resource != null && resource instanceof IFile) {
			IFile file = (IFile) resource;
			if (!checkFileAvailability(file)) {
				return null;
			}

			IEditorInput input = new FileEditorInput(file);

			IWorkbenchWindow workbenchWindow = PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow();
			if (null != workbenchWindow) {
				IWorkbenchPage workbenchPage = workbenchWindow.getActivePage();
				if (null != workbenchPage) {
					try {
						IEditorPart graphicalEditor = workbenchPage.openEditor(
								input, EDITOR_ID, true, MATCH_FLAGS);
						workbenchPage.activate(graphicalEditor);
						return graphicalEditor;
					} catch (PartInitException e) {
						MessageDialog.openError(null, "Error", e
								.getLocalizedMessage());
					}
				}
			}

		} else {
			MessageDialog.openError(null, "Open",
					"Could not find file \"" + resource.getLocation() + "\"!");
		}
		return null;
	}

	/**
	 * Checks the file's available. If the file does not exist or it's not
	 * accessible, a message dialog will pop up to prompt user and returns
	 * <code>false</code>. If the file is normal, returns <code>true</code>.
	 * @param file the {@linkplain IFile} which will be checked.
	 */
	public static boolean checkFileAvailability(IFile file) {
		if (!file.exists() || !file.isAccessible()) {
			StringBuilder sb = new StringBuilder("Could not able open file \"");
			sb.append(file.getLocation().toOSString());
			sb.append("\"!\n");
			sb.append("File does not exist or not accessible!");
			MessageDialog.openError(null, "Error", sb.toString());
			return false;
		}

		return true;
	}

	private static final int MATCH_FLAGS = IWorkbenchPage.MATCH_INPUT
			| IWorkbenchPage.MATCH_ID;
	private static final String EDITOR_ID = "com.verigy.itee.gst.editor.ktablebasededitor";

	private static final String ATE_EDITOR_ID = "com.verigy.itee.gst.editor.editors.ATEKTable";

	private static final String ATE_EDITOR_MULTI_ID = "com.verigy.itee.gst.editor.editors.ATEKTableMulti";
}
