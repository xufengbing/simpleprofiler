/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.TestDataNode;
import com.verigy.itee.gst.explorer.ate.UDAccessor;

/**
 * Folder Entity
 *
 * @author leenshi
 *
 */
public class FolderEntity extends TestDataNode implements IUTDContainerEntity {

    private IResource entityResource;

//    private final IUTDContainerEntity parentEntity;

    private boolean bindStatus = true;

//    private final List<IUTDEntity> entityList = new ArrayList<IUTDEntity>();

    /**
     * @param parent parent entity
     * @param address node address
     * @param name node name
     * @param resource resource in file system
     */
    public FolderEntity(final IUTDContainerEntity parent, int address, String name, IResource resource) {
        super(parent, address, name);
        entityResource = resource;
    }

//    /**
//     * @param parent parent entity
//     * @param address node address
//     */
//    public FolderEntity(final IUTDContainerEntity parent, int address) {
//        super(parent, address);
//    }
//
//    /**
//     * @param parent
//     *            Parent entity
//     * @param resource
//     *            Relevant resource in file system
//     */
//    public FolderEntity(IUTDContainerEntity parent, IResource resource) {
//        parentEntity = parent;
//        entityResource = resource;
//    }

    @Override
    public IResource getResource() {
        return entityResource;
    }

    @Override
    public void setResource(IResource resource) {
        entityResource = resource;

    }

//    @Override
//    public String getName() {
//        return entityResource.getName();
//    }

    @Override
    public void addChild(IUTDEntity entity) {
        children.add(entity);
    }

    @Override
    public boolean getBindStatus() {
        return bindStatus;
    }

    @Override
    public void setBindStatus(boolean status) {
        bindStatus = status;
    }

    @Override
    public void removeChild(IUTDEntity entity) {
        children.remove(entity);
    }

    @Override
    public String getType() {
        return "FOLDER";
    }

    @Override
    public String getPackageName() {
//        IUTDEntity root = InMemoryController.getInstance().getRoot();
        String pathStr = getResource().getLocation().toOSString();
//        String cut = root.getResource().getFullPath().toString();
//        int index = pathStr.indexOf(cut);
//        // if this folder is not under program folder, using the default package
//        if (cut.length() >= pathStr.length() || index != 0) {
//            return "";
//        }
//        String result = pathStr.substring(cut.length());
//        if (result.startsWith("/")) {
//            if (result.length() == 1) {
//                return "";
//            }
//            result = result.substring(1);
//        }
        return pathStr;//result;
    }

//    @Override
//    public IUTDEntity getChildByName(String name) {
//        if (name == null) {
//            return null;
//        }
//        Iterator<IZTestDataNode> iter = children.iterator();
//        while (iter.hasNext()) {
//            IZTestDataNode entity = iter.next();
//            if (entity.getName().equals(name)) {
//                return (IUTDEntity)entity;
//            }
//        }
//        return null;
//    }

    @Override
    public List<IZTestDataNode> getChildren() {
        if(null == children) {
            children = new ArrayList<IZTestDataNode>();
            UDAccessor.getInstance().createTDETree(this);
        }
        return children;
    }

    @Override
    public String getMetaData() {
        return "";
    }

    @Override
    public void setMetaData(String metaData) {
        // do nothing
    }

    @Override
    public void setParent(IZTestDataNode parentNode) {
        parent = parentNode;
    }
}
