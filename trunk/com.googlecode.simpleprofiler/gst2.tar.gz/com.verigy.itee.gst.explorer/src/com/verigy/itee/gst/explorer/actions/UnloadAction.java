/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.actions.ActionDelegate;

import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.InMemoryController;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * Unload Test Data Entity action. Currently, only Test Program can be unloaded.
 * @author leenshi
 *
 */
public class UnloadAction extends ActionDelegate {

	private IUTDEntity data;

	private IStructuredSelection selection = StructuredSelection.EMPTY;

	@Override
	public void selectionChanged(IAction action, ISelection sel) {
		if (sel instanceof IStructuredSelection) {
			selection = (IStructuredSelection) sel;
			if (!selection.isEmpty() && selection.size() == 1
					&& selection.getFirstElement() instanceof IUTDEntity) {
				data = ((IUTDEntity) selection.getFirstElement());
			}
		} else {
			selection = StructuredSelection.EMPTY;
			data = null;
		}
	}

	@Override
	public void run(IAction action) {
		if (data == null) {
			return;
		}
		InMemoryController.getInstance().unload();
		Util.refreshExplorer();
	}

}
