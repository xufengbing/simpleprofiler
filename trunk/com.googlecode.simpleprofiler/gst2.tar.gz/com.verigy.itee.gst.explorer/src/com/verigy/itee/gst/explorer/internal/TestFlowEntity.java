/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import java.util.ArrayList;
import java.util.List;

/**
 * Test Flow Entity
 * @author leenshi
 *
 */
public class TestFlowEntity extends FileEntity {
    ;
	private final List<TestSuiteLinkEntity> testSuiteList = new ArrayList<TestSuiteLinkEntity>();

	/**
     * @param parent parent entity
     * @param address node address
     */
	public TestFlowEntity(IUTDContainerEntity parent, int address) {
		super(parent, address);
	}

	/**
	 * @param entity test suite entity
	 */
	public void addTestSuite(IUTDEntity entity) {
		if (entity instanceof TestSuiteLinkEntity) {
			testSuiteList.add((TestSuiteLinkEntity) entity);
		} else if (entity instanceof TestSuiteEntity) {
			TestSuiteLinkEntity link = new TestSuiteLinkEntity(this,
					(TestSuiteEntity) entity);
			testSuiteList.add(link);
		}
	}

	/**
	 * @param entity test suite entity
	 */
	public void removeTestSuite(IUTDEntity entity) {
		if (entity instanceof TestSuiteLinkEntity) {
			testSuiteList.remove(entity);
		}
	}

    @Override
    public String getType() {
        return "FLOW";
    }
}
