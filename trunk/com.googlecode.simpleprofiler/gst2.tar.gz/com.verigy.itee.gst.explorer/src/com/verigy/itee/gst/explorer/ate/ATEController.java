/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.ate;


/**
 * ATE layer access
 *
 * @author leenshi
 *
 */
public class ATEController {
//
//    /**
//     * @param resource
//     *            Test Program folder
//     * @return true if loading Test Program is succeed
//     */
//    public static boolean load(IResource resource) {
//        // unload previous test program
//        if (!unload()) {
//            return false;
//        }
//
//        if (resource instanceof IFolder) {
//            IFolder programFolder = (IFolder) resource;
//            IResource programFile = programFolder.findMember(Util.TEST_PROGRAM_FILE_NAME);
//            // if (programFile == null || !(programFile instanceof IFile)) {
//            // return null;
//            // }
//
//            return loadTestProgram(programFolder, (IFile) programFile);
//        }
//
//        Util.LOG.logError("Not Test Program Folder", null);
//        return false;
//    }
//
//    private static boolean loadSpec(IUTDContainerEntity parent, IResource resource) {
//        if (!loadTDE(parent.getPackageName(), resource)) {
//            return false;
//        }
//
//        SpecEntity specEntity = new SpecEntity(parent, resource);
//        parent.addChild(specEntity);
//        return true;
//    }
//
//    private static boolean loadTDE(String packageName, IResource resource) {
//        // load entity from ATE
//        IPath path = resource.getLocation();
//        IPath dir = path.removeLastSegments(1);
//
//        try {
//            UDAccessor.getInstance().loadTDE(packageName, dir.toOSString(),
//                    resource.getName());
//        } catch (CoreException93k e) {
//            Util.LOG.logError("Failed to load Test Data Entity.", e);
//            // return false;
//        } catch (Exception e) {
//            Util.LOG.logError("Failed to load Test Data Entity.", e);
//            // return false;
//        }
//        return true;
//    }
//
//    private static boolean loadConfig(IUTDContainerEntity parent, IResource resource) {
//        if (!loadTDE(parent.getPackageName(), resource)) {
//            return false;
//        }
//
//        ConfigEntity configEntity = new ConfigEntity(parent, resource);
//        parent.addChild(configEntity);
//        return true;
//    }
//
//    private static boolean loadMeasurementRun(IUTDContainerEntity parent,
//            IResource resource) {
//        if (!loadTDE(parent.getPackageName(), resource)) {
//            return false;
//        }
//
//        MeasurementRunEntity mrunEntity = new MeasurementRunEntity(parent, resource);
//        parent.addChild(mrunEntity);
//        return true;
//    }
//
//    private static boolean loadWaveTable(IUTDContainerEntity parent, IResource resource) {
//        if (!loadTDE(parent.getPackageName(), resource)) {
//            return false;
//        }
//
//        WaveTableEntity wavetableEntity = new WaveTableEntity(parent, resource);
//        parent.addChild(wavetableEntity);
//        return true;
//    }
//
//    private static boolean loadPattern(IUTDContainerEntity parent, IResource resource) {
//        PatternEntity patternEntity = new PatternEntity(parent, resource);
//        parent.addChild(patternEntity);
//        return true;
//    }
//
//    private static boolean loadTestSuite(IUTDContainerEntity parent, IResource resource) {
//        if (!loadTDE(parent.getPackageName(), resource)) {
//            return false;
//        }
//
//        TestSuiteEntity suiteEntity = new TestSuiteEntity(parent, resource);
//        parent.addChild(suiteEntity);
//        return true;
//    }
//
//    private static boolean loadTestDataLink(IUTDContainerEntity parent, IResource resource) {
//        Node fileContent = Util.readXmlFile((IFile) resource);
//        String name = ((Element) fileContent).getElementsByTagName("Name").item(0)
//                .getFirstChild().getNodeValue();
//        String pathStr = ((Element) fileContent).getElementsByTagName("Path").item(0)
//                .getFirstChild().getNodeValue();
//
//        IPath path = new Path(pathStr);
//        IProject currentProject = InMemoryController.getInstance().getCurrentProject();
//        if (currentProject == null) {
//            Util.LOG.logError("Linked folder fail, no corrent device project.", null);
//            return false;
//        }
//        IResource linkResource = currentProject.findMember(path);
//
//        // direct item in current device project
//        if (linkResource == null || !(linkResource instanceof IFolder)) {
//            Util.LOG.logError("Linked folder " + pathStr + " does not exist or not folder.",
//                    null);
//            return false;
//        }
//
//        TestDataLinkEntity linkEntity = new TestDataLinkEntity(parent, name, linkResource);
//        parent.addChild(linkEntity);
//        return loadContentsInFolder(linkEntity, linkResource);
//    }
//
//    private static boolean loadTestFlow(IUTDContainerEntity parent, IResource resource) {
//        TestFlowEntity flowEntity = new TestFlowEntity(parent, resource);
//        parent.addChild(flowEntity);
//        // if (all) {
//        // Node node = Util.readXmlFile((IFile) resource);
//        // NodeList list = ((Element) node).getElementsByTagName("Node");
//        // for (int i = 0; i < list.getLength(); i++) {
//        // Element elem = (Element) list.item(i);
//        // String type = elem.getElementsByTagName("Type").item(0)
//        // .getFirstChild().getNodeValue();
//        // if (Util.TEST_SUITE_NODE.equals(type)) {
//        // String pathStr = elem.getElementsByTagName("Path").item(0)
//        // .getFirstChild().getNodeValue();
//        // IResource res = resource.getProject().findMember(pathStr);
//        // TestSuiteEntity suite = loadTestSuite(res);
//        // flowEntity.addChild(suite);
//        // }
//        // }
//        // }
//        return true;
//    }
//
//    private static boolean isTestFlow(IResource file) {
//        if (file.exists() && Util.TEST_FLOW_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isTestSuite(IResource file) {
//        if (file.exists() && Util.TEST_SUITE_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isSpec(IResource file) {
//        if (file.exists() && Util.SPEC_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isConfig(IResource file) {
//        if (file.exists() && Util.CONFIG_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isMeasurementRun(IResource file) {
//        if (file.exists() && Util.MESUREMENT_RUN_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isPattern(IResource file) {
//        if (file.exists() && Util.PATTERN_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isTestDataLink(IResource file) {
//        if (file.exists() && Util.TEST_DATE_LINK_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean isWaveTable(IResource file) {
//        if (file.exists() && Util.WAVE_TABLE_NODE.equals(file.getFileExtension())) {
//            return true;
//        }
//        return false;
//    }
//
//    private static boolean loadTestProgram(IFolder programFolder, IFile programFile) {
//        TestProgramEntity entity = new TestProgramEntity(programFolder);
//        InMemoryController.getInstance().setRoot(entity);
//        return loadContentsInFolder(entity, programFolder);
//    }
//
//    private static boolean loadFolderTypeEntity(IUTDContainerEntity parent,
//            IFolder resource) {
//        FolderEntity folder = new FolderEntity(parent, resource);
//        parent.addChild(folder);
//        return loadContentsInFolder(folder, resource);
//    }
//
//    private static boolean loadContentsInFolder(IUTDContainerEntity entity,
//            IResource resource) {
//        if (!(resource instanceof IFolder)) {
//            return false;
//        }
//
//        boolean result = true;
//        try {
//            IResource[] childern = ((IFolder) resource).members();
//            for (int i = 0; i < childern.length; i++) {
//                if (!result) {
//                    return result;
//                }
//
//                if (childern[i] instanceof IFolder) {
//                    result = loadFolderTypeEntity(entity, (IFolder) childern[i]);
//                } else if (childern[i] instanceof IFile) {
//                    result = loadFileTypeEntity(entity, (IFile) childern[i]);
//                }
//            }
//        } catch (CoreException e) {
//            Util.LOG.logError("Failed to load contents in folder " + resource.getName(), e);
//            result = false;
//        }
//        return result;
//    }
//
//    /**
//     * @param parentEntity
//     *            parent entity
//     * @param file
//     *            resource file
//     * @return true if load test data entity is succeed
//     */
//    public static boolean loadFileTypeEntity(IUTDContainerEntity parentEntity, IFile file) {
//        if (isSpec(file)) {
//            return loadSpec(parentEntity, file);
//        } else if (isConfig(file)) {
//            return loadConfig(parentEntity, file);
//        } else if (isMeasurementRun(file)) {
//            return loadMeasurementRun(parentEntity, file);
//        } else if (isTestSuite(file)) {
//            return loadTestSuite(parentEntity, file);
//        } else if (isTestDataLink(file)) {
//            return loadTestDataLink(parentEntity, file);
//        }
//
//        // fake accesses
//        if (isTestFlow(file)) {
//            return loadTestFlow(parentEntity, file);
//        } else if (isPattern(file)) {
//            return loadPattern(parentEntity, file);
//        } else if (isWaveTable(file)) {
//            return loadWaveTable(parentEntity, file);
//        }
//
//        // since there are more and more type come, as this stage we return
//        // true always for unknown types.
//        Util.LOG.logWarning("The type of " + file.getName() + " is unknown.", null);
//        return true;
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     * @return true if the entity content can be shown in editor
//     */
//    public static boolean isOpenable(IUTDEntity entity) {
//        if (entity instanceof FolderEntity) {
//            return false;
//        }
//        return true;
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     * @return editor part
//     */
//    public static IEditorPart open(IUTDEntity entity) {
//        if (!isOpenable(entity)) {
//            return null;
//        }
//
//        if (entity instanceof SpecEntity || entity instanceof ConfigEntity) {
//            IResource resource = entity.getResource();
//            if (resource != null && resource instanceof IFile) {
//                // fake load for format
//                if (hasFormat((IFile) resource)) {
//                    return OpenEditorUtil.openEditorByPath(resource);
//                }
//                // end of load file with format
//
//                String packageName = "";
//                Object parent = entity.getParent();
//                if (parent instanceof IUTDContainerEntity) {
//                    packageName = ((IUTDContainerEntity) parent).getPackageName();
//                }
//                return OpenEditorUtil.openLoadedTDE((IFile) resource, entity.getType(),
//                        packageName);
//            }
//            return null;
//        }
//
//        // fake load
//        IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow()
//                .getActivePage();
//
//        IFile file = (IFile) entity.getResource();
//        FileEditorInput input = new FileEditorInput(file);
//        try {
//            return page.openEditor(input, "org.eclipse.ui.DefaultTextEditor");
//        } catch (PartInitException e) {
//            Util.LOG.logError("Failed to open " + entity.getName(), e);
//        }
//
//        return null;
//    }
//
//    private static boolean hasFormat(IFile resource) {
//        Node rootElement = Util.readXmlFile(resource);
//        if (null != rootElement && rootElement.hasAttributes()) {
//            if (null == rootElement.getAttributes().getNamedItem("format")) {
//                return false;
//            }
//            return true;
//        }
//        return false;
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     * @return true if the entity can be builded
//     */
//    public static boolean isBindable(IUTDEntity entity) {
//        return isExecutable(entity);
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     */
//    public static void bind(IUTDEntity entity) {
//        String packageName = "";
//        Object parent = entity.getParent();
//        if (parent instanceof IUTDContainerEntity) {
//            packageName = ((IUTDContainerEntity)parent).getPackageName();
//        }
//
//        // fake for executing suite
//        if (entity instanceof TestSuiteEntity) {
//            UDAccessor.getInstance().flushTestSuite(entity.getName(),
//                    packageName);
//        }
//
//        // Call AteServerStub to fake a bind. Hand over the logical name of
//        // the TED to bind and the resource name. In the Haussmann target
//        // architecture, the TestDataContoller will probably maintain the
//        // mapping between logical TDE name and the corresponding resource,
//        // and bind (or build) will probably a method to of the
//        // Measurement Entity TDE.
//        if (entity instanceof SpecEntity) {
//            String resource = entity.getResource().getLocation().toString();
//            boolean success = UDAccessor.getInstance().getAteServerStub()
//                    .bind(entity.getName(), resource, packageName);
//            Set<IMarker> problems = ProblemManager.getInstance().getWorkspaceProblems(entity);
//            if (!problems.isEmpty()) {
//                entity.setBindStatus(success);
//            }
//        }
//
//        Object[] objs = entity.getChildren();
//        if (objs == null || !(objs instanceof IUTDEntity[])) {
//            return;
//        }
//        IUTDEntity[] chidren = (IUTDEntity[]) objs;
//        for (int i = 0; i < chidren.length; i++) {
//            bind(chidren[i]);
//            if (!chidren[i].getBindStatus() && entity.getBindStatus()) {
//                entity.setBindStatus(false);
//            }
//        }
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     */
//    public static void execute(IUTDEntity entity) {
//        if (!(entity instanceof TestProgramEntity) && !(entity instanceof TestFlowEntity)
//                && !(entity instanceof TestSuiteEntity)) {
//            return;
//        }
//
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     * @return true if the entity can be executed
//     */
//    public static boolean isExecutable(IUTDEntity entity) {
//        if (!(entity instanceof TestProgramEntity) && !(entity instanceof TestFlowEntity)
//                && !(entity instanceof TestSuiteEntity)) {
//            return false;
//        }
//        return true;
//    }
//
//    /**
//     * @return true if unloading is succeed
//     */
//    public static boolean unload() {
//        // close opened editors
//        OpenEditorUtil.closeTDEEditors();
//
//        // remove entities from ATE
//        UDAccessor.getInstance().unloadAll();
//
//        // clear root
//        InMemoryController.getInstance().setRoot(null);
//        return true;
//    }
//
//    /**
//     * @param entity
//     *            Test Data Entity
//     */
//    public static void save(IUTDEntity entity) {
//        TestProgramEntity root = InMemoryController.getInstance().getRoot();
//        saveEntity(root);
//    }
//
//    private static void saveEntity(IUTDEntity entity) {
//        if (entity.getResource() == null) {
//            return;
//        }
//        if (entity.getResource() instanceof IFolder) {
//            final IFolder folder = (IFolder) entity.getResource();
//            if (!folder.exists()) {
//                try {
//                    folder.create(false, true, null);// monitor);
//                } catch (CoreException e) {
//                    Util.LOG.logError("Failed to create folder " + entity.getName(), e);
//                }
//            }
//            IUTDEntity[] children = (IUTDEntity[]) entity.getChildren();
//            for (IUTDEntity child : children) {
//                saveEntity(child);
//            }
//
//        } else if (entity.getResource() instanceof IFile) {
//            final IFile file = (IFile) entity.getResource();
//            if (!file.exists()) {
//                try {
//                    byte[] content = "test".getBytes();
//                    InputStream source = new ByteArrayInputStream(content);
//                    file.create(source, false, null);// monitor);
//                } catch (CoreException e) {
//                    Util.LOG.logError("Failed to create file " + entity.getName(), e);
//                }
//            }
//        }
//    }
//
//    /*
//     * fake code for building, call in the beginning of loadTestProgram()
//     */
//    private boolean runFWBeforeLoad() {
//        try {
//            /*
//             * T("*RST SWR")
//             */
//            IFwRequest query = CorePlugin.createRequest(IFwRequest.class);
//            query.append(new FWCommand("*RST").setEnumAt("SWR", 0));
//            CorePlugin.execute(query, null);
//        } catch (CoreException93k e) {
//            Util.LOG.logError("FW Error", e);
//            return false;
//        }
//        return true;
//    }
//
//    /*
//     * fake code for binding
//     */
//    private boolean bindWithFW(IUTDEntity entity) {
//        try {
//            /*
//             * T("DFPN #{$stdChnls[0].channelNo},\"1\",(CP)")
//             * T("DFPN #{$stdChnls[1].channelNo},\"2\",(mode)")
//             * T("DFPN #{$stdChnls[2].channelNo},\"3\",(ser_in)")
//             * T("DFPN #{$stdChnls[3].channelNo},\"4\",(_MR)")
//             * T("DFPN #{$stdChnls[4].channelNo},\"5\",(ser_out)")
//             * T("DFPN #{$stdChnls[5].channelNo},\"6\",(io_pins)") T("CONF IO,F160,(@)")
//             * T("DFPT (CP,mode,ser_in),(P1)") T("DFPT (_MR,ser_out,io_pins),(P2)")
//             */
//
//            IFwRequest query = CorePlugin.createRequest(IFwRequest.class);
//            query.append(new FWCommand("DFPN").setPinListAt("10101", 0)
//                    .setStringAt("1", 1).setPinListAt("CP", 2));
//            query.append(new FWCommand("DFPN").setPinListAt("10102", 0)
//                    .setStringAt("2", 1).setPinListAt("mode", 2));
//            query.append(new FWCommand("DFPN").setPinListAt("10103", 0)
//                    .setStringAt("3", 1).setPinListAt("ser_in", 2));
//            query.append(new FWCommand("DFPN").setPinListAt("10104", 0)
//                    .setStringAt("4", 1).setPinListAt("_MR", 2));
//            query.append(new FWCommand("DFPN").setPinListAt("10105", 0)
//                    .setStringAt("5", 1).setPinListAt("ser_out", 2));
//            query.append(new FWCommand("DFPN").setPinListAt("10106", 0)
//                    .setStringAt("6", 1).setPinListAt("io_pins", 2));
//            query.append(new FWCommand("CONF").setEnumAt("IO", 0).setEnumAt("F160", 1)
//                    .setPinListAt(FWCommand.ALL, 2));
//            query.append(new FWCommand("DFPT").setPinListAt(
//                    new String[] { "CP", "ser_in" }, 0).setPinListAt("P1", 1));
//            query.append(new FWCommand("DFPT").setPinListAt(
//                    new String[] { "_MR", "ser_out", "io_pins" }, 0)
//                    .setPinListAt("P2", 1));
//            CorePlugin.execute(query, null);
//
//            UDAccessor.getInstance().flushTestSuite(entity.getName(),
//                    ((IUTDContainerEntity) entity.getParent()).getPackageName());
//
//            /* T("SPRM 101,1,,") */
//            query = CorePlugin.createRequest(IFwRequest.class);
//            query.append(new FWCommand("SPRM").setIntAt(101, 0).setIntAt(1, 1)
//                    .setOptionalAt(2).setOptionalAt(3));
//            CorePlugin.execute(query, null);
//        } catch (CoreException93k e) {
//            Util.LOG.logError("FW Error", e);
//            return false;
//        }
//        return true;
//    }
//
//    /*
//     * fake code for building
//     */
//    private boolean buildwithRuby() {
//        try {
//            String key = "user.dir";
//            String oldPWD = System.getProperty(key);
//            Util.LOG.logDebug("current pwd: " + oldPWD, null);
//            System.setProperty(key,
//                    "/opt/93000/src/fw/components/fw_eqm_accessor/TEST.hp93000/non_scalable/xlator");
//            Runtime.getRuntime()
//                    .exec("execTestSuite.rb",
//                            null,
//                            new File(
//                                    "/opt/93000/src/fw/components/fw_eqm_accessor/TEST.hp93000/non_scalable/xlator"));
//            System.setProperty(key, oldPWD);
//        } catch (IOException e) {
//            Util.LOG.logError("Failed to run Ruby.", e);
//            return false;
//        }
//        return true;
//    }
}
