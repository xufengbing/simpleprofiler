package com.verigy.itee.gst.explorer.ate;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;

import xoc.ate.cor.td.ZTestDataController;
import xoc.ate.cor.td.ZTestPackage;
import xoc.ate.cor.td2.ZExecutionEntity;
import xoc.ate.cor.uda.ZAttribute;
import xoc.ate.cor.uda.ZTestDataNode;
import xoc.ate.cor.uda.ZTestDataTree;
import xoc.ate.cor.uda.ZTestDataTreeFocus;
import xoc.ate.cor.uda.ZTestProgram;
import xoc.ate.cor.uda.ZUda;
import xoc.ate.cor.uda.ZUvarAttributeList;
import xoc.ate.cor.uda.ZUvarAttributeListSeq;
import xoc.ate.cor.uda.ZUvarLong;
import xoc.ate.cor.uda.ZUvarLongSeq;
import xoc.ate.cor.uda.ZUvarString;
import xoc.ate.cor.uda.ZUvarStringSeq;
import xoc.proto.pv.atestub.ZPrototype;

import com.sun.star.uno.Exception;
import com.sun.star.uno.UnoRuntime;
import com.verigy.itee.core.CoreException93k;
import com.verigy.itee.gst.explorer.internal.ConfigEntity;
import com.verigy.itee.gst.explorer.internal.FolderEntity;
import com.verigy.itee.gst.explorer.internal.IUTDContainerEntity;
import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.internal.SpecEntity;
import com.verigy.itee.gst.explorer.internal.TestDataLinkEntity;
import com.verigy.itee.gst.explorer.internal.TestProgramEntity;
import com.verigy.itee.gst.explorer.utils.DebugOption;
import com.verigy.itee.svc.unoaccess.UnoAccessor;


/**
 * UDAccessor is the only interface to connect to UDA
 *
 * @author bennwang
 *
 */
public class UDAccessor {
    private static final String EMPTY_STRING = "";
    private static final String TEST_DATA_ENTITY = "TEST_DATA_ENTITY";
    private static final String NODE_TYPE = "nodeType";
    private static final String SUB_TYPE = "subType";
    private static UDAccessor instance = null;
    private ZUda zUda;
    private ZTestProgram zTestProgram;
    private ZTestDataTreeFocus zTestDataTreeFocus;
    private ZTestDataNode zTestDataNode;
    private ZTestDataTree zTestDataTree;
    private ZTestDataController zTestDataController;
    private ZPrototype ateServerStub;

    private UDAccessor() {
        //empty
    }

    /**
     * Singleton
     *
     * @return {@link UDAccessor} instanace
     */
    public static UDAccessor getInstance() {
        if( instance == null) {
            instance = new UDAccessor();
        }
        return instance;
    }



    /**
     * Load different TDE
     * @param directory directory where TDE is tore
     * @param fileName filename
     * @return boolean
     * @throws CoreException93k {@link CoreException93k}
     * @throws Exception {@link java.lang.Exception}
     */
    @Deprecated
    public boolean loadTDE(String directory, String fileName) throws CoreException93k, Exception{
        return loadTDE(EMPTY_STRING,directory, fileName);
    }

    /**
     * @param packageName package name where the TDE will be added to
     * @param directory the parent directory of the TDE
     * @param fileName file name
     * @return boolean
     * @throws CoreException93k {@link CoreException93k}
     * @throws Exception {@link java.lang.Exception}
     */
    @Deprecated
    public boolean loadTDE(String packageName, String directory, String fileName) throws CoreException93k, Exception{
        if (packageName == null || fileName == null || fileName.isEmpty()) {
            return false;
        }
        long start = System.currentTimeMillis();
        long end;
        ZTestDataController controller = getTestDataController();
        ZTestPackage zTestPackage = controller.getTestPackage(packageName);
        if(zTestPackage == null){
            zTestPackage = controller.createTestPackage(packageName);
            end = System.currentTimeMillis();
            if(DebugOption.DEBUG) {
                System.out.println("Time to create Test Package >>>>" + packageName + "   " + (end - start));
            }
        }
        zTestPackage.importTestDataEntity(directory, fileName);

        end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to load TDE >>>>" + fileName + "   " + (end - start));
        }

        return true;
    }

    /**
     * deleting all Test Packages
     */
    @Deprecated
    public void unloadAll(){
        ZTestDataController controller = getTestDataController();
        controller.clear();
    }


    /**
     * @return
     */
    @Deprecated
    private ZTestDataController getTestDataController() {
        long start = System.currentTimeMillis();
        if (zTestDataController == null) {
            try {
                zTestDataController = UnoAccessor.getUnoServiceManager()
                        .getInstance("xoc.ate.cor.td.ZSTestDataController", null,
                                ZTestDataController.class);
            } catch (CoreException93k e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get ZTestDataController >>>>" + (end - start));
        }
        return zTestDataController;
    }


    @Deprecated
    public ZTestPackage getTestPackage(String name) {
        return getTestDataController().getTestPackage(name);
    }


    /**
     * @return prototype interface to stub some ATEServer functionality
     */
    public ZPrototype getAteServerStub() {
        long start = System.currentTimeMillis();
        if (ateServerStub == null) {
            try {
                ateServerStub = UnoAccessor.getUnoServiceManager()
                        .getInstance("xoc.proto.pv.atestub.ZSAteServerStub", null,
                                ZPrototype.class);
            } catch (CoreException93k e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get ZPrototype >>>>" + (end - start));
        }
        return ateServerStub;
    }


    /**
     * flush test suite
     * @param name test suite name
     * @param packageName the package name which the test suite belongs to
     */
    @Deprecated
    public void flushTestSuite(String name, String packageName) {
        long start = System.currentTimeMillis();
        Object testDataEntity = getTestPackage(packageName).getTestDataEntity(IDService.getInstance().getId("SUITE"), name);
        ZExecutionEntity exeEntity = ZExecutionEntity.class.cast(UnoRuntime.queryInterface(
                ZExecutionEntity.class, testDataEntity));
        exeEntity.flush(new int[0]);
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to run flush suite >>>>" + (end - start) + "   " + name);
        }
    }


    /**
     * Get the uda service
     *
     * @return {@link ZUda}
     */
    public ZUda getUDAService() {
        long start = System.currentTimeMillis();
        if(zUda != null) {
            return zUda;
        }
        try {
            zUda =  UnoAccessor.getUnoServiceManager().getInstance("xoc.ate.cor.uda.ZSUda", null, ZUda.class);
        } catch (CoreException93k e) {
            // LOG.logError("TODO", e);
        } catch (Exception e) {
            // LOG.logError("TODO", e);
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get uda service >>>>\t" + (end - start));
        }
        return zUda;
    }

    private ZTestProgram getZTestProgram() {
        long start = System.currentTimeMillis();
        if(null == zTestProgram) {
            zTestProgram = (ZTestProgram)UnoRuntime.queryInterface(ZTestProgram.class, getUDAService().getUdaInterface("ZTestProgram"));
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get ZTestProgram >>>>\t" + (end - start));
        }
        return zTestProgram;
    }

    /**
     * Get the test data tree focus
     *
     * @return {@link ZTestDataTreeFocus}
     */
    public ZTestDataTreeFocus getZTestDataTreeFocus() {
        long start = System.currentTimeMillis();
        if(null == zTestDataTreeFocus) {
            zTestDataTreeFocus = (ZTestDataTreeFocus)UnoRuntime.queryInterface(ZTestDataTreeFocus.class, getUDAService().getUdaInterface("ZTestDataTreeFocus"));
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get ZTestDataTreeFocus >>>>\t" + (end - start));
        }
        return zTestDataTreeFocus;
    }


    /**
     * Get the focused test data node
     * @return {@link ZTestDataNode}
     */
    public ZTestDataNode getZTestDataNode() {
        long start = System.currentTimeMillis();
        if(null == zTestDataNode) {
            zTestDataNode = (ZTestDataNode)UnoRuntime.queryInterface(ZTestDataNode.class, getUDAService().getUdaInterface("ZTestDataNode"));
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get ZTestDataNode >>>>\t" + (end - start));
        }
        return zTestDataNode;
    }

    /**
     * Get the children nodes of the given node
     * @param node given node
     * @return children {@link List}
     */
    public ArrayList<IZTestDataNode> getChildren(IZTestDataNode node) {
        if(null == node) {
            return null;
        }
        ArrayList<IZTestDataNode> children = new ArrayList<IZTestDataNode>();
        int addresses[] = null;
        long start = System.currentTimeMillis();
        getUDAService().startTransaction();
        ZUvarLong var = getUDAService().localLong((int)node.getAddress());
        ZUvarLongSeq list = getUDAService().remoteLongSeq();
        ZUvarAttributeListSeq attrList = getUDAService().remoteAttributeListSeq();
        getZTestDataTreeFocus().setToAddress(var);
        getZTestDataTreeFocus().setToChildren();
        getZTestDataNode().getAddress(list);
        getZTestDataNode().getAttributes(attrList);
        getUDAService().sync();
        addresses =  getUDAService().getLongSeq(list);
        getUDAService().endTransaction();
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get TDO/TDE children >>>>" +  + (end - start));
        }

        //TODO Benny refactor the instanceof
        boolean isTdoNode = (node instanceof ITdoNode) ? true : false;
        if(isTdoNode) {
            if(null != addresses && addresses.length > 0){
                for(int i=0; i<addresses.length; i++) {
                    children.add(new TdoNode(node,addresses[i]));
                }
            }
        } else {
            if(null != addresses && addresses.length > 0){
                for(int i=0; i<addresses.length; i++) {
                    children.add(new TestDataNode(node,addresses[i]));
                }
            }
        }

        return children;
    }


    /**
     *  Get the test data tree
     * @return {@link ZTestDataTree}
     */
    public ZTestDataTree getZTestDataTree() {
        long start = System.currentTimeMillis();
        if(null == zTestDataTree) {
            zTestDataTree = (ZTestDataTree)UnoRuntime.queryInterface(ZTestDataTree.class, getUDAService().getUdaInterface("ZTestDataTree"));
        }
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get ZTestDataTree >>>>\t" + (end - start));
        }
        return zTestDataTree;
    }

    /**
     *
     * @param path absolute path
     * @return root test data entity
     */
    public TestProgramEntity loadTestProgram(String path) {
        long start = System.currentTimeMillis();
        getUDAService().startTransaction();
            //TODO Benny check if unload is necessary every time
            getZTestProgram().unload();
            getZTestProgram().load(path);

            //Traverse tree
            ZUvarLongSeq address = getUDAService().remoteLongSeq();
            getZTestDataTreeFocus().setToRoot();
            getZTestDataNode().getAddress(address);
            getUDAService().sync();

            // Create TDE tree in UI
            IUTDEntity root = null;
            int[] rootAddr = getUDAService().getLongSeq(address);
            if (rootAddr.length > 0) {
                root = createTDENode(null, rootAddr[0]);
            }
        getUDAService().endTransaction();
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to load a TP >>>>\t" + (end - start));
        }

        if(root != null && root instanceof TestProgramEntity){
            return (TestProgramEntity) root;
        }
        return null;
    }

    /**
     * Traverse a test data tree
     * @param address
     */
    private void traverseTree(int[] address) {
        if(null != address && address.length > 0) {
            for(int i=0; i<address.length; i++) {
                getNode(address[i]);
                getUDAService().startTransaction();
                ZUvarLong nodeAddress = getUDAService().localLong(address[i]);
                ZUvarLongSeq childrenAddress = getUDAService().remoteLongSeq();
                getZTestDataTreeFocus().setToAddress(nodeAddress);
                getZTestDataTreeFocus().setToChildren();
                getZTestDataNode().getAddress(childrenAddress);
                getUDAService().sync();
                int[] children = getUDAService().getLongSeq(childrenAddress);
                getUDAService().endTransaction();
                if(children.length > 0) {
                    traverseTree(children);
                }
            }
        }
    }

    /**
     * Get a test data node properties
     *
     * @param address
     */
    private void getNode(int address) {
        long start = System.currentTimeMillis();
        getUDAService().startTransaction();
        {
            ZUvarLong nodeAdress = getUDAService().localLong(address);
            ZUvarStringSeq nodeName = getUDAService().remoteStringSeq();
            ZUvarAttributeListSeq attrList = getUDAService().remoteAttributeListSeq();
            getZTestDataTreeFocus().setToAddress(nodeAdress);
            getZTestDataNode().getName(nodeName);
            getZTestDataNode().getAttributes(attrList);
            //get the meta data
            ZUvarString meta = getUDAService().remoteString();
            getZTestDataNode().getTdeMetaData(meta);
            getUDAService().sync();
            if(DebugOption.DEBUG) {
                System.out.println("node name is:\t" + zUda.getStringSeq(nodeName)[0]);
            }
            ZAttribute[] attrib =  getUDAService().getAttributeListSeq(attrList)[0];
            boolean isTDENode = false;
            if(null != attrib && attrib.length > 0) {
                for(int i=0; i<attrib.length; i++) {
                    if(DebugOption.DEBUG) {
                        System.out.println("\t"+attrib[i].name + "\t" + attrib[i].value);
                    }
                    if(attrib[i].name.equals(NODE_TYPE) && attrib[i].value.equals(TEST_DATA_ENTITY)){
                        isTDENode = true;
                    }
                }
            }

            if (DebugOption.DEBUG && isTDENode) {
                System.out.println("node meta:\t" + getUDAService().getString(meta));
            }
        }
        getUDAService().endTransaction();
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to get a test node >>>>\t" + (end - start));
        }
    }

    private IUTDEntity createTDENode(IUTDContainerEntity parent, int address) {
        long start = System.currentTimeMillis();

        getUDAService().startTransaction();
        ZUvarLong nodeAdress = getUDAService().localLong(address);
        ZUvarStringSeq nodeName = getUDAService().remoteStringSeq();
        ZUvarString udaFileName = getUDAService().remoteString();
        ZUvarAttributeListSeq attrList = getUDAService().remoteAttributeListSeq();
        getZTestDataTreeFocus().setToAddress(nodeAdress);

        getZTestDataNode().getName(nodeName);
        getZTestDataNode().getFileName(udaFileName);
        getZTestDataNode().getAttributes(attrList);
        getUDAService().sync();

        String name = getUDAService().getStringSeq(nodeName)[0];
        String fileName = getUDAService().getString(udaFileName);

        if(DebugOption.DEBUG) {
            System.out.println("node name is:\t" + name);
        }

        ZAttribute[] attrib = getUDAService().getAttributeListSeq(attrList)[0];
        getUDAService().endTransaction();

        if (null != attrib && attrib.length > 0) {
            String nodeType = null;
            String subType = null;
            String linkTarget = null;
            for (int i = 0; i < attrib.length; i++) {
                if(DebugOption.DEBUG) {
                    System.out.println("\t" + attrib[i].name + "\t" + attrib[i].value);
                }

                if (attrib[i].name.equals(NODE_TYPE)) {
                    nodeType = attrib[i].value;
                } else if (attrib[i].name.equals("subType")) {
                    subType = attrib[i].value;
                } else if (attrib[i].name.equals("linkTarget")) {
                    linkTarget = attrib[i].value;
                }
            }

            long end = System.currentTimeMillis();
            if(DebugOption.DEBUG) {
                System.out.println("Time to read ZTestDataNode >>>>" + (end - start));
            }

            if (nodeType == null) {
                return null;
            }
            IUTDEntity entity = null;
            if (nodeType.equals("TEST_PROGRAM")) {
                IResource resource = ResourcesPlugin.getWorkspace().getRoot().getContainerForLocation(new Path(fileName));
                entity = new TestProgramEntity(address, name, resource);
                return entity;
            }

            if (nodeType.equals("TEST_PACKAGE")) {
                IResource resource = ResourcesPlugin.getWorkspace().getRoot()
                        .getContainerForLocation(new Path(fileName));
                entity = new FolderEntity(parent, address, name, resource);
                return entity;
            }

            if (nodeType.equals(TEST_DATA_ENTITY)) {
                if (subType == null) {
                    return null;
                }

                IResource resource = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(fileName));
                if (subType.equals("SPEC")) {
                    entity = new SpecEntity(parent, address, name, resource);
                } else if (subType.equals("CFG")) {
                    entity = new ConfigEntity(parent, address, name, resource);
                }

                return entity;
            }

            if (nodeType.equals("TEST_DATA_LINK")) {
                IResource resource = ResourcesPlugin.getWorkspace().getRoot()
                        .getFileForLocation(new Path(fileName));
                IResource targetResource = ResourcesPlugin.getWorkspace().getRoot()
                        .getFileForLocation(new Path(linkTarget));
                entity = new TestDataLinkEntity(parent, address, name, resource,
                        targetResource);
                return entity;
            }
        }

        return null;
    }

    /**
     * @param address the address to match the path.
     * @return Returns the path to the corresponding address. Returns empty string
     * if there is no matched path.
     */
    private String addressToPath(int address) {
        getZTestDataTreeFocus().setToAddress(getUDAService().localLong(address));
        ZUvarStringSeq path = getUDAService().remoteStringSeq();

        getZTestDataNode().getPath(path);
        getUDAService().sync();

        String[] pathSeq = getUDAService().getStringSeq(path);

        return pathSeq.length > 0 ? pathSeq[0] : EMPTY_STRING;
    }

    /**
     * created children list for parentEntity
     * @param parentEntity parent test data entity
     */
    public void createTDETree(IUTDContainerEntity parentEntity){
        if(parentEntity == null){
            return;
        }

        getUDAService().startTransaction();
        ZUvarLong nodeAddress = getUDAService().localLong((int)parentEntity.getAddress());
        ZUvarLongSeq childrenAddress = getUDAService().remoteLongSeq();
        getZTestDataTreeFocus().setToAddress(nodeAddress);
        getZTestDataTreeFocus().setToChildren();
        getZTestDataNode().getAddress(childrenAddress);
        getUDAService().sync();
        int[] children = getUDAService().getLongSeq(childrenAddress);
        getUDAService().endTransaction();

        if (children.length > 0) {
            for (int i = 0; i < children.length; i++) {
                IUTDEntity entity = createTDENode(parentEntity, children[i]);
                if (entity != null) {
                    parentEntity.addChild(entity);
                }
            }
        }
    }

    /**
     * unload test program
     */
    public void unloadTestProgram(){
        getUDAService().startTransaction();
        getZTestProgram().unload();
        getUDAService().endTransaction();
    }

    /**
     * create new node
     * @param parentNode parent node
     * @param name node name
     * @param type node type
     * @param meta format info
     * @return new created node
     */
    public IUTDEntity createUDANode(IUTDContainerEntity parentNode, String name, String type, String meta) {
        long start = System.currentTimeMillis();

        ZAttribute[] attrs;
        if ("SPEC".equals(type) || "CFG".equals(type)) {
            attrs = new ZAttribute[2];
            attrs[0] = new ZAttribute(NODE_TYPE, TEST_DATA_ENTITY);
            attrs[1] = new ZAttribute("subType", type);
        } else {
            attrs = new ZAttribute[1];
            attrs[0] = new ZAttribute(NODE_TYPE, type);
        }

        int childAddress = createTestDataChildNode((int) parentNode.getAddress(), attrs,
                name, meta);
        IUTDEntity entity = createTDENode(parentNode, childAddress);

        long end = System.currentTimeMillis();
        if (DebugOption.DEBUG) {
            System.out.println("Time to create ZTestDataNode >>>>" + (end - start));
        }
        return entity;
    }

    /**
     * @param address the address of the TDE.
     * @return Returns the meta data information for a TDE specified by the input
     * address.
     */
    public String getMetaDataFor(int address) {
        ZTestDataTreeFocus focus = getZTestDataTreeFocus();
        ZUda uda = getUDAService();
        ZTestDataNode node = getZTestDataNode();

        uda.startTransaction();
        focus.setToAddress(uda.localLong(address));
        ZUvarAttributeListSeq attrListSeq = uda.remoteAttributeListSeq();
        node.getAttributes(attrListSeq);

        uda.sync();

        boolean isTDE = false;
        ZAttribute[] attrs = uda.getAttributeListSeq(attrListSeq)[0];
        for (ZAttribute a : attrs) {
            if(NODE_TYPE.equals(a.name) && TEST_DATA_ENTITY.equals(a.value)) {
                isTDE = true;
            }
        }

        String result = EMPTY_STRING;
        if (isTDE) {
            ZUvarString metaData = uda.remoteString();
            node.getTdeMetaData(metaData);
            uda.sync();

            result = uda.getString(metaData);
        }
        uda.endTransaction();

        return result;
    }

    /**
     * Sets the new meta data to a TDE specified by inputed address.
     * @param address the address to the TDE
     * @param value the new meta data
     */
    public void setMetaDataFor(int address, String value) {
        ZTestDataTreeFocus focus = getZTestDataTreeFocus();
        ZUda uda = getUDAService();
        ZTestDataNode node = getZTestDataNode();

        focus.setToAddress(uda.localLong(address));
        ZUvarAttributeListSeq attrListSeq = uda.remoteAttributeListSeq();
        node.getAttributes(attrListSeq);

        uda.sync();

        boolean isTDE = false;
        ZAttribute[] attrs = uda.getAttributeListSeq(attrListSeq)[0];
        for (ZAttribute a : attrs) {
            if(NODE_TYPE.equals(a.name) && TEST_DATA_ENTITY.equals(a.value)) {
                isTDE = true;
            }
        }

        if (isTDE) {
            ZUvarString metaData = uda.localString(value);
            node.setTdeMetaData(metaData);
            uda.sync();
        }
    }

    /**
     * @param address the address to a specific test data entity
     * @return Returns the node type of specified address.
     */
    public String getNodeTypeFor(int address) {
        ZTestDataTreeFocus focus = getZTestDataTreeFocus();
        ZUda uda = getUDAService();
        ZTestDataNode node = getZTestDataNode();

        focus.setToAddress(uda.localLong(address));

        ZUvarAttributeListSeq attrListSeq = uda.remoteAttributeListSeq();
        node.getAttributes(attrListSeq);

        uda.sync();

        String result = EMPTY_STRING;
        ZAttribute[] attrs = uda.getAttributeListSeq(attrListSeq)[0];
        for (ZAttribute a : attrs) {
            if(NODE_TYPE.equals(a.name)) {
                result = a.value;
            }
        }

        return result;
    }

    /**
     * @param address the address to a specific test data entity
     * @return Returns the node type of specified address.
     */
    public String getNodeSubTypeFor(int address) {
        ZTestDataTreeFocus focus = getZTestDataTreeFocus();
        ZUda uda = getUDAService();
        ZTestDataNode node = getZTestDataNode();

        focus.setToAddress(uda.localLong(address));

        ZUvarAttributeListSeq attrListSeq = uda.remoteAttributeListSeq();
        node.getAttributes(attrListSeq);

        uda.sync();

        String result = EMPTY_STRING;
        ZAttribute[] attrs = uda.getAttributeListSeq(attrListSeq)[0];
        for (ZAttribute a : attrs) {
            if(SUB_TYPE.equals(a.name)) {
                result = a.value;
            }
        }

        return result;
    }

    /**
     * @param address the address to a specific test data entity
     * @return Returns the node type of specified address.
     */
    public String getNodeNameFor(int address) {
        ZTestDataTreeFocus focus = getZTestDataTreeFocus();
        ZUda uda = getUDAService();
        ZTestDataNode node = getZTestDataNode();

        focus.setToAddress(uda.localLong(address));

        ZUvarStringSeq strSeq = uda.remoteStringSeq();
        node.getName(strSeq);

        uda.sync();

        String[] names = uda.getStringSeq(strSeq);

        return names.length > 0 ? names[0] : EMPTY_STRING;
    }

    /**
     * Set a new name for the node
     * @param name new name
     * @param address the node address
     */
    public void setNodeNameFor(final String name, final int address) {
        getUDAService().startTransaction();
        ZUvarLong var = getUDAService().localLong(address);
        getZTestDataTreeFocus().setToAddress(var);
        ZUvarString newName = getUDAService().localString(name);
        getZTestDataNode().setName(newName);
        getUDAService().sync();
        getUDAService().endTransaction();
    }

    /**
     * Get the node value
     * @param address the node address
     * @return node value
     */
    public String getNodeValueFor(int address) {
        String value = null;
        getUDAService().startTransaction();
        ZUvarLong var = getUDAService().localLong(address);
        ZUvarAttributeListSeq attributesList = getUDAService().remoteAttributeListSeq();
        getZTestDataTreeFocus().setToAddress(var);
        getZTestDataNode().getAttributes(attributesList);
        getUDAService().sync();
        ZAttribute[] attributes = getUDAService().getAttributeListSeq(attributesList)[0];
        getUDAService().endTransaction();
        if(null != attributes && attributes.length > 0) {
            boolean hasValue = false;
            for(int i=0; i<attributes.length; i++) {
//                System.out.println(">>>>>>>>>>>>" + attributes[i].name + " "+ attributes[i].value);
                if(attributes[i].name.equalsIgnoreCase("val") || attributes[i].name.equalsIgnoreCase("label")) {
                    value = attributes[i].value;
                    hasValue = true;
                    break;
                }
            }

            if (!hasValue) {
                value = EMPTY_STRING;
            }
        }
        return value;
    }

    /**
     * Set a new value for the node
     * @param value new value
     * @param address the node address
     */
    public void setNodeValueFor(final String value, final int address) {
        getUDAService().startTransaction();
        ZUvarLong var = getUDAService().localLong(address);
        getZTestDataTreeFocus().setToAddress(var);
        ZUvarAttributeListSeq attrListSeq = getUDAService().remoteAttributeListSeq();
        getZTestDataNode().getAttributes(attrListSeq);
        getUDAService().sync();
        //TODO Benny check the length of the sequence
        ZAttribute[] attrs = getUDAService().getAttributeListSeq(attrListSeq)[0];
        if(null != attrs && attrs.length > 0) {
            for(int i=0; i<attrs.length; i++) {
//                System.out.println(">>>>>>>>>>>>" + attrs[i].name + " "+ attrs[i].value);
                if(attrs[i].name.equals("val") || attrs[i].name.equals("label")) {
                    attrs[i].value = value;
                    //TODO Benny use the update to get the new value
                    getZTestDataNode().setAttributes(getUDAService().localAttributeList(attrs));
                    getUDAService().sync();
                    getUDAService().endTransaction();
                }
            }
        }
        getUDAService().endTransaction();
    }

    /**
     * Remove a child
     *
     * @param address child to be deleted
     */
    public void removeChild(final int address) {
        long start = System.currentTimeMillis();
        getUDAService().startTransaction();
        ZUvarLong var = getUDAService().localLong(address);
        getZTestDataTreeFocus().setToAddress(var);
        getZTestDataTree().deleteNode();
        getUDAService().endTransaction();
        long end = System.currentTimeMillis();
        if(DebugOption.DEBUG) {
            System.out.println("Time to delete TDO child >>>>" +  + (end - start));
        }
    }

    /**
     * Create a new child node in under layer. This method can be enhanced to support generic node creation
     * @param parent {@link ITdoNode}
     * @param attrs {@link ZAttribute}
     * @param name new name
     * @return {@link ITdoNode}
     */
    public int createTestDataChildNode(final int parent, final ZAttribute[] attrs, final String name)  {
        return createTestDataChildNode(parent, attrs, name, null);
    }

    /**
     * Create a new child node in under layer. This method can be enhanced to support generic node creation
     * @param parent {@link ITdoNode}
     * @param attrs {@link ZAttribute}
     * @param name new name
     * @param meta format info
     * @return {@link ITdoNode}
     */
    public int createTestDataChildNode(final int parent, final ZAttribute[] attrs, final String name,
            final String meta)  {
        int child = -1;
        getUDAService().startTransaction();
        ZUvarLong address = getUDAService().localLong(parent);
        ZUvarString localName = getUDAService().localString(name);
        ZUvarAttributeList attributes = getUDAService().localAttributeList(attrs);
        getZTestDataTreeFocus().setToAddress(address);
        getZTestDataTree().createChildNode(localName, attributes, true);
        getUDAService().sync();
        ZUvarLongSeq childAddress = getUDAService().remoteLongSeq();
        getZTestDataNode().getAddress(childAddress);
        getUDAService().sync();

        // set meta data
        if (meta != null && !meta.isEmpty()) {
            ZUvarString metaData = getUDAService().localString(meta);
            getZTestDataNode().setTdeMetaData(metaData);
            getUDAService().sync();
        }

        child = getUDAService().getLongSeq(childAddress)[0];
        getUDAService().endTransaction();
        return child;
    }

    /**
     * @param previous
     * @param attrs
     * @param name
     * @return
     */
    public int createTdoSiblingNode(final int previous, final ZAttribute[] attrs, final String name)  {
        int sibling = -1;
        getUDAService().startTransaction();
        ZUvarLong address = getUDAService().localLong(previous);
        ZUvarString localName = getUDAService().localString(name);
        ZUvarAttributeList attributes = getUDAService().localAttributeList(attrs);
        getZTestDataTreeFocus().setToAddress(address);
        getZTestDataTree().createSiblingNode(localName, attributes, true);
        getUDAService().sync();
        ZUvarLongSeq childAddress = getUDAService().remoteLongSeq();
        getZTestDataNode().getAddress(childAddress);
        getUDAService().sync();
        sibling = getUDAService().getLongSeq(childAddress)[0];
        getUDAService().endTransaction();
        return sibling;
    }

}
