/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.ui.IEditorPart;

import com.verigy.itee.gst.explorer.ate.IZTestDataNode;
import com.verigy.itee.gst.explorer.ate.TestDataNode;
import com.verigy.itee.gst.explorer.ate.UDAccessor;
import com.verigy.itee.gst.explorer.utils.OpenEditorUtil;

/**
 * @author leenshi
 *
 */
public class FileEntity extends TestDataNode implements IUTDEntity {

    /**
     * resource file, needed?
     */
    protected IResource entityResource;

    /**
     * bind status
     */
    protected boolean bindStatus = true;

    /**
     * @param parent
     *            parent entity
     * @param address
     *            node address
     */
    public FileEntity(IUTDContainerEntity parent, int address) {
        super(parent, address);
    }

    /**
     * @param parent
     *            parent entity
     * @param resource
     *            file resource
     */
    public FileEntity(IUTDContainerEntity parent, IResource resource) {
        super(parent, 0);
        entityResource = resource;
    }

    /**
     * @param parent parent entity
     * @param address node address
     * @param name entity name
     * @param resource relevant file
     */
    public FileEntity(IUTDContainerEntity parent, int address, String name, IResource resource) {
        super(parent, address, name);
        entityResource = resource;
    }

    @Override
    public IResource getResource() {
        return entityResource;
    }

    @Override
    public void setResource(IResource resource) {
        entityResource = resource;
    }

    @Override
    public boolean getBindStatus() {
        return bindStatus;
    }

    @Override
    public void setBindStatus(boolean status) {
        bindStatus = status;
    }

    @Override
    public String getType() {
        return "FILE";
    }

    /**
     * @return editor part
     */
    public IEditorPart open() {
        if (this instanceof SpecEntity || this instanceof ConfigEntity) {
            IResource resource = this.getResource();
            if (resource != null && resource instanceof IFile) {
                // fake load for format
                // if (hasFormat((IFile) resource)) {
                // return OpenEditorUtil.openEditorByPath(resource);
                // }
                // end of load file with format

//                String packageName = "";
//                Object parent = getParent();
//                if (parent instanceof IUTDContainerEntity) {
//                    packageName = ((IUTDContainerEntity) parent).getPackageName();
//                }
                return OpenEditorUtil.openLoadedTDE((IFile) resource, (IZTestDataNode)this);
            }
            return null;
        }
        return null;
    }

    /**
     * @param multi true if open with multi editor
     * @return editor part
     */
    public IEditorPart open(boolean multi) {
        if (this instanceof SpecEntity || this instanceof ConfigEntity) {
            IResource resource = this.getResource();
            if (resource != null && resource instanceof IFile) {
                // fake load for format
                // if (hasFormat((IFile) resource)) {
                // return OpenEditorUtil.openEditorByPath(resource);
                // }
                // end of load file with format

//                String packageName = "";
//                Object parent = getParent();
//                if (parent instanceof IUTDContainerEntity) {
//                    packageName = ((IUTDContainerEntity) parent).getPackageName();
//                }
                return OpenEditorUtil.openLoadedTDE((IFile) resource,"","", (IZTestDataNode)this, multi);
            }
            return null;
        }
        return null;
    }

    @Override
    public String getMetaData() {
        return UDAccessor.getInstance().getMetaDataFor(address);
    }

    @Override
    public void setMetaData(String metaData) {
        UDAccessor.getInstance().setMetaDataFor(address, metaData);
    }

    @Override
    public List<IZTestDataNode> getChildren() {
        return new ArrayList<IZTestDataNode>();
    }

    @Override
    public boolean hasChild() {
        return false;
    }

    @Override
    public void setParent(IZTestDataNode parentNode) {
        parent = parentNode;
    }
}
