/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.wizards;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.wizards.newresource.BasicNewResourceWizard;

/**
 * @author leenshi
 *
 */
public class UTDNewWizard extends BasicNewResourceWizard {

	private UTDSelectTemplatePage mainPage;

	@Override
	public void addPages(){
		mainPage = new UTDSelectTemplatePage("Select a Template", getSelection());
		addPage(mainPage);
	}

	@Override
	public boolean performFinish() {
		return mainPage.createEntity();
	}

	@Override
	public void init(IWorkbench workbench, IStructuredSelection sel) {
		super.init(workbench, sel);
		setWindowTitle("New Test Data Entity");
	}

}
