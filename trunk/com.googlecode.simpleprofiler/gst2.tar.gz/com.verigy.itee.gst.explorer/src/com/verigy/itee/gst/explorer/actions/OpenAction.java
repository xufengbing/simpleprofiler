/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbenchPage;

import com.verigy.itee.gst.explorer.internal.FileEntity;

/**
 * Open test data entity (file type entity) in editor
 *
 * @author leenshi
 *
 */
public class OpenAction extends Action {

    private final IWorkbenchPage page;

    private final ISelectionProvider provider;

    private Object data;

    private boolean multi = false;

    /**
     * @param p
     *            workbench page
     * @param sel
     *            selection provider
     */
    public OpenAction(IWorkbenchPage p, ISelectionProvider sel) {
        setText("Open");
        page = p;
        provider = sel;
    }

    /**
     * @param p workbench page
     * @param sel selection provider
     * @param m true if open with multi editor
     */
    public OpenAction(IWorkbenchPage p, ISelectionProvider sel, boolean m) {
        setText("Open With Multi Page Editor");
        page = p;
        provider = sel;
        multi = m;
    }

    @Override
    public boolean isEnabled() {
        ISelection selection = provider.getSelection();
        if (!selection.isEmpty()) {
            IStructuredSelection strSelection = (IStructuredSelection) selection;
            if (strSelection.size() == 1) {
                data = strSelection.getFirstElement();
                return data instanceof FileEntity;
            }
        }
        return false;
    }

    @Override
    public void run() {
        if (isEnabled()) {
            ((FileEntity) data).open(multi);
        }
    }
}
