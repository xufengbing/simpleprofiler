/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.ate;



/**
 * Implementation of interface {@link ITdoNode}. This is a thin wrapper of a TDO node get from UDA
 *
 * @author bennwang
 *
 */
public class TdoNode extends TestDataNode implements ITdoNode {

    /**
     * The node type, see {@link GenericNodeType}
     */
    protected GenericNodeType type;
    private final boolean isRoot;


    /**
     * Construct a TDO node according to the parent node and an unique address
     *
     * @param parent parent node
     * @param address unique address which can only be get from UDA
     */
    public TdoNode(IZTestDataNode parent, int address) {
        super(parent, address);
        isRoot = false;
    }

    /**
     * Construct a TDO or TDE node according to the parent node and an unique address
     * @param parent parent node
     * @param address unique address which can only be get from UDA
     * @param isRoot if this node is a TDE node
     */
    public TdoNode(IZTestDataNode parent, int address, boolean isRoot) {
        super(parent, address);
        this.isRoot = isRoot;
    }


    @Override
    public boolean isRoot() {
        return isRoot;
    }

    @Override
    public GenericNodeType getNodeType() {
        if (type == null) {
            type = GenericNodeType.convertFrom(UDAccessor.getInstance().getNodeSubTypeFor(address));
        }
        return type;
    }


    @Override
    public IZTestDataNode getRoot() {
        if (this.isRoot == true) {
            return this;
        }

        IZTestDataNode current = this;
        IZTestDataNode root = this;
        while (current instanceof ITdoNode) {
            root = current;
            current = current.getParent();
        }
        return root;
    }

    @Override
    public void removeChild(ITdoNode child) {
        UDAccessor.getInstance().removeChild((int)child.getAddress());
        getChildren().remove(child);
    }

    @Override
    public void addChild(ITdoNode child) {
        if(getChildren().contains(child)) {
            return;
        }
        getChildren().add(child);
    }

    @Override
    public void addChild(ITdoNode child, int index) {
        if(getChildren().contains(child)) {
            return;
        }
        getChildren().add(index, child);
    }

    @Override
    public boolean equals(Object obj) {
        if(obj != null && obj instanceof ITdoNode) {
            return ((ITdoNode)obj).getAddress() == this.getAddress() ? true :false;
        }
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return this.address;
    }
}
