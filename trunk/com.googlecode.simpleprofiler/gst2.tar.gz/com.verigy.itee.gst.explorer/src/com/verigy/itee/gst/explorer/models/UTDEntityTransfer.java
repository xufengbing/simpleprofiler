/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.models;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.eclipse.swt.dnd.ByteArrayTransfer;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.TransferData;

import com.verigy.itee.gst.explorer.internal.IUTDEntity;
import com.verigy.itee.gst.explorer.utils.Util;

/**
 * @author leenshi
 *
 */
public class UTDEntityTransfer extends ByteArrayTransfer {

    private static final String UTD_ENTITY = "verigy_gst_test_data_entity";

    private static final int UTD_ENTITY_TYPE_ID = registerType(UTD_ENTITY);

    private static UTDEntityTransfer instance = new UTDEntityTransfer();

    /**
     * @return UTDEntityTransfer instance
     */
    public static UTDEntityTransfer getInstance() {
        return instance;
    }

    @Override
    protected String[] getTypeNames() {
        return new String[] { UTD_ENTITY };
    }

    @Override
    protected int[] getTypeIds() {
        return new int[] { UTD_ENTITY_TYPE_ID };
    }

    @Override
    protected void javaToNative(Object object, TransferData transferData) {
        if (!isSupportedType(transferData)) {
            DND.error(DND.ERROR_INVALID_DATA);
        }

        if (!(object instanceof IUTDEntity[])) {
            return;
        }

        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ObjectOutputStream objectOut = new ObjectOutputStream(out);
            IUTDEntity[] entities = (IUTDEntity[]) object;
            //write count
            objectOut.writeInt(entities.length);
            for (int i = 0; i < entities.length; i++) {
                //write entity UDA address
                objectOut.writeLong(entities[i].getAddress());
            }
            objectOut.close();
            out.close();
            byte[] buffer = out.toByteArray();

            super.javaToNative(buffer, transferData);

        } catch (IOException e) {
            Util.LOG.logError(e.getMessage(), e);
        }
    }

    @Override
    protected Object nativeToJava(TransferData transferData) {
        if (!isSupportedType(transferData)) {
            return null;
        }

        try {
            byte[] buffer = (byte[]) super.nativeToJava(transferData);
            if (buffer == null) {
                return null;
            }
            ByteArrayInputStream in = new ByteArrayInputStream(buffer);
            ObjectInputStream objectInput = new ObjectInputStream(in);
            //read count
            int count = objectInput.readInt();
            long[] addresses = new long[count];
            for (int i = 0; i < addresses.length; i++) {
                addresses[i] = objectInput.readLong();
            }
            objectInput.close();
            in.close();
            return addresses;
        } catch (IOException e) {
            Util.LOG.logError(e.getMessage(), e);
        }

        return null;
    }

}
