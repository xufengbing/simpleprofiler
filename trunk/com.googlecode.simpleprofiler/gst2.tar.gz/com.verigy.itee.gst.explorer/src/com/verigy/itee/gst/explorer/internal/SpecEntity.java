/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.internal;

import org.eclipse.core.resources.IResource;


/**
 * Spec Sheet Entity
 * @author leenshi
 *
 */
public class SpecEntity extends FileEntity {

    /**
     * @param parent parent entity
     * @param address node address
     * @param name entity name
     * @param resource relevant file
     */
    public SpecEntity(IUTDContainerEntity parent, int address, String name, IResource resource) {
        super(parent, address, name, resource);
    }

    @Override
    public String getType() {
        return "SPEC";
    }

}
