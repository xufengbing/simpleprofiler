/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.markers;

import com.verigy.itee.gst.explorer.internal.IUTDEntity;

/**
 * Can be added to a ProblemManager to get notified about error
 * marker changes. Used to update error ticks.
 *
 * @author leenshi
 *
 */
public interface IProblemChangedListener {

    /**
     * @param changedEntities resources which have problem marker changes
     * @param markerChanged true if marker is changed
     */
    public void problemsChanged(IUTDEntity[] changedEntities, boolean markerChanged);

}
