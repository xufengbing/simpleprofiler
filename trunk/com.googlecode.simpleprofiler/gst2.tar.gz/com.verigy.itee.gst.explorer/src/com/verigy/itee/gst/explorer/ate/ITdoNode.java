/*******************************************************************************
 * Copyright (c) 2010 Verigy. All rights reserved.
 *
 * Contributors:
 *     Verigy - initial API and implementation
 *******************************************************************************/
package com.verigy.itee.gst.explorer.ate;


/**
 * An interface to operate a TDO node
 *
 * @author bennwang
 *
 */
public interface ITdoNode extends IZTestDataNode {


    /**
     * If this node is root node TDE
     * @return boolean
     */
    public boolean isRoot();

    /**
     * Get the node type
     * @return {@link GenericNodeType}
     */
    public GenericNodeType getNodeType();

    /**
     * Get the root node
     * @return {@link IZTestDataNode}
     */
    public IZTestDataNode getRoot();

    /**
     * Remove a child
     * @param child {@link ITdoNode}
     */
    public void removeChild(ITdoNode child);

    /**
     * Add a child
     * @param child {@link ITdoNode}
     */
    public void addChild(ITdoNode child);

    /**
     * Add a child according to a specified index
     * @param child {@link ITdoNode}
     * @param index The index to be added
     */
    public void addChild(ITdoNode child, int index);
}
